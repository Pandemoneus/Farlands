data.raw["item"]["stone-brick"].stack_size = 500
data.raw["item"]["concrete"].stack_size = 500