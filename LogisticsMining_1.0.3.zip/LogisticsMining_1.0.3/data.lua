require("prototypes.item.item")
require("prototypes.recipe.recipes")
require("prototypes.technology.technology")
require("prototypes.entity.entities")
