require "defines"

script.on_event(defines.events.on_tick, function(event)

	if (event.tick % 20 ==0) then
		for _,player in pairs (game.players) do
			if (player.vehicle~=nil) then
				local vehicle = player.vehicle
				for orientation=0, 1, 0.25 do
					if vehicle.orientation~=orientation and
					 vehicle.orientation<orientation+0.025 and
					  vehicle.orientation>orientation-0.025 then
					  
						foundPrev = false;
						if (vehicles==nil) then
							vehicles = {}
						else
							for index, previousVehicle in pairs(vehicles) do
								if previousVehicle.entity==vehicle then
									foundPrev = true
									if previousVehicle.orientation==vehicle.orientation then
										vehicle.orientation = orientation
										table.remove(vehicles, index)
									else
										previousVehicle.orientation = vehicle.orientation
									end
									break
								end
							end
						end

						if (foundPrev == false) then
							table.insert(vehicles, {entity = vehicle, orientation = vehicle.orientation})
						end
					end
				end
			end
		end
	end
	
end)