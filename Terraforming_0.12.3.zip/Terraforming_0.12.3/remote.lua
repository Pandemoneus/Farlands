function set_remotes()
	remote.add_interface("Terraforming", {
		hello = function() remote_hello() end,
		version = function() return MOD_VERSION end,
		moddebug = function(b) if b then debug = b else debug = not debug end; shout("Debug mode = " .. tostring(debug)) end,
		testing = function() remote_testing() end,
		tech = function() remote_technology() end,
		give = function() remote_give_tf() end,
		fill = function() remote_fill_all_tf() end,
		supply = function() remote_supply_chests() end,
	});
end 

function remote_hello() 
	shout("Terraformeing " .. MOD_VERSION .. " ready and awaiting your command!");
	if debug then shout ("*** DEBUG IS ENABLED ***") end
	shout("Craft speed="..BASE_CRAFTING_SPEED..", Fuel size="..FUEL_INVENTORY_SIZE..", Module slots="..MODULE_SLOTS.."/"..LOGISTIC_MODULE_SLOTS..", Logistics order x"..LOGISTIC_RECIPE_COUNT)
end

function remote_testing()
	local f = game.forces["player"];
	
	f.reset_recipes()
	f.reset_technologies()
	for _,t in pairs(f.technologies) do t.researched=t.enabled end
	game.always_day = true
	game.peaceful_mode = true
	game.forces['enemy'].kill_all_units()
	f.manual_mining_speed_modifier=1000
	f.manual_crafting_speed_modifier=1000
	f.laboratory_speed_modifier = 1000
	remote_give_tf()
	remote_supply_chests()
	shout("Test mode is go!")
end

function remote_technology()
	local f = game.forces["player"];
	f.technologies["terraforming-1"].researched = true
	f.technologies["terraforming-2"].researched = true
	f.technologies["terraforming-3"].researched = true
	f.technologies["terraforming-prefabrication"].researched = true
	f.technologies["terraforming-logistics"].researched = true
	shout ("Research completed!")
end

function remote_fill_all_tf()
	if global.terraformers ~= nil then
		for i, tf in pairs(global.terraformers) do
			local e = tf.entity;
			if is_terraformer[e.name] <= 2 and e.recipe then -- excludes bridges!
				local r = e.recipe
				if tf.type ~= "prefabrication-plant" then
					local fuel = e.get_inventory(defines.inventory.fuel)
					fuel.insert{name="coal", count=50 * FUEL_INVENTORY_SIZE}
				end
				for i, v in pairs(r.ingredients) do
					if v.type == "item" and v.amount > 0 then
						e.insert{name=v.name, count=game.item_prototypes[v.name].stack_size * 2} -- sometimes they seem to allow more than a stack!
					end
				end
				local modules = e.get_inventory(defines.inventory.assembling_machine_modules)
				modules.insert{name="speed-module-3", count=10}
				local outinv = e.get_inventory(defines.inventory.assembling_machine_output)
				outinv.clear()				
			end
		end
	end
	shout ("Terraformers filled with ingredients :-)")
end

function remote_give_tf()
	for _, p in pairs(game.players) do
		p.insert{name="bridge-builder", count=2}
		p.insert{name="moat-digger", count=2}
		p.insert{name="logistic-bridge-builder", count=2}
		p.insert{name="logistic-moat-digger", count=2}
		p.insert{name="prefabrication-plant", count=5}
		p.insert{name="draw-bridge", count=20}
		p.insert{name="rail-bridge", count=20}
		p.print("Happy Birthday present!")
	end
end

function remote_supply_chests()
	local items={"raw-wood","wood","coal","stone","stone-brick","iron-plate", "copper-plate", "steel-plate",
				 "concrete","iron-axe","plastic-bar","water-barrel","empty-barrel","express-transport-belt"}
	for _, p in pairs(game.players) do
		local s = p.surface
		local pos = p.position
		local x = 0
		local y = 0
		local e
		for _, i in pairs(items) do
			x = x + 1; if (x % 11) == 0 then x = 1; y = y + 1 end
			e = s.create_entity{name="logistic-chest-storage", position=addpos(pos,{x=x,y=y}), force=p.force}
			e.insert{name=i,count=10000}
		end

		-- Chest of packages
		x = x + 1
		e = s.create_entity{name="logistic-chest-storage", position=addpos(pos,{x=x,y=y}), force=p.force}
		e.insert{name="ford-package", count=800}
		e.insert{name="stone-bridge-package", count=800}
		e.insert{name="concrete-bridge-package", count=800}
		e.insert{name="moat-package", count=800}
		e.insert{name="stone-moat-package", count=800}
		e.insert{name="concrete-moat-package", count=800}
		
		-- Chests of extra stuff
		x = x + 1
		e = s.create_entity{name="logistic-chest-storage", position=addpos(pos,{x=x,y=y}), force=p.force}
		e.insert{name="bridge-builder", count=2}
		e.insert{name="moat-digger", count=2}
		e.insert{name="logistic-bridge-builder", count=2}
		e.insert{name="logistic-moat-digger", count=2}
		e.insert{name="prefabrication-plant", count=5}
		e.insert{name="draw-bridge", count=20}
		e.insert{name="rail-bridge", count=20}			
		e.insert{name="steel-axe", count=20}
		e.insert{name="steel-chest",count=50}; 
		e.insert{name="fast-inserter",count=100}; 
		e.insert{name="long-handed-inserter",count=50};
		e.insert{name="assembling-machine-3", count=50}
		e.insert{name="steel-furnace", count=50}
		e.insert{name="speed-module",count=50};
		e.insert{name="speed-module-2",count=50};
		e.insert{name="speed-module-3",count=50};
		e.insert{name="solar-panel",count=200};
		e.insert{name="basic-accumulator",count=200}; 
		e.insert{name="substation",count=100}; 
		e.insert{name="medium-electric-pole",count=100};
		e.insert{name="offshore-pump",count=20}; 
		e.insert{name="boiler",count=50}; 
		e.insert{name="steam-engine",count=50}; 

		x = x + 1
		e = s.create_entity{name="logistic-chest-storage", position=addpos(pos,{x=x,y=y}), force=p.force}
		e.insert{name="car",count=5};
		e.insert{name="tank",count=5};
		e.insert{name="pipe",count=100}; 
		e.insert{name="pipe-to-ground",count=100};
		e.insert{name="express-transport-belt-to-ground",count=200};
		e.insert{name="express-splitter",count=200};

		x = x + 1
		e = s.create_entity{name="logistic-chest-storage", position=addpos(pos,{x=x,y=y}), force=p.force}
		e.insert{name="diesel-locomotive",count=5};
		e.insert{name="cargo-wagon",count=5};
		e.insert{name="straight-rail",count=1000};
		e.insert{name="curved-rail",count=1000};
		e.insert{name="train-stop",count=50};
		e.insert{name="rail-signal",count=200};
		e.insert{name="rail-chain-signal",count=200};

		x = x + 1
		e = s.create_entity{name="logistic-chest-storage", position=addpos(pos,{x=x,y=y}), force=p.force}
		e.insert{name="roboport",count=15}; 
		e.insert{name="construction-robot",count=300}; 
		e.insert{name="logistic-robot",count=300}; 
		e.insert{name="logistic-chest-storage",count=50}; 
		e.insert{name="logistic-chest-requester",count=50}; 
		e.insert{name="logistic-chest-passive-provider",count=50}; 
		e.insert{name="logistic-chest-active-provider",count=50}; 
		e.insert{name="blueprint",count=20}; 
		e.insert{name="deconstruction-planner",count=5};
		e.insert{name="fusion-reactor-equipment",count=10}; 
		e.insert{name="power-armor-mk2",count=2}; 
		e.insert{name="personal-roboport-equipment",count=5};

		p.print("Supplies delivered!")
	end
end