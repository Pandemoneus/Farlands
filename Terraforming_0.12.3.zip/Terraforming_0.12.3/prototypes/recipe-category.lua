data:extend(
{
	{
		type = "recipe-category",
		name = "terraforming",
	},
	
	{
		type = "recipe-category",
		name = "digging",
	},	
	
	{
		type = "recipe-category",
		name = "prefabrication",
	},
})
