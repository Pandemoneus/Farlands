MOD_VERSION = "0.12.3"		-- Mod version number
BASE_CRAFTING_SPEED = 0.5	-- Affects all terraforming machines (default is 0.5)
FUEL_INVENTORY_SIZE = 2		-- Affects normal bridge builder and moat digger only (default is 2)
MODULE_SLOTS = 2			-- Affects basic & prefabrication terraforming machines (default is 2)
LOGISTIC_MODULE_SLOTS = 3	-- Affects logistics terraforming machines (default is 3)
LOGISTIC_RECIPE_COUNT = 5	-- How many multiples of recipe to order at once via logistics

debug = false				-- Enable printing of debug messages
if debug then
	BASE_CRAFTING_SPEED = 10
end