if reach_mod then
	data.raw.player.player.build_distance = 12 
	data.raw.player.player.reach_distance = 10 
end