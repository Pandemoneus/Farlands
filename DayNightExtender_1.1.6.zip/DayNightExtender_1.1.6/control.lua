-- debug_status = 1
debug_mod_name = "DayNightExtender"
debug_file = debug_mod_name .. "-debug.txt"
require("utils")
require("config")


--------------------------------------------------------------------------------------
local function init_globals()
	-- initialize or update general globals of the mod
	debug_print( "init_globals" )
	
	global.counter = global.counter or 0

	if global.freeze_state == nil then global.freeze_state = false end
end

--------------------------------------------------------------------------------------
local function on_init() 
	-- called once, the first time the mod is loaded on a game (new or existing game)
	debug_print( "on_init" )
	
	init_globals()
end

script.on_init(on_init)

--------------------------------------------------------------------------------------
local function on_configuration_changed(data)
	-- detect any mod or game version change
	if data.mod_changes ~= nil then
		local changes = data.mod_changes[debug_mod_name]
		if changes ~= nil then
			debug_print( "update mod: ", debug_mod_name, " ", tostring(changes.old_version), " to ", tostring(changes.new_version) )
		
			init_globals()
		end
	end
end

script.on_configuration_changed(on_configuration_changed)

--------------------------------------------------------------------------------------
local function on_tick(event)
	if game.tick % 14 == 0 then
		for _, surf in pairs(game.surfaces) do
			if global.counter == 0 then
				if not surf.always_day then
					surf.freeze_daytime(false)
				end
			elseif global.counter == 1 then
				if not surf.always_day then
					surf.freeze_daytime(true)
				end
			end
		end
		
		global.counter = global.counter + 1
		if global.counter >= day_length_multiplier then
			global.counter = 0
		end
	end
end

script.on_event(defines.events.on_tick, on_tick)

