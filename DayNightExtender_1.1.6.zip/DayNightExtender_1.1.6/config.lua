day_length_multiplier = 4 

-- (integer) Controls how long daytime will be. 
-- Set to 1 for default vanilla length (7 minutes full day/night cycle).
-- With 4, it gives a 28 mins cycle.
