table.insert(
    data.raw["technology"]["automated-construction"]["effects"],
    { type = "unlock-recipe", recipe = "upgrade-planner" }
)

