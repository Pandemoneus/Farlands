data:extend({
    {
        type = "deconstruction-item",
        name = "upgrade-planner",
        icon = "__upgrade-planner__/graphics/icons/upgrade-planner.png",
        flags = {"goes-to-quickbar"},
        subgroup = "tool",
        order = "c[automated-construction]-c[upgrade-planner]",
        selection_color = { r = 1, g = 0, b = 0 },
        alt_selection_color = { r = 1, g = 0, b = 0 },
        selection_mode = {"blueprint"},
        alt_selection_mode = {"blueprint"},
        selection_cursor_box_type = "copy",
        alt_selection_cursor_box_type = "copy",
        stack_size = 1
    }
})
