data:extend(
{
  {
    type = "recipe",
    name = "grabber-equipment",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      {"processing-unit", 8},
      {"long-handed-inserter", 16},
      {"steel-plate", 16},
    },
    result = "grabber-equipment"
  }
}
)
