require("prototypes.item")
require("prototypes.equipment")
require("prototypes.recipe")
require("prototypes.technology")