data:extend({
    {
        type = "font",
        name = "upgrade-planner-small-font",
        from = "default",
        size = 14
    }
})

data.raw["gui-style"].default["upgrade-planner-small-button"] = {
    type = "button_style",
    parent = "button_style",
    font = "upgrade-planner-small-font"
}

data.raw["gui-style"].default["upgrade-planner-menu-button"] = {
    type = "button_style",
    parent = "button_style",
    font = "upgrade-planner-small-font"
}


data.raw["gui-style"].default["upgrade-planner-menu-button"] =
  {
    type = "button_style",
    parent = "button_style",
    width = 33,
    height = 33,
    top_padding = 6,
    right_padding = 6,
    bottom_padding = 6,
    left_padding = 6,
    font = "upgrade-planner-small-font",
    default_graphical_set =
    {
      type = "monolith",
      monolith_image =
      {
        filename = "__upgrade-planner__/gui-button.png",
        priority = "extra-high-no-scale",
        width = 64,
        height = 64,
        
      }
    },
    hovered_graphical_set =
    {
      type = "monolith",
      monolith_image =
      {
        filename = "__upgrade-planner__/gui-highlight.png",
        priority = "extra-high-no-scale",
        width = 64,
        height = 64,
        
      }
    },
    clicked_graphical_set =
    {
      type = "monolith",
      monolith_image =
      {
        filename = "__upgrade-planner__/gui-button.png",
        width = 64,
        height = 64,
        
      }
    }
  }