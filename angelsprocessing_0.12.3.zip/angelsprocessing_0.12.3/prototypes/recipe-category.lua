data:extend(
{
  {
    type = "recipe-category",
    name = "ore-processing",
  },
  {
    type = "recipe-category",
    name = "blast-smelting",
  },
  {
    type = "recipe-category",
    name = "bio-processing",
  },
  {
    type = "item-group",
    name = "resource-processing",
    order = "aaa-a",
    inventory_order = "c-a",
    icon = "__angelsprocessing__/graphics/item-group/ore-processing-plant.png",
	icon_size = 64,
  },
  {
    type = "item-subgroup",
    name = "ore-processing",
	group = "resource-processing",
	order = "a-l",
  },
  {
    type = "item-subgroup",
    name = "ingot-smelting",
	group = "resource-processing",
	order = "b-f",
  },
  {
    type = "item-subgroup",
    name = "plate-from-ingot",
	group = "resource-processing",
	order = "c-f",
  },
  {
    type = "item-subgroup",
    name = "bob-plate-from-processed",
	group = "resource-processing",
	order = "d-f",
  },
  {
    type = "item-subgroup",
    name = "bob-plate-from-ingot",
	group = "resource-processing",
	order = "e-f",
  },
    {
    type = "item-subgroup",
    name = "ore-compressing",
	group = "resource-processing",
	order = "f-f",
  },
  {
    type = "item-subgroup",
    name = "bio-processing",
	group = "resource-processing",
	order = "f-f",
  },
  }
  )
