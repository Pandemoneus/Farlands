data:extend(
{
--TIN
    {
    type = "item",
    name = "compressed-tin-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-tin-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "d-c[compressed-tin-ore]",
    stack_size = 200
    },
  --GOLD
    {
    type = "item",
    name = "compressed-gold-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-gold-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "d-d[compressed-gold-ore]",
    stack_size = 200
    },

  --BAUXITE
    {
    type = "item",
    name = "compressed-bauxite-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-bauxite-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "d-e[compressed-bauxite-ore]",
    stack_size = 200
    },
  --LEAD
    {
    type = "item",
    name = "compressed-lead-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-lead-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "d-f[compressed-lead-ore]",
    stack_size = 200
    },

  --QUARTZ
    {
    type = "item",
    name = "compressed-quartz",
    icon = "__angelsprocessing__/graphics/icons/compressed-quartz.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "d-g[compressed-quartz]",
    stack_size = 200
    },
  
  --RUTILE/TITANIUM
    {
    type = "item",
    name = "compressed-rutile-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-rutile-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "d-h[compressed-rutile-ore]",
    stack_size = 200
    },
 --TUNGSTEN
    {
    type = "item",
    name = "compressed-tungsten-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-tungsten-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "d-i[compressed-tungsten-ore]",
    stack_size = 200
    },
  --ZINC
    {
    type = "item",
    name = "compressed-zinc-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-zinc-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "d-j[compressed-zinc-ore]",
    stack_size = 200
    },
  --SILVER
    {
    type = "item",
    name = "compressed-silver-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-silver-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "d-k[compressed-silver-ore]",
    stack_size = 200
    },

    --COBALT
    {
    type = "item",
    name = "compressed-cobalt-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-cobalt-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "d-l[compressed-cobalt-ore]",
    stack_size = 200
    },
    --NICKEL
    {
    type = "item",
    name = "compressed-nickel-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-nickel-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "d-j[compressed-nickel-ore]",
    stack_size = 200
    },
  
 }
)