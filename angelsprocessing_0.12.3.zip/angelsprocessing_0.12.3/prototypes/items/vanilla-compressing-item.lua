data:extend(
{
--IRON
  {
    type = "item",
    name = "compressed-iron-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-iron-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-compressing",
    order = "d-a[compressed-iron-ore]",
    stack_size = 200
  },
  --COPPER
  {
    type = "item",
    name = "compressed-copper-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-copper-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-compressing",
    order = "d-b[compressed-copper-ore]",
    stack_size = 200
  },
    --COAL
  {
    type = "item",
    name = "compressed-coal",
    icon = "__angelsprocessing__/graphics/icons/compressed-coal.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-compressing",
    order = "d-c[compressed-coal]",
    stack_size = 200
  },
    --STONE
  {
    type = "item",
    name = "compressed-stone",
    icon = "__angelsprocessing__/graphics/icons/compressed-stone.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-compressing",
    order = "d-d[compressed-stone]",
    stack_size = 200
  },

}
)