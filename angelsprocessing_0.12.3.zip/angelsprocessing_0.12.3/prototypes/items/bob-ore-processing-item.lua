data:extend(
{
--TIN
  {
    type = "item",
    name = "processed-tin-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-tin-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "a-c[processed-tin-ore]",
    stack_size = 200
  },
    {
    type = "item",
    name = "tin-ingot",
    icon = "__angelsprocessing__/graphics/icons/tin-ingot.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ingot-smelting",
    order = "b-c[tin-ingot]",
    stack_size = 200
  },
  --GOLD
    {
    type = "item",
    name = "processed-gold-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-gold-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "a-d[processed-gold-ore]",
    stack_size = 200
  },
    {
    type = "item",
    name = "gold-ingot",
    icon = "__angelsprocessing__/graphics/icons/gold-ingot.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ingot-smelting",
    order = "b-d[gold-ingot]",
    stack_size = 200
  },
  --BAUXITE
    {
    type = "item",
    name = "processed-bauxite-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-bauxite-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "a-e[processed-bauxite-ore]",
    stack_size = 200
  },
  --LEAD
    {
    type = "item",
    name = "processed-lead-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-lead-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "a-f[processed-lead-ore]",
    stack_size = 200
  },
    {
    type = "item",
    name = "lead-ingot",
    icon = "__angelsprocessing__/graphics/icons/lead-ingot.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ingot-smelting",
    order = "b-e[lead-ingot]",
    stack_size = 200
  },
  --QUARTZ
    {
    type = "item",
    name = "processed-quartz",
    icon = "__angelsprocessing__/graphics/icons/processed-quartz.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "a-g[processed-quartz]",
    stack_size = 200
  },
  
  --RUTILE/TITANIUM
     {
    type = "item",
    name = "processed-rutile-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-rutile-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "a-h[processed-rutile-ore]",
    stack_size = 200
  },
 --TUNGSTEN
     {
    type = "item",
    name = "processed-tungsten-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-tungsten-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "a-i[processed-tungsten-ore]",
    stack_size = 200
  },
  --ZINC
     {
    type = "item",
    name = "processed-zinc-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-zinc-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "a-j[processed-zinc-ore]",
    stack_size = 200
  },
  --SILVER
     {
    type = "item",
    name = "processed-silver-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-silver-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "a-k[processed-silver-ore]",
    stack_size = 200
  },
  {
    type = "item",
    name = "silver-ingot",
    icon = "__angelsprocessing__/graphics/icons/silver-ingot.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ingot-smelting",
    order = "b-f[silver-ingot]",
    stack_size = 200
  },
    --COBALT
  {
    type = "item",
    name = "processed-cobalt-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-cobalt-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "a-l[processed-cobalt-ore]",
    stack_size = 200
  },
    --NICKEL
  {
    type = "item",
    name = "processed-nickel-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-nickel-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "a-j[processed-nickel-ore]",
    stack_size = 200
  },
  
 }
)