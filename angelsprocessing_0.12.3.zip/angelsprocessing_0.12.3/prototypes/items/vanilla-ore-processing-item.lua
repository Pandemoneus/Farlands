data:extend(
{
--IRON
  {
    type = "item",
    name = "processed-iron-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-iron-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "a-a[processed-iron-ore]",
    stack_size = 200
  },
  {
    type = "item",
    name = "iron-ingot",
    icon = "__angelsprocessing__/graphics/icons/iron-ingot.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ingot-smelting",
    order = "b-a[iron-ingot]",
    stack_size = 200
  },
  --COPPER
  {
    type = "item",
    name = "processed-copper-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-copper-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ore-processing",
    order = "a-b[processed-copper-ore]",
    stack_size = 200
  },
  {
    type = "item",
    name = "copper-ingot",
    icon = "__angelsprocessing__/graphics/icons/copper-ingot.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "ingot-smelting",
    order = "b-b[copper-ingot]",
    stack_size = 200
  },
}
)