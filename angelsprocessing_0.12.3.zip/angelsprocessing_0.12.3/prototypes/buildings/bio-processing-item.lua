data:extend(
{
  {
    type = "item",
    name = "bio-processing-plant",
    icon = "__angelsprocessing__/graphics/icons/bio-processing-plant.png",
    flags = {"goes-to-quickbar"},
    subgroup = "bio-processing",
    order = "a[bio-processing-plant]",
    place_result = "bio-processing-plant",
    stack_size = 10,
  },
  }
  )