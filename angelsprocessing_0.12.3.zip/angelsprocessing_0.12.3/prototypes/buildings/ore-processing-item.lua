data:extend(
{
{
    type = "item",
    name = "ore-processing-plant",
    icon = "__angelsprocessing__/graphics/icons/ore-processing-plant.png",
	flags = {"goes-to-quickbar"},
    subgroup = "ore-processing",
    order = "a[ore-processing-plant]",
    place_result = "ore-processing-plant",
    stack_size = 10,
  },
  {
    type = "item",
    name = "blast-furnace",
    icon = "__angelsprocessing__/graphics/icons/blast-furnace.png",
    flags = {"goes-to-quickbar"},
    subgroup = "ore-processing",
    order = "a[blast-furnace]",
    place_result = "blast-furnace",
    stack_size = 10,
  },
  }
  )