data:extend(
{
--IRON
{
    type = "recipe",
    name = "iron-ore-processing",
    category = "ore-processing",
	subgroup = "ore-processing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"iron-ore", 4}},
    results=
    {
      {type="item", name="processed-iron-ore", amount=4},
      {type="item", name="stone", amount=1}
    },
    main_product= "processed-iron-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-iron-ore.png",
    order = "a-a [processed-iron-ore]",
  },
  {
    type = "recipe",
    name = "processed-iron-ore-smelting",
    category = "blast-smelting",
	subgroup = "ingot-smelting",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"processed-iron-ore", 3}},
    results=
    {
      {type="item", name="iron-ingot", amount=4},
    },
    main_product= "iron-ingot",
    icon = "__angelsprocessing__/graphics/icons/iron-ingot.png",
    order = "b-a [iron-ingot]",
  },
  {
    type = "recipe",
    name = "iron-ingot-smelting",
    category = "smelting",
	subgroup = "plate-from-ingot",
    energy_required = 1,
	enabled = "false",
    ingredients ={{"iron-ingot", 1}},
    results=
    {
      {type="item", name="iron-plate", amount=2},
    },
    main_product= "iron-plate",
    icon = "__angelsprocessing__/graphics/icons/iron-plate-ingot.png",
    order = "c-a [iron-plate-ingot]",
  },
    {
    type = "recipe",
    name = "steel-from-ingot",
    category = "smelting",
	subgroup = "plate-from-ingot",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"iron-ingot", 1}},
    results=
    {
      {type="item", name="steel-plate", amount=2},
    },
    main_product= "steel-plate",
    icon = "__angelsprocessing__/graphics/icons/steel-plate-ingot.png",
    order = "c-a [steel-plate-from-ingot]",
  },
  
 --COPPER
  {
    type = "recipe",
    name = "copper-ore-processing",
    category = "ore-processing",
	subgroup = "ore-processing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"copper-ore", 4}},
    results=
    {
      {type="item", name="processed-copper-ore", amount=4},
      {type="item", name="stone", amount=1}
    },
    main_product= "processed-copper-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-copper-ore.png",
    order = "a-b [processed-copper-ore]",
  },
  {
    type = "recipe",
    name = "processed-copper-ore-smelting",
    category = "blast-smelting",
	subgroup = "ingot-smelting",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"processed-copper-ore", 3}},
    results=
    {
      {type="item", name="copper-ingot", amount=4},
    },
    main_product= "copper-ingot",
    icon = "__angelsprocessing__/graphics/icons/copper-ingot.png",
    order = "b-b [copper-ingot]",
  },
  {
    type = "recipe",
    name = "copper-ingot-smelting",
    category = "smelting",
	subgroup = "plate-from-ingot",
    energy_required = 1,
	enabled = "false",
    ingredients ={{"copper-ingot", 1}},
    results=
    {
      {type="item", name="copper-plate", amount=2},
    },
    main_product= "copper-plate",
    icon = "__angelsprocessing__/graphics/icons/copper-plate-ingot.png",
    order = "c-b [copper-plate-ingot]",
  },
  }
  )