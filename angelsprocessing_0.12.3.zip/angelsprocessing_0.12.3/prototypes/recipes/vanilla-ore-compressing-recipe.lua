data:extend(
{
--IRON
{
    type = "recipe",
    name = "iron-ore-compressing",
    category = "ore-processing",
	subgroup = "ore-compressing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"iron-ore", 20}},
    results=
    {
      {type="item", name="compressed-iron-ore", amount=1},
      {type="item", name="stone", amount=5}
    },
    main_product= "compressed-iron-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-iron-ore.png",
    order = "d-a [compressed-iron-ore]",
  },
  
 --COPPER
{
    type = "recipe",
    name = "copper-ore-compressing",
    category = "ore-processing",
	subgroup = "ore-compressing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"copper-ore", 20}},
    results=
    {
      {type="item", name="compressed-copper-ore", amount=1},
      {type="item", name="stone", amount=5}
    },
    main_product= "compressed-copper-ore",
    icon = "__angelsprocessing__/graphics/icons/compressed-copper-ore.png",
    order = "d-a [compressed-copper-ore]",
  },
  
   --COAL
{
    type = "recipe",
    name = "coal-compressing",
    category = "ore-processing",
	subgroup = "ore-compressing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"coal", 20}},
    results=
    {
      {type="item", name="compressed-coal", amount=1},
    },
    main_product= "compressed-coal",
    icon = "__angelsprocessing__/graphics/icons/compressed-coal.png",
    order = "d-a [compressed-coal]",
  },
  
   --COPPER
{
    type = "recipe",
    name = "stone-compressing",
    category = "ore-processing",
	subgroup = "ore-compressing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"stone", 20}},
    results=
    {
      {type="item", name="compressed-stone", amount=1},
    },
    main_product= "compressed-stone",
    icon = "__angelsprocessing__/graphics/icons/compressed-stone.png",
    order = "d-a [compressed-stone]",
  },

  }
  )