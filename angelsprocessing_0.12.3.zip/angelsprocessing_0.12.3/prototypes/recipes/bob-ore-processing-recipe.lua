data:extend(
{
--TIN
  {
    type = "recipe",
    name = "tin-ore-processing",
    category = "ore-processing",
	subgroup = "ore-processing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"tin-ore", 4}},
    results=
    {
      {type="item", name="processed-tin-ore", amount=4},
      {type="item", name="stone", amount=1}
    },
    main_product= "processed-tin-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-tin-ore.png",
    order = "a-c [processed-tin-ore]",
  },
  {
    type = "recipe",
    name = "processed-tin-ore-smelting",
    category = "blast-smelting",
	subgroup = "ingot-smelting",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"processed-tin-ore", 3}},
    results=
    {
      {type="item", name="tin-ingot", amount=4},
    },
    main_product= "tin-ingot",
    icon = "__angelsprocessing__/graphics/icons/tin-ingot.png",
    order = "b-c [tin-ingot]",
  },
  {
    type = "recipe",
    name = "tin-ingot-smelting",
    category = "smelting",
	subgroup = "plate-from-ingot",
    energy_required = 1,
	enabled = "false",
    ingredients ={{"tin-ingot", 2}},
    results=
    {
      {type="item", name="tin-plate", amount=3},
    },
    main_product= "tin-plate",
    icon = "__angelsprocessing__/graphics/icons/tin-plate-ingot.png",
    order = "c-c [tin-plate-ingot]",
  },
  --GOLD
    {
    type = "recipe",
    name = "gold-ore-processing",
    category = "ore-processing",
	subgroup = "ore-processing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"gold-ore", 4}},
    results=
    {
      {type="item", name="processed-gold-ore", amount=4},
      {type="item", name="stone", amount=1}
    },
    main_product= "processed-gold-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-gold-ore.png",
    order = "a-d [processed-gold-ore]",
  },
  {
    type = "recipe",
    name = "bob-gold-plate-from-processed",
    category = "chemical-furnace",
    subgroup = "bob-plate-from-processed",
    energy_required = 3.5,
	enabled = "false",
    ingredients =
    {
      {type="item", name="processed-gold-ore", amount=2},
      {type="fluid", name="chlorine", amount=1}
    },
    results=
	{
      {type="item", name="gold-plate", amount=3},
    },
	main_product= "gold-plate",
	icon = "__angelsprocessing__/graphics/icons/gold-plate-processed.png",
    order = "c-e [gold-plate-from-processed]",
  },
    --BAUXITE
    {
    type = "recipe",
    name = "bauxite-ore-processing",
    category = "ore-processing",
	subgroup = "ore-processing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"bauxite-ore", 4}},
    results=
    {
      {type="item", name="processed-bauxite-ore", amount=4},
      {type="item", name="stone", amount=1}
    },
    main_product= "processed-bauxite-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-bauxite-ore.png",
    order = "a-e [processed-bauxite-ore]",
  },
  {
    type = "recipe",
    name = "alumina-from-processed",
    category = "chemical-furnace",
    subgroup = "bob-plate-from-processed",
    energy_required = 2,
	enabled = "false",
    ingredients =
    {
      {type="item", name="sodium-hydroxide", amount=1},
      {type="item", name="processed-bauxite-ore", amount=2},
    },
    results=
	{
      {type="item", name="alumina", amount=3},
    },
	icon = "__angelsprocessing__/graphics/icons/corundum-processed.png",
    order = "f[alumina]"
  },
   --LEAD
    {
    type = "recipe",
    name = "lead-ore-processing",
    category = "ore-processing",
	subgroup = "ore-processing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"lead-ore", 4}},
    results=
    {
      {type="item", name="processed-lead-ore", amount=4},
      {type="item", name="stone", amount=1}
    },
    main_product= "processed-lead-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-lead-ore.png",
    order = "a-f [processed-lead-ore]",
  },
  {
    type = "recipe",
    name = "processed-lead-ore-smelting",
    category = "blast-smelting",
	subgroup = "ingot-smelting",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"processed-lead-ore", 3}},
    results=
    {
      {type="item", name="lead-ingot", amount=4},
    },
    main_product= "lead-ingot",
    icon = "__angelsprocessing__/graphics/icons/lead-ingot.png",
    order = "b-e [lead-ingot]",
  },
  {
    type = "recipe",
    name = "lead-ingot-smelting",
    category = "smelting",
	subgroup = "plate-from-ingot",
    energy_required = 1,
	enabled = "false",
    ingredients ={{"lead-ingot", 2}},
    results=
    {
      {type="item", name="lead-plate", amount=3},
    },
    main_product= "lead-plate",
    icon = "__angelsprocessing__/graphics/icons/lead-plate-ingot.png",
    order = "c-e [lead-plate-ingot]",
  },
  {
    type = "recipe",
    name = "lead-oxide-processed",
    category = "chemistry",
    subgroup = "bob-plate-from-processed",
    enabled = "false",
    energy_required = 2,
    ingredients =
    {
      {type="item", name="processed-lead-ore", amount=2},
      {type="fluid", name="oxygen", amount=1.5},
    },
    results=
    {
      {type="item", name="lead-oxide", amount=3},
      {type="fluid", name="sulfur-dioxide", amount=1},
    },
    main_product= "lead-oxide",
    icon = "__angelsprocessing__/graphics/icons/lead-oxide-processed.png",
    order = "f[lead-oxide-processed]"
  },
   --RUTILE
    {
    type = "recipe",
    name = "rutile-ore-processing",
    category = "ore-processing",
	subgroup = "ore-processing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"rutile-ore", 4}},
    results=
    {
      {type="item", name="processed-rutile-ore", amount=4},
      {type="item", name="stone", amount=1}
    },
    main_product= "processed-rutile-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-rutile-ore.png",
    order = "a-g [processed-rutile-ore]",
  },
  {
    type = "recipe",
    name = "bob-titanium-plate-from-processed",
    category = "electrolysis",
    subgroup = "bob-plate-from-processed",
    energy_required = 7,
	enabled = "false",
    ingredients =
    {
      {type="item", name="calcium-chloride", amount=2},
      {type="item", name="carbon", amount=1},
      {type="item", name="processed-rutile-ore", amount=2}
    },
    result = "titanium-plate",
    result_count = 3,
	icon = "__angelsprocessing__/graphics/icons/titanium-plate-processed.png",
    order = "a-g [titanium-plate-processed]",
  },
   --TUNGSTEN
    {
    type = "recipe",
    name = "tungsten-ore-processing",
    category = "ore-processing",
	subgroup = "ore-processing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"tungsten-ore", 4}},
    results=
    {
      {type="item", name="processed-tungsten-ore", amount=4},
      {type="item", name="stone", amount=1}
    },
    main_product= "processed-tungsten-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-tungsten-ore.png",
    order = "a-h [processed-tungsten-ore]",
  },
    {
    type = "recipe",
    name = "tungstic-acid-from-processed",
    category = "chemistry",
    enabled = "false",
    energy_required = 2,
    ingredients =
    {
      {type="item", name="processed-tungsten-ore", amount=2},
      {type="fluid", name="hydrogen-chloride", amount=4}
    },
    results=
    {
      {type="fluid", name="tungstic-acid", amount=3},
      {type="item", name="calcium-chloride", amount=1}
    },
    main_product= "tungstic-acid",
    subgroup = "bob-plate-from-processed",
    icon = "__angelsprocessing__/graphics/icons/tungstic-acid-processed.png",
    order = "b[fluid-chemistry]-b[tungstic-acid-processed]"
  },
   --ZINC
    {
    type = "recipe",
    name = "zinc-ore-processing",
    category = "ore-processing",
	subgroup = "ore-processing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"zinc-ore", 4}},
    results=
    {
      {type="item", name="processed-zinc-ore", amount=4},
      {type="item", name="stone", amount=1}
    },
    main_product= "processed-zinc-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-zinc-ore.png",
    order = "a-i [processed-zinc-ore]",
  },
  {
    type = "recipe",
    name = "bob-zinc-plate-from-processed",
    category = "electrolysis",
    subgroup = "bob-plate-from-processed",
    energy_required = 3.5,
	enabled = "false",
    ingredients =
    {
      {type="item", name="processed-zinc-ore", amount=2},
      {type="fluid", name="sulfuric-acid", amount=1}
    },
    results=
	{
      {type="item", name="zinc-plate", amount=3},
    },
    icon = "__angelsprocessing__/graphics/icons/zinc-plate-processed.png",
    order = "a-i [zinc-plate-processed]",
  },
   --SILVER
    {
    type = "recipe",
    name = "silver-ore-processing",
    category = "ore-processing",
	subgroup = "ore-processing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"silver-ore", 4}},
    results=
    {
      {type="item", name="processed-silver-ore", amount=4},
      {type="item", name="stone", amount=1}
    },
    main_product= "processed-silver-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-silver-ore.png",
    order = "a-j [processed-silver-ore]",
  },
    {
    type = "recipe",
    name = "processed-silver-ore-smelting",
    category = "blast-smelting",
	subgroup = "ingot-smelting",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"processed-silver-ore", 3}},
    results=
    {
      {type="item", name="silver-ingot", amount=4},
    },
    main_product= "silver-ingot",
    icon = "__angelsprocessing__/graphics/icons/silver-ingot.png",
    order = "b-f [silver-ingot]",
  },
  {
    type = "recipe",
    name = "silver-ingot-smelting",
    category = "smelting",
	subgroup = "plate-from-ingot",
    energy_required = 1,
	enabled = "false",
    ingredients ={{"silver-ingot", 2}},
    results=
    {
      {type="item", name="silver-plate", amount=3},
    },
    main_product= "silver-plate",
    icon = "__angelsprocessing__/graphics/icons/silver-plate-ingot.png",
    order = "c-f [silver-plate-ingot]",
  },
  {
    type = "recipe",
    name = "silver-nitrate-from-ingot",
    category = "chemistry",
    subgroup = "bob-plate-from-ingot",
    energy_required = 5,
	enabled = "false",
    ingredients =
    {
      {type="item", name="silver-ingot", amount=2},
      {type="fluid", name="nitrogen-dioxide", amount=1},
    },
    results=
	{
      {type="item", name="silver-nitrate", amount=3},
    },
	icon = "__angelsprocessing__/graphics/icons/silver-nitrate-ingot.png",
    order = "c-f [silver-nitrate-ingot]",
  },
   --COBALT
    {
    type = "recipe",
    name = "cobalt-ore-processing",
    category = "ore-processing",
	subgroup = "ore-processing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"cobalt-ore", 4}},
    results=
    {
      {type="item", name="processed-cobalt-ore", amount=4},
      {type="item", name="stone", amount=1}
    },
    main_product= "processed-cobalt-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-cobalt-ore.png",
    order = "a-k [processed-cobalt-ore]",
  },
  {
    type = "recipe",
    name = "cobalt-oxide-from-processed",
    category = "chemical-furnace",
    subgroup = "bob-plate-from-processed",
    energy_required = 7,
    enabled = "false",
    ingredients =
    {
      {type="item", name="processed-cobalt-ore", amount=2},
      {type="item", name="stone", amount=1}
    },
    result="cobalt-oxide",
    result_count = 3,
	icon = "__angelsprocessing__/graphics/icons/cobalt-oxide-processed.png",
    order = "c-b[cobalt-oxide-from-processed]"
  },
  {
    type = "recipe",
    name = "cobalt-oxide-from-processed-copper",
    category = "chemical-furnace",
    subgroup = "bob-plate-from-processed",
    energy_required = 25,
    enabled = "false",
    ingredients =
    {
      {type = "item", name = "processed-copper-ore", amount = 5},
      {type = "item", name = "stone", amount = 1},
      {type = "item", name = "coal", amount = 1},
      {type = "fluid", name = "hydrogen", amount = 1},
    },
    results=
    {
      {type = "item", name = "copper-plate", amount = 10},
      {type = "item", name = "cobalt-oxide", amount = 2},
    },
    main_product= "copper-plate",
    icon = "__angelsprocessing__/graphics/icons/copper-cobalt-oxide-processed.png",
    order = "c-b[cobalt-oxide-from-processed-copper]"
  },
   --QUARTZ
    {
    type = "recipe",
    name = "quartz-processing",
    category = "ore-processing",
	subgroup = "ore-processing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"quartz", 4}},
    results=
    {
      {type="item", name="processed-quartz", amount=4},
      {type="item", name="stone", amount=1}
    },
    main_product= "processed-quartz",
    icon = "__angelsprocessing__/graphics/icons/processed-quartz.png",
    order = "a-b [processed-quartz]",
  },
  {
    type = "recipe",
    name = "quartz-glass-from-processed",
    category = "smelting",
    subgroup = "bob-plate-from-processed",
    energy_required = 7,
	enabled = "false",
    ingredients =
    {
      {"processed-quartz", 3},
    },
    results=
	{
      {type="item", name="glass", amount=4},
    },
	icon = "__angelsprocessing__/graphics/icons/glas-processed.png",
    order = "a-a [glas-processed]",
  },
  {
    type = "recipe",
    name = "bob-silicon-plate-from-processed",
    category = "electrolysis",
    subgroup = "bob-plate-from-processed",
    energy_required = 7,
	enabled = "false",
    ingredients =
    {
      {type="item", name="calcium-chloride", amount=2},
      {type="item", name="carbon", amount=1},
      {type="item", name="processed-quartz", amount=2}
    },
    results=
	{
      {type="item", name="silicon", amount=3},
    },
	icon = "__angelsprocessing__/graphics/icons/silicon-plate-processed.png",
    order = "c-a-f[silicon-plate-processed]",
  },
  --NICKEL
  {
    type = "recipe",
    name = "nickel-processing",
    category = "ore-processing",
	subgroup = "ore-processing",
    energy_required = 4,
	enabled = "false",
    ingredients ={{"nickel-ore", 4}},
    results=
    {
      {type="item", name="processed-nickel-ore", amount=4},
      {type="item", name="stone", amount=1}
    },
    main_product= "processed-nickel-ore",
    icon = "__angelsprocessing__/graphics/icons/processed-nickel-ore.png",
    order = "a-j [processed-nickel]",
  },
  {
    type = "recipe",
    name = "bob-nickel-plate-from-processed",
    category = "electrolysis",
    subgroup = "bob-plate-from-processed",
    energy_required = 3.5,
	enabled = "false",
    ingredients =
    {
      {type="item", name="processed-nickel-ore", amount=2},
      {type="fluid", name="water", amount=1},
      {type="fluid", name="oxygen", amount=1.5}
    },
    results=
    {
      {type="fluid", name="sulfuric-acid", amount=1},
      {type="item", name="nickel-plate", amount=3}
    },
    main_product= "nickel-plate",
    icon = "__angelsprocessing__/graphics/icons/nickel-plate-processed.png",
    order = "c-a-f[nickel-plate-processed]",
  },
  --ALLOYS
    {
    type = "recipe",
    name = "bronze-alloy-from-ingot",
    category = "mixing-furnace",
	subgroup = "bob-plate-from-ingot",
    energy_required = 17.5,
	enabled = "false",
    ingredients =
    {
      {type="item", name="copper-ingot", amount=3},
      {type="item", name="tin-ingot", amount=1},
    },
    results = 
    {
      {type="item", name="bronze-alloy", amount=5}
    },
	icon = "__angelsprocessing__/graphics/icons/bronze-plate-ingot.png",
    order = "c-a-f[bronze-plate-ingot]",
  },
}
)

if data.raw.recipe["solder-alloy"] then
data:extend(
{
  {
      type = "recipe",
      name = "solder-alloy-from-ingot",
      energy_required = 7,
	  enabled = "false",
      category = "crafting-machine",
	  subgroup = "bob-plate-from-ingot",
      ingredients =
      {
        {"tin-ingot", 5},
        {"copper-ingot", 1},
		{"silver-ingot", 1}
      },
      result = "solder-alloy",
      result_count = 11,
	  icon = "__angelsprocessing__/graphics/icons/solder-plate-silver.png",
      order = "c-a-f[solder-plate-silver]",
    },
	{
        type = "recipe",
        name = "solder-alloy-lead-from-ingot",
        energy_required = 7,
		enabled = "false",
        category = "crafting-machine",
		subgroup = "bob-plate-from-ingot",
        ingredients =
        {
          {"tin-ingot", 2},
          {"lead-ingot", 5},
        },
        result = "solder-alloy",
        result_count = 11,
	    icon = "__angelsprocessing__/graphics/icons/solder-plate-lead.png",
        order = "c-a-f[solder-plate-lead]",
    },
  }
  )
end