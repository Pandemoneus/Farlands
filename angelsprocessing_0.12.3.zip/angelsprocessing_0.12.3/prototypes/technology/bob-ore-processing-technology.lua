data.raw.technology["ore-processing"].order = "c-a1"
data.raw.technology["ore-processing"].effects =
	  {
	  {
        type = "unlock-recipe",
        recipe = "blast-furnace"
      },
      {
        type = "unlock-recipe",
        recipe = "ore-processing-plant"
      },
      {
        type = "unlock-recipe",
        recipe = "iron-ore-processing"
      },
      {
        type = "unlock-recipe",
        recipe = "processed-iron-ore-smelting"
      },
      {
        type = "unlock-recipe",
        recipe = "iron-ingot-smelting"
      },
	  {
        type = "unlock-recipe",
        recipe = "steel-from-ingot"
      },
	  {
        type = "unlock-recipe",
        recipe = "copper-ore-processing"
      },
      {
        type = "unlock-recipe",
        recipe = "processed-copper-ore-smelting"
      },
      {
        type = "unlock-recipe",
        recipe = "copper-ingot-smelting"
      },
	  {
        type = "unlock-recipe",
        recipe = "tin-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "processed-tin-ore-smelting"
      },
	  {
        type = "unlock-recipe",
        recipe = "tin-ingot-smelting"
      },
	  {
        type = "unlock-recipe",
        recipe = "lead-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "processed-lead-ore-smelting"
      },
	  {
        type = "unlock-recipe",
        recipe = "lead-ingot-smelting"
      },
	  {
        type = "unlock-recipe",
        recipe = "silver-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "processed-silver-ore-smelting"
      },
	  {
        type = "unlock-recipe",
        recipe = "silver-ingot-smelting"
      },
	  {
        type = "unlock-recipe",
        recipe = "quartz-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "quartz-glass-from-processed"
      },
	  }

data:extend(
{
{
    type = "technology",
    name = "gold-ore-processing",
    icon = "__angelsprocessing__/graphics/technology/ore-processing-plant-gold.png",
	icon_size = 64,
	prerequisites =
    {
      "gold-processing",
	  "ore-processing",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "gold-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "bob-gold-plate-from-processed"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1}
	  },
      time = 30
    },
    order = "c-a"
  },
  {
    type = "technology",
    name = "bauxite-ore-processing",
    icon = "__angelsprocessing__/graphics/technology/ore-processing-plant-bauxite.png",
	icon_size = 64,
	prerequisites =
    {
      "aluminium-processing",
	  "ore-processing",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "bauxite-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "alumina-from-processed"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1}
	  },
      time = 30
    },
    order = "c-a"
  },
  {
    type = "technology",
    name = "rutile-ore-processing",
    icon = "__angelsprocessing__/graphics/technology/ore-processing-plant-rutile.png",
	icon_size = 64,
	prerequisites =
    {
      "titanium-processing",
	  "ore-processing",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "rutile-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "bob-titanium-plate-from-processed"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1}
	  },
      time = 30
    },
    order = "c-a"
  },
  {
    type = "technology",
    name = "tungsten-ore-processing",
    icon = "__angelsprocessing__/graphics/technology/ore-processing-plant-tungsten.png",
	icon_size = 64,
	prerequisites =
    {
      "tungsten-processing",
	  "ore-processing",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "tungsten-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "tungstic-acid-from-processed"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1}
	  },
      time = 30
    },
    order = "c-a"
  },
  {
    type = "technology",
    name = "zinc-ore-processing",
    icon = "__angelsprocessing__/graphics/technology/ore-processing-plant-zinc.png",
	icon_size = 64,
	prerequisites =
    {
      "zinc-processing",
	  "ore-processing",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "zinc-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "bob-zinc-plate-from-processed"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1}
	  },
      time = 30
    },
    order = "c-a"
  },
  {
    type = "technology",
    name = "silver-nitrate-processing",
    icon = "__angelsprocessing__/graphics/technology/ore-processing-plant-silvernitrate.png",
	icon_size = 64,
	prerequisites =
    {
      "battery-3",
	  "ore-processing",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "silver-nitrate-from-ingot"
      },
	},
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"science-pack-4", 1}
	  },
      time = 30
    },
    order = "c-a"
  },
  {
    type = "technology",
    name = "cobalt-ore-processing",
    icon = "__angelsprocessing__/graphics/technology/ore-processing-plant-cobalt.png",
	icon_size = 64,
	prerequisites =
    {
      "cobalt-processing",
	  "ore-processing",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "cobalt-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "cobalt-oxide-from-processed"
      },
	  {
        type = "unlock-recipe",
        recipe = "cobalt-oxide-from-processed-copper"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  },
      time = 30
    },
    order = "c-a"
  },
  {
    type = "technology",
    name = "bob-silicon-plate-from-processed",
    icon = "__angelsprocessing__/graphics/technology/ore-processing-plant-silicon.png",
	icon_size = 64,
	prerequisites =
    {
      "silicon-processing",
	  "ore-processing",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "bob-silicon-plate-from-processed"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  },
      time = 30
    },
    order = "c-a"
  },
  {
    type = "technology",
    name = "nickel-ore-processing",
    icon = "__angelsprocessing__/graphics/technology/ore-processing-plant-nickel.png",
	icon_size = 64,
	prerequisites =
    {
      "nickel-processing",
	  "ore-processing",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "nickel-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "bob-nickel-plate-from-processed"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  },
      time = 30
    },
    order = "c-a"
  },
}
)

if data.raw.recipe["solder-alloy"] then
data:extend(
{
  {
    type = "technology",
    name = "alloy-processing-1add",
    icon = "__angelsprocessing__/graphics/technology/ore-processing-plant-alloy1.png",
	icon_size = 64,
	prerequisites =
    {
      "alloy-processing-1",
	  "ore-processing",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "bronze-alloy-from-ingot"
      },
	  {
        type = "unlock-recipe",
        recipe = "solder-alloy-from-ingot"
      },
	  {
        type = "unlock-recipe",
        recipe = "solder-alloy-lead-from-ingot"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  },
      time = 30
    },
    order = "c-a"
  },
}
)
end

