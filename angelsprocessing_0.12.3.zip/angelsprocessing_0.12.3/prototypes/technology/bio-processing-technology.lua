data.raw.technology["gold-ore-processing"].effects =
	  {
	  {
        type = "unlock-recipe",
        recipe = "gold-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "bob-gold-plate-from-processed"
      },
      {
        type = "unlock-recipe",
        recipe = "powdered-gold"
      },
	  }
	  
data.raw.technology["rutile-ore-processing"].effects =
	  {
	  {
        type = "unlock-recipe",
        recipe = "rutile-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "bob-titanium-plate-from-processed"
      },
      {
        type = "unlock-recipe",
        recipe = "powdered-rutile"
      },
	  }
	  
data.raw.technology["tungsten-ore-processing"].effects =
	  {
	  {
        type = "unlock-recipe",
        recipe = "tungsten-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "tungstic-acid-from-processed"
      },
      {
        type = "unlock-recipe",
        recipe = "powdered-tungsten"
      },
	  }
	  
data.raw.technology["zinc-ore-processing"].effects =
	  {
	  {
        type = "unlock-recipe",
        recipe = "zinc-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "bob-zinc-plate-from-processed"
      },
      {
        type = "unlock-recipe",
        recipe = "powdered-zinc"
      },
	  }
	  
data.raw.technology["cobalt-ore-processing"].effects =
	  {
	  {
        type = "unlock-recipe",
        recipe = "cobalt-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "cobalt-oxide-from-processed"
      },
	  {
        type = "unlock-recipe",
        recipe = "cobalt-oxide-from-processed-copper"
      },
      {
        type = "unlock-recipe",
        recipe = "powdered-cobalt"
      },
	  }
	  
data.raw.technology["cobalt-ore-processing"].effects =
	  {
	  {
        type = "unlock-recipe",
        recipe = "cobalt-ore-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "cobalt-oxide-from-processed"
      },
	  {
        type = "unlock-recipe",
        recipe = "cobalt-oxide-from-processed-copper"
      },
      {
        type = "unlock-recipe",
        recipe = "powdered-cobalt"
      },
	  }

data:extend(
{
{
    type = "technology",
    name = "bio-processing",
    icon = "__angelsprocessing__/graphics/technology/bio-processing.png",
	icon_size = 64,
	order = "c-a",
	prerequisites =
    {
        "ore-processing",
		"oil-processing",
    },
    effects =
	{
	  {
        type = "unlock-recipe",
        recipe = "bio-processing-plant"
      },
	  {
        type = "unlock-recipe",
        recipe = "algae-farming"
      },
	  {
        type = "unlock-recipe",
        recipe = "cellulose-fiber-algae"
      },
	  {
        type = "unlock-recipe",
        recipe = "wood-from-cellulose"
      },
	  {
        type = "unlock-recipe",
        recipe = "paste"
      },
	  {
        type = "unlock-recipe",
        recipe = "liquid-chlor-methane"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1}
	  },
      time = 30
    },
  },
  {
    type = "technology",
    name = "concrete-processing",
    icon = "__angelsprocessing__/graphics/technology/ore-processing-plant-concrete.png",
	icon_size = 64,
	order = "c-a",
	prerequisites =
    {
	  "ore-processing",
	  "concrete",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "powdered-stone"
      },
	  {
        type = "unlock-recipe",
        recipe = "powdered-iron"
      },
	  {
        type = "unlock-recipe",
        recipe = "concrete-pulver"
      },
	  {
        type = "unlock-recipe",
        recipe = "concrete-brick"
      },
	  {
        type = "unlock-recipe",
        recipe = "concrete-from-pulver"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1}
	  },
      time = 30
    },
  },
    {
    type = "technology",
    name = "alien-bio-processing",
    icon = "__angelsprocessing__/graphics/technology/bio-processing-alien.png",
	icon_size = 64,
	order = "c-a",
	prerequisites =
    {
	  "ore-processing",
	  "alien-technology",
	  "bio-processing",
	  "concrete-processing",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "petri-dish"
      },
	  {
        type = "unlock-recipe",
        recipe = "substrate-dish"
      },
	  {
        type = "unlock-recipe",
        recipe = "alien-pre-artifact"
      },
	  {
        type = "unlock-recipe",
        recipe = "alien-pre-artifact-base"
      },
	  {
        type = "unlock-recipe",
        recipe = "alien-pre-artifact-yellow"
      },
	  {
        type = "unlock-recipe",
        recipe = "alien-pre-artifact-blue"
      },
	  {
        type = "unlock-recipe",
        recipe = "alien-pre-artifact-green"
      },
	  {
        type = "unlock-recipe",
        recipe = "alien-pre-artifact-purple"
      },
 	  {
        type = "unlock-recipe",
        recipe = "alien-pre-artifact-orange"
      },
  	  {
        type = "unlock-recipe",
        recipe = "alien-pre-artifact-red"
      },
	  {
        type = "unlock-recipe",
        recipe = "small-alien-artifact-red"
      },
	  {
        type = "unlock-recipe",
        recipe = "small-alien-artifact-yellow"
      },
	  {
        type = "unlock-recipe",
        recipe = "small-alien-artifact-orange"
      },
	  {
        type = "unlock-recipe",
        recipe = "small-alien-artifact-blue"
      },
	  {
        type = "unlock-recipe",
        recipe = "small-alien-artifact-purple"
      },
	  {
        type = "unlock-recipe",
        recipe = "small-alien-artifact-green"
      },
	  {
        type = "unlock-recipe",
        recipe = "small-alien-artifact"
      },
	  {
        type = "unlock-recipe",
        recipe = "alien-bacteria"
      },
	  {
        type = "unlock-recipe",
        recipe = "alien-goo"
      },
	  {
        type = "unlock-recipe",
        recipe = "powdered-silver"
      },
	  {
        type = "unlock-recipe",
        recipe = "powdered-copper"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  },
      time = 30
    },
  },
}
)


