data:extend(
{
{
    type = "technology",
    name = "ore-compressing",
    icon = "__angelsprocessing__/graphics/technology/ore-processing-plant.png",
	icon_size = 64,
	prerequisites =
    {
      "steel-processing",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "iron-ore-compressing"
      },
      {
        type = "unlock-recipe",
        recipe = "copper-ore-compressing"
      },
      {
        type = "unlock-recipe",
        recipe = "coal-compressing"
      },
      {
        type = "unlock-recipe",
        recipe = "stone-compressing"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1}
	  },
      time = 5
    },
    order = "c-a"
  },
}
)