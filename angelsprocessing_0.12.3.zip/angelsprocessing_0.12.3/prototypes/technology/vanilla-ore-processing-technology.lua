data:extend(
{
{
    type = "technology",
    name = "ore-processing",
    icon = "__angelsprocessing__/graphics/technology/ore-processing-plant.png",
	icon_size = 64,
	order = "c-a",
	prerequisites =
    {
      "steel-processing",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "blast-furnace"
      },
      {
        type = "unlock-recipe",
        recipe = "ore-processing-plant"
      },
      {
        type = "unlock-recipe",
        recipe = "iron-ore-processing"
      },
      {
        type = "unlock-recipe",
        recipe = "processed-iron-ore-smelting"
      },
      {
        type = "unlock-recipe",
        recipe = "iron-ingot-smelting"
      },
	  {
        type = "unlock-recipe",
        recipe = "steel-from-ingot"
      },
	  {
        type = "unlock-recipe",
        recipe = "copper-ore-processing"
      },
      {
        type = "unlock-recipe",
        recipe = "processed-copper-ore-smelting"
      },
      {
        type = "unlock-recipe",
        recipe = "copper-ingot-smelting"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1}
	  },
      time = 5
    },
  },
}
)