--Enables the ore processing technology
angelsmods.processing.enable_ore_processing = true
--Enables the ore compressing technology (not implemented yet)
angelsmods.processing.enable_ore_compressing = false
--Enables the bio processing technology
angelsmods.processing.enable_bio_processing = true