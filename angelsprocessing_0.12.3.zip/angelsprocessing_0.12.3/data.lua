if not angelsmods then angelsmods = {} end
if not angelsmods.processing then angelsmods.processing = {} end
if not bobmods then bobmods = {false} end

require("config")

if angelsmods.processing.enable_ore_processing or angelsmods.processing.enable_bio_processing or angelsmods.processing.enable_ore_compressing then
	require("prototypes.recipe-category")
end


if angelsmods.processing.enable_ore_processing then

	require("prototypes.items.vanilla-ore-processing-item")
	
	if bobmods.ores then 
		require("prototypes.items.bob-ore-processing-item") 
	end

	require("prototypes.buildings.ore-processing-item")
	require("prototypes.buildings.ore-processing-entity")

	require("prototypes.recipes.vanilla-ore-processing-recipe")
	require("prototypes.recipes.ore-processing-entity-recipe")
	
	if bobmods.ores then 
		require("prototypes.recipes.bob-ore-processing-recipe")
	end

	require("prototypes.technology.vanilla-ore-processing-technology")
	
	if bobmods.ores then 
		require("prototypes.technology.bob-ore-processing-technology")
	end 	
end

--if angelsmods.processing.enable_ore_compressing then
--	require("prototypes.recipes.vanilla-ore-compressing-recipe")
--	require("prototypes.items.vanilla-ore-compressing-item")
--	require("prototypes.technology.ore-compression-technology")
--end

if angelsmods.processing.enable_bio_processing and angelsmods.processing.enable_ore_processing and bobmods.ores and bobmods.config.enemies.EnableSmallArtifacts then
	require("prototypes.buildings.bio-processing-item")
	require("prototypes.buildings.bio-processing-entity")

	require("prototypes.recipes.bio-processing-recipe")
	require("prototypes.recipes.bio-processing-entity-recipe")
	require("prototypes.items.bio-processing-item")
	
	require("prototypes.technology.bio-processing-technology")
end