require("prototypes.recipe.recipes")
require("prototypes.recipe.recipe-updates")
require("prototypes.technology")
require("prototypes.technology-updates")
require("prototypes.items.items")
require("prototypes.recipe.syntheticwoodremoval")


bobmods.ores.gold.enabled = false
bobmods.ores.zinc.enabled = false
bobmods.ores.quartz.enabled = false
bobmods.ores.settings.UnsortedGemOre = true
bobmods.ores.nickel.enabled = false
bobmods.ores.settings.LeadGivesNickel = true
bobmods.ores.settings.LeadNickelRatio = 0.3