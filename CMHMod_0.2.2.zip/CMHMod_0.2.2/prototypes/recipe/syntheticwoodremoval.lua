if data.raw.item["synthetic-wood"] then
    data.raw["recipe"]["synthetic-wood"].result = "wood"
    data.raw["recipe"]["wooden-board-synthetic"] = nil
    data.raw["recipe"]["phenolic-board-synthetic"] = nil
end