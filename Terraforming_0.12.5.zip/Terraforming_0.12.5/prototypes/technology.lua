data:extend({
{
	type = "technology",
	name = "terraforming-1",
	icon = "__Terraforming__/graphics/technology/terraforming.png",
	icon_size = 128,
	effects =
	{
		{
			type = "unlock-recipe",
			recipe = "bridge-builder",
		},
		{
			type = "unlock-recipe",
			recipe = "ford",
		},
	},
	prerequisites = {"electronics"},
	unit =
	{
		count = 20,
		ingredients =
		{
			{"science-pack-1", 1},
			{"science-pack-2", 1},
		},
		time = 10
	},
	order = "t-a"
},

{
	type = "technology",
	name = "terraforming-2",
	icon = "__Terraforming__/graphics/technology/terraforming.png",
	icon_size = 128,
	effects =
	{
		{
			type = "unlock-recipe",
			recipe = "stone-bridge",
		},
		{
			type = "unlock-recipe",
			recipe = "concrete-bridge",
		},
		{
			type = "unlock-recipe",
			recipe = "moat-digger",
		},
		{
			type = "unlock-recipe",
			recipe = "moat",
		},
		{
			type = "unlock-recipe",
			recipe = "fill-water-barrel",
		},
		{
			type = "unlock-recipe",
			recipe = "empty-water-barrel",
		},
	},
	prerequisites = {"terraforming-1", "steel-processing", "fluid-handling"},
	unit =
	{
		count = 50,
		ingredients =
		{
			{"science-pack-1", 1},
			{"science-pack-2", 1},
		},
		time = 15
	},
	order = "t-b"
},

{
	type = "technology",
	name = "terraforming-3",
	icon = "__Terraforming__/graphics/technology/terraforming.png",
	icon_size = 128,
	effects =
	{
		{
			type = "unlock-recipe",
			recipe = "stone-moat",
		},
		{
			type = "unlock-recipe",
			recipe = "concrete-moat",
		},
		{
			type = "unlock-recipe",
			recipe = "draw-bridge",
		},
		{
			type = "unlock-recipe",
			recipe = "rail-bridge",
		},
	},
	prerequisites = {"terraforming-2", "railway"},
	unit =
	{
		count = 100,
		ingredients =
		{
			{"science-pack-1", 1},
			{"science-pack-2", 1},
		},
		time = 25
	},
	order = "t-c"
},

{
	type = "technology",
	name = "terraforming-prefabrication",
	icon = "__Terraforming__/graphics/technology/terraforming-prefabrication.png",
	icon_size = 128,
	effects =
	{
		{
			type = "unlock-recipe",
			recipe = "prefabrication-plant",
		},
		{
			type = "unlock-recipe",
			recipe = "ford-package",
		},
		{
			type = "unlock-recipe",
			recipe = "stone-bridge-package",
		},
		{
			type = "unlock-recipe",
			recipe = "concrete-bridge-package",
		},
		{
			type = "unlock-recipe",
			recipe = "moat-package",
		},
		{
			type = "unlock-recipe",
			recipe = "stone-moat-package",
		},
		{
			type = "unlock-recipe",
			recipe = "concrete-moat-package",
		},
		{
			type = "unlock-recipe",
			recipe = "ford-prefab",
		},
		{
			type = "unlock-recipe",
			recipe = "stone-bridge-prefab",
		},
		{
			type = "unlock-recipe",
			recipe = "concrete-bridge-prefab",
		},
		{
			type = "unlock-recipe",
			recipe = "moat-prefab",
		},
		{
			type = "unlock-recipe",
			recipe = "stone-moat-prefab",
		},
		{
			type = "unlock-recipe",
			recipe = "concrete-moat-prefab",
		},
	
	},
	prerequisites = {"terraforming-3", "automation-2", "electric-engine", "plastics"},
	unit =
	{
		count = 10,
		ingredients =
		{
			{"science-pack-1", 15},
			{"science-pack-2", 10},
			{"science-pack-3", 1},
		},
		time = 30
	},
	order = "t-d"
},

{
	type = "technology",
	name = "terraforming-logistics",
	icon = "__Terraforming__/graphics/technology/terraforming-logistics.png",
	icon_size = 128,
	effects =
	{
		{
			type = "unlock-recipe",
			recipe = "logistic-moat-digger",
		},
		{
			type = "unlock-recipe",
			recipe = "logistic-bridge-builder",
		},	},
	prerequisites = {"terraforming-3", "logistic-system"},
	unit =
	{
		count = 50,
		ingredients =
		{
			{"science-pack-1", 3},
			{"science-pack-2", 2},
			{"science-pack-3", 1},
		},
		time = 30
	},
	order = "t-e"
},
  
})