data:extend({

{
	type = "recipe",
	name = "bridge-builder",
	category = "crafting",
	enabled = false,
	energy_required = 5,
	ingredients = 
	{
		{"steel-plate", 4},
		{"electronic-circuit", 2},
	},
	result = "bridge-builder",
	result_count = 1,
},

{
	type = "recipe",
	name = "ford",
	category = "terraforming",
	enabled = false,
	energy_required = 4,
	ingredients = 
	{
		{"raw-wood", 3},
		{"stone", 5},
	},
	result = "ford",
	result_count = 1,
},

{
	type = "recipe",
	name = "stone-bridge",
	category = "terraforming",
	enabled = false,
	energy_required = 7,
	ingredients = 
	{
		{"wood", 3},
		{"stone-brick", 5},
	},
	result = "stone-bridge",
	result_count = 1,
},

{
	type = "recipe",
	name = "concrete-bridge",
	category = "terraforming",
	enabled = false,
	energy_required = 10,
	ingredients = 
	{
		{"iron-plate", 3},
		{"concrete", 5},
	},
	result = "concrete-bridge",
	result_count = 1,
},

{
	type = "recipe",
	name = "moat-digger",
	category = "crafting",
	enabled = false,
	energy_required = 5,
	ingredients = 
	{
		{"steel-axe", 3},
		{"steel-plate", 2},
		{"empty-barrel", 2},
	},
	result = "moat-digger",
	result_count = 1,
},

{
	type = "recipe",
	name = "moat",
	category = "digging",
	enabled = false,
	energy_required = 4,
	ingredients = 
	{
		{"wood", 1},
		{"stone", 1},
		{"water-barrel", 1}
	},
	-- NB: For multiple results, must name the icon, group & subgroup as well
	icon = "__Terraforming__/graphics/icon/moat.png",
	group = "terraforming", 
	subgroup = "features",
	results=
	{
		{type="item", name="empty-barrel", amount=1}, -- NB: Barrel must be first result for it to be retained!
		{type="item", name="moat", amount=1},
	},
},

{
	type = "recipe",
	name = "stone-moat",
	category = "digging",
	enabled = false,
	energy_required = 7,
	ingredients = 
	{
		{"iron-axe", 1},
		{"wood", 3},
		{"stone-brick", 3},
		{"water-barrel", 1}
	},
	-- NB: For multiple results, must name the icon, group & subgroup as well
	icon = "__Terraforming__/graphics/icon/stone-moat.png",
	group = "terraforming", 
	subgroup = "features",
	results=
	{
		{type="item", name="empty-barrel", amount=1}, -- NB: Barrel must be first result for it to be retained!
		{type="item", name="stone-moat", amount=1},
	},
},

{
	type = "recipe",
	name = "concrete-moat",
	category = "digging",
	enabled = false,
	energy_required = 10,
	ingredients = 
	{
		{"iron-axe", 1},
		{"iron-plate", 3},
		{"concrete", 3},
		{"water-barrel", 1}
	},
	-- NB: For multiple results, must name the icon, group & subgroup as well
	icon = "__Terraforming__/graphics/icon/concrete-moat.png",
	group = "terraforming", 
	subgroup = "features",
	results=
	{
		{type="item", name="empty-barrel", amount=1}, -- NB: Barrel must be first result for it to be retained!
		{type="item", name="concrete-moat", amount=1},
	}
},

{
	type = "recipe",
	name = "fill-water-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "water-barrel",
	order = "c[water-barrel]-a[fill]",
	enabled = false,
	icon = "__Terraforming__/graphics/icon/fill-water-barrel.png",
	ingredients =
	{
		{type="fluid", name="water", amount=25},
		{type="item", name="empty-barrel", amount=1},
	},
	results=
	{
		{type="item", name="water-barrel", amount=1}
	}
},

{
	type = "recipe",
	name = "empty-water-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "water-barrel",
	order = "c[water-barrel]-b[empty]",
	enabled = false,
	icon = "__Terraforming__/graphics/icon/empty-water-barrel.png",
	ingredients =
	{
		{type="item", name="water-barrel", amount=1}
	},
	results=
	{
		{type="fluid", name="water", amount=25},
		{type="item", name="empty-barrel", amount=1},
	}
},

{
	type = "recipe",
	name = "draw-bridge",
	category = "crafting",
	enabled = false,
	energy_required = 5,
	ingredients = 
	{
		{"gate", 2},
		{"steel-plate", 2},
		{"concrete", 3},
	},
	result = "draw-bridge",
	result_count = 1,
},

{
	type = "recipe",
	name = "rail-bridge",
	category = "crafting",
	enabled = false,
	energy_required = 10,
	ingredients = 
	{
		{"gate", 2},
		{"straight-rail", 2},
		{"concrete", 3},
	},
	result = "rail-bridge",
	result_count = 1,
},

-------------------------------------- LOGISTIC SUPPORT ------------------------------------

{
	type = "recipe",
	name = "logistic-bridge-builder",
	category = "crafting",
	enabled = false,
	energy_required = 10,
	ingredients = 
	{
		{"bridge-builder", 1},
		{"steel-plate", 10},
		{"plastic-bar", 10},
		{"logistic-chest-requester", 1},
		{"logistic-chest-active-provider", 1},
	},
	result = "logistic-bridge-builder",
	result_count = 1,
},

{
	type = "recipe",
	name = "logistic-moat-digger",
	category = "crafting",
	enabled = false,
	energy_required = 10,
	ingredients = 
	{
		{"moat-digger", 1},
		{"steel-plate", 10},
		{"plastic-bar", 10},
		{"logistic-chest-requester", 1},
		{"logistic-chest-active-provider", 1},
	},
	result = "logistic-moat-digger",
	result_count = 1,
},

-------------------------------------- PREFABRICATION ------------------------------------

{
	type = "recipe",
	name = "prefabrication-plant",
	category = "crafting",
	enabled = false,
	energy_required = 10,
	ingredients = 
	{
        {"assembling-machine-2", 2},
		{"steel-furnace", 1},
	    {"electric-engine-unit", 2},
		{"plastic-bar", 10},
	},
	result = "prefabrication-plant",
	result_count = 1,
},

{
	type = "recipe",
	name = "ford-package",
	category = "prefabrication",
	enabled = false,
	energy_required = 8,
	ingredients = 
	{
		{"plastic-bar", 1},
		{"raw-wood", 4},
		{"stone", 7},
	},
	result = "ford-package",
	result_count = 1,
},

{
	type = "recipe",
	name = "stone-bridge-package",
	category = "prefabrication",
	enabled = false,
	energy_required = 14,
	ingredients = 
	{
		{"plastic-bar", 1},
		{"wood", 4},
		{"stone-brick", 7},
	},
	result = "stone-bridge-package",
	result_count = 1,
},

{
	type = "recipe",
	name = "concrete-bridge-package",
	category = "prefabrication",
	enabled = false,
	energy_required = 20,
	ingredients = 
	{
		{"plastic-bar", 1},
		{"iron-plate", 4},
		{"concrete", 7},
	},
	result = "concrete-bridge-package",
	result_count = 1,
},

{
	type = "recipe",
	name = "moat-package",
	category = "prefabrication",
	enabled = false,
	energy_required = 8,
	ingredients =
	{
		{type="fluid", name="water", amount=25},
		{type="item", name="plastic-bar", amount=1},
		{type="item", name="wood", amount=1},
		{type="item", name="stone", amount=2},
	},
	icon = "__Terraforming__/graphics/icon/moat-package.png",
	group = "terraforming", 
	subgroup = "package",
	results=
	{
		{type="item", name="moat-package", amount=1},
	},
},

{
	type = "recipe",
	name = "stone-moat-package",
	category = "prefabrication",
	enabled = false,
	energy_required = 14,
	ingredients = 
	{
		{type="fluid", name="water", amount=25},
		{type="item", name="plastic-bar", amount=1},
		{type="item", name="iron-axe", amount=1},
		{type="item", name="wood", amount=4},
		{type="item", name="stone-brick", amount=5},
	},
	-- NB: For multiple results, must name the icon, group & subgroup as well
	icon = "__Terraforming__/graphics/icon/stone-moat-package.png",
	group = "terraforming", 
	subgroup = "package",
	results=
	{
		{type="item", name="stone-moat-package", amount=1},
	},
},

{
	type = "recipe",
	name = "concrete-moat-package",
	category = "prefabrication",
	enabled = false,
	energy_required = 20,
	ingredients = 
	{
		{type="fluid", name="water", amount=25},
		{type="item", name="plastic-bar", amount=1},
		{type="item", name="iron-axe", amount=1},
		{type="item", name="iron-plate", amount=4},
		{type="item", name="concrete", amount=5},
	},
	-- NB: For multiple results, must name the icon, group & subgroup as well
	icon = "__Terraforming__/graphics/icon/concrete-moat-package.png",
	group = "terraforming", 
	subgroup = "package",	
	results=
	{
		{type="item", name="concrete-moat-package", amount=1},
	},
},

{
	type = "recipe",
	name = "ford-prefab",
	category = "terraforming",
	enabled = false,
	energy_required = 8,
	ingredients = 
	{
		{"ford-package", 1},
	},
	icon = "__Terraforming__/graphics/icon/ford-prefab.png",
	group = "terraforming", 
	subgroup = "prefab",	
	result = "ford",
	result_count = 1,
},

{
	type = "recipe",
	name = "stone-bridge-prefab",
	category = "terraforming",
	enabled = false,
	energy_required = 14,
	ingredients = 
	{
		{"stone-bridge-package", 1},
	},
	icon = "__Terraforming__/graphics/icon/stone-bridge-prefab.png",
	group = "terraforming", 
	subgroup = "prefab",	
	result = "stone-bridge",
	result_count = 1,
},

{
	type = "recipe",
	name = "concrete-bridge-prefab",
	category = "terraforming",
	enabled = false,
	energy_required = 20,
	ingredients = 
	{
		{"concrete-bridge-package", 1},
	},
	icon = "__Terraforming__/graphics/icon/concrete-bridge-prefab.png",	
	group = "terraforming", 
	subgroup = "prefab",	
	result = "concrete-bridge",
	result_count = 1,
},

{
	type = "recipe",
	name = "moat-prefab",
	category = "digging",
	enabled = false,
	energy_required = 8,
	ingredients = 
	{
		{"moat-package", 1},
	},
	icon = "__Terraforming__/graphics/icon/moat-prefab.png",	
	group = "terraforming", 
	subgroup = "prefab",	
	result = "moat",
	result_count = 1,
},

{
	type = "recipe",
	name = "stone-moat-prefab",
	category = "digging",
	enabled = false,
	energy_required = 14,
	ingredients = 
	{
		{"stone-moat-package", 1},
	},
	icon = "__Terraforming__/graphics/icon/stone-moat-prefab.png",	
	group = "terraforming", 
	subgroup = "prefab",	
	result = "stone-moat",
	result_count = 1,
},

{
	type = "recipe",
	name = "concrete-moat-prefab",
	category = "digging",
	enabled = false,
	energy_required = 20,
	ingredients = 
	{
		{"concrete-moat-package", 1},
	},
	icon = "__Terraforming__/graphics/icon/concrete-moat-prefab.png",	
	group = "terraforming", 
	subgroup = "prefab",	
	result = "concrete-moat",
	result_count = 1,
},
})