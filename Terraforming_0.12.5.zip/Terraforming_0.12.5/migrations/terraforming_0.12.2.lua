game.reload_script()

for _, force in pairs(game.forces) do
	force.reset_recipes()
	force.reset_technologies()
end

