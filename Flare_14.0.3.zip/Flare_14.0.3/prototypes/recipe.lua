data:extend(
{
    {
        type = "recipe",
        name = "flare-capsule",
        enabled = true,
        energy_required = 4,
        ingredients =
        {
            {"electronic-circuit", 2},
            {"coal", 2}
        },
        result = "flare-capsule"
    },
})