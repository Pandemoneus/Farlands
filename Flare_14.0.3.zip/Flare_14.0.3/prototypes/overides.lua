--[[for i, tree in pairs (data.raw.tree) do
    
    tree.resistances =
    {
      {
        type = "poison",
        percent = 0,---300,
      },
      {
        type = "poison",
        decrease = -2,
      }
    }
end]]--

