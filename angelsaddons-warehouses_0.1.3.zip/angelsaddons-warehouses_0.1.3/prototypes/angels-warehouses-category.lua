data:extend(
{
  {
    type = "item-subgroup",
    name = "angels-warehouses",
	group = "resource-refining",
	order = "zd",
  },
  }
  )