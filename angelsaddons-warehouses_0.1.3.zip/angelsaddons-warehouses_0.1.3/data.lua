if not angelsmods then angelsmods = {} end
if not angelsmods.addons then angelsmods.addons = {} end
if not angelsmods.addons.warehouses then angelsmods.addons.warehouses = {} end

require("prototypes.angels-warehouses-category")
	
require("prototypes.buildings.warehouses")

require("prototypes.recipes.warehouses")

require("prototypes.technology.warehouses-technology")