data:extend({
    {
        type="technology",
        name="repair-pack-mk2",
        icon="__nekoRepairPacks__/graphics/repair-pack-mk2.png",
        prerequisites={"steel-processing"},
        unit={
            count=25,
            time=10,
            ingredients={
                {"science-pack-1", 1},
                {"science-pack-2", 1}
            }
        },
        effects={
            {
                type="unlock-recipe",
                recipe="repair-pack-mk2"
            },
        },
    },
    {
        type="technology",
        name="repair-pack-mk3",
        icon="__nekoRepairPacks__/graphics/repair-pack-mk3.png",
        prerequisites={"repair-pack-mk2", "titanium-processing"},
        unit={
            count=50,
            time=25,
            ingredients= {
                {"science-pack-1", 1},
                {"science-pack-2", 1},
                {"science-pack-3", 1}
            }
        },
        effects= {
            {
                type="unlock-recipe",
                recipe="repair-pack-mk3"
            },
        },
    },
    {
          type="technology",
          name="repair-pack-mk4",
          icon="__nekoRepairPacks__/graphics/repair-pack-mk4.png",
          prerequisites={"repair-pack-mk3", "tungsten-processing"},
          unit={
              count=100,
              time=50,
              ingredients={
                  {"science-pack-1", 1},
                  {"science-pack-2", 1},
                  {"science-pack-3", 1}
              }
          },
          effects={
              {
                  type="unlock-recipe",
                  recipe="repair-pack-mk4"
              },
          },
    },
})