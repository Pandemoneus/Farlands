for index, force in pairs(game.forces) do
	local technologies = force.technologies
	local recipes = force.recipes
	
	force.reset_technologies()
  
	if technologies["uranium-processing"] ~= nil and technologies["uranium-processing"].researched then
		recipes["uraninite-slurry-from-uranium-ore"].enabled = true
	end
	
	if technologies["nuclear-fission"] ~= nil and technologies["nuclear-fission"].researched and recipes["uranium-slurry-from-uraninite"] ~= nil then
		recipes["uranium-slurry-from-uraninite"].enabled = true
	end
end
