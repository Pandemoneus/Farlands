data:extend({
	{
		type = "item-subgroup",
		name = "reactors_ammo",
		group = "reactions",
		order = "1"
	},
	{
		type = "item-subgroup",
		name = "reactors_parts",
		group = "reactions",
		order = "2"
	},
	{
		type = "item-subgroup",
		name = "reactors_production",
		group = "reactions",
		order = "3"
	}
})

data.raw["item-subgroup"]["fission-products"]["group"]	= "reactions"
data.raw["item-subgroup"]["fission-products"]["order"]	= "4"

data.raw["ammo"]["du-magazine"]["subgroup"]				= "reactors_ammo"
data.raw["item"]["plutonium-core"]["subgroup"]			= "reactors_parts"
data.raw["item"]["rtg-equipment"]["subgroup"]			= "reactors_parts"
data.raw["item"]["nuclear-reactor"]["subgroup"]			= "reactors_production"
data.raw["item"]["reactor-interface"]["subgroup"]		= "reactors_production"
data.raw["item"]["cooling-tower"]["subgroup"]			= "reactors_production"
data.raw["item"]["steam-turbine"]["subgroup"]			= "reactors_production"

-- detect Uranium Power
if data.raw["fluid"]["uraninite-slurry"] ~= nil then
	-- Add Uranium Ore to Uraninite Slurry recipe to Uranium Power tech
	table.insert(
		data.raw["technology"]["uranium-processing"].effects, 
		{
			type = "unlock-recipe",
			recipe = "uraninite-slurry-from-uranium-ore"
		}
	)
	
	-- Add Uraninite Ore to Uranium Slurry recipe to Reactors tech
	table.insert(
		data.raw["technology"]["nuclear-fission"].effects, 
		{
			type = "unlock-recipe",
			recipe = "uranium-slurry-from-uraninite"
		}
	)

	-- recipes
	data:extend({
		{
			type = "recipe",
			name = "uranium-slurry-from-uraninite",
			icon = "__Reactors__/graphics/icons/uranium-slurry.png",
			subgroup = "fission-products",
			order = "a[uranium]",
			category = "chemistry",
			enabled = "false",
			energy_required = 5,
			ingredients =
			{
				{type="fluid", name="sulfuric-acid", amount=1},
				{"uraninite", 8}
			},
			results =
			{
				{type="fluid", name="uranium-slurry", amount=8}
			}
		},
		{
			type = "recipe",
			name = "uraninite-slurry-from-uranium-ore",
			category = "crafting-with-fluid",
			subgroup = "uranium-prefluids",
			energy_required = 3,
			enabled = "false",
			ingredients =
			{
				{type="item", name="uranium-ore", amount=5},
				{type="fluid", name="water", amount=10}
			},
			results =
			{
				{type="fluid", name="uraninite-slurry", amount=5}
			}
		}
	})
end