require "defines"
require "stack"

local mod_version="0.0.1"

-- =============================================================
-- === event definitions
-- =============================================================

local stopnames = Stack:Create()

local function onLoad(event)
end

local function onTick()
end

local function onBuilt(event)
	local ent = event.created_entity

	if ent.type == "train-stop" and stopnames:getn() > 0 then
    ent.backer_name = stopnames:pop()
	end
end

local function onRemove(event)
	local ent = event.entity
  if ent.type == "train-stop" then
		stopnames:push(ent.backer_name)
	end
end

-- =============================================================
-- === event registration
-- =============================================================

script.on_init(onLoad)
script.on_load(onLoad)

-- script.on_event(defines.events.on_tick,onTick)

script.on_event(defines.events.on_built_entity, onBuilt)

-- script.on_event(defines.events.on_entity_died, onRemove)
script.on_event(defines.events.on_preplayer_mined_item, onRemove)
-- script.on_event(defines.events.on_robot_pre_mined, onRemove)
