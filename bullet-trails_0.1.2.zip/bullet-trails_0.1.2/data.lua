data:extend({
	{
		type = "explosion",
		name = "bullet-beam",
		flags = {"not-on-map", "placeable-off-grid"},
		animation_speed = 1,
		rotate = true,
		beam = true,
		animations =
		{
		  {
			filename = "__bullet-trails__/graphics/entity/projectile/bullet-beam.png",
			priority = "extra-high",
			width = 5,
			height = 90,
			frame_count = 6,
		  }
		},
		light = {intensity = 0.1, size = 2},
		smoke = "smoke-fast",
		smoke_count = 1,
		smoke_slow_down_factor = 1
	},
	{
		type = "explosion",
		name = "piercing-bullet-beam",
		flags = {"not-on-map", "placeable-off-grid"},
		animation_speed = 1,
		rotate = true,
		beam = true,
		animations =
		{
		  {
			filename = "__bullet-trails__/graphics/entity/projectile/piercing-bullet-beam.png",
			priority = "extra-high",
			width = 5,
			height = 90,
			frame_count = 6,
		  }
		},
		light = {intensity = 0.2, size = 4},
		smoke = "smoke-fast",
		smoke_count = 1,
		smoke_slow_down_factor = 1
	},
	{
		type = "explosion",
		name = "bullet-beam-cyan",
		flags = {"not-on-map", "placeable-off-grid"},
		animation_speed = 1,
		rotate = true,
		beam = true,
		animations =
		{
		  {
			filename = "__bullet-trails__/graphics/entity/projectile/bullet-beam-cyan.png",
			priority = "extra-high",
			width = 5,
			height = 90,
			frame_count = 6,
		  }
		},
		light = {intensity = 0.2, size = 4},
		smoke = "smoke-fast",
		smoke_count = 1,
		smoke_slow_down_factor = 1
	},
})
