
modVersion = "0.5.0"
modName = "robotMiningSite"
fullModName = "robotMiningSite"

libLog.testing = false -- enable logging (player console output)