if angelsmods.ores.enableangelsores and angelsmods.refining and bobmods.ores then
	require("prototypes.generation.angels-override")
end