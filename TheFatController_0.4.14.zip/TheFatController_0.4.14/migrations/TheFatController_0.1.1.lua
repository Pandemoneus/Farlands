global.character = nil
global.trains = nil
global.guiSettings = nil
global.unlocked = nil