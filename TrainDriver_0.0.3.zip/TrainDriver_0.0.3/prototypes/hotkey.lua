data:extend(
	{
		{
			type = "custom-input",
			name = "train_driver_directions",
			key_sequence = "CONTROL + Q",
			consuming = "script-only"
		},
	}
)