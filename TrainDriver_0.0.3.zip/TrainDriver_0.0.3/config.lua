-- Color of the displayed maneuver directions
-- if nil then the player color will be used

-- cfg_directions_color = nil
cfg_directions_color = {r = 255, g = 255, b = 0}


-- Should we display where is "straight" direction?
cfg_directions_show_straight = true


-- Texts to be displayed
cfg_directions_straight = "STRAIGHT"
cfg_directions_left = "LEFT"
cfg_directions_right = "RIGHT"
