game.player.force.resettechnologies()
game.player.force.resetrecipes()