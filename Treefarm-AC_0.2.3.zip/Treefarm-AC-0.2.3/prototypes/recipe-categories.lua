data:extend(
{
	{
		type = "recipe-category",
		name = "treefarm-mod-smelting"
	},
	
	{
		type = "recipe-category",
		name = "treefarm-mod-crushing"
	},

	{
		type = "recipe-category",
		name = "treefarm-mod-hydroculture"
	},

	{
		type = "recipe-category",
		name = "treefarm-mod-bioreactor"
	},

	{
		type = "recipe-category",
		name = "treefarm-mod-biolab"
	},

	{
		type = "recipe-category",
		name = "treefarm-mod-dummy"
	}
}
)