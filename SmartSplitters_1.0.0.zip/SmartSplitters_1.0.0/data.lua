require("prototypes.entity.entities")
require("prototypes.items")
require("prototypes.recipes")
require("prototypes.technology")

require "mod_def"
if DF_Under_Debug then
	require("_tools.prototypes.debug")
end