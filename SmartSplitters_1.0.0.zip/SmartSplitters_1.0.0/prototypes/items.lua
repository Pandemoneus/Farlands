data:extend(
{
	{
		type = "item",
		name = "smartsplitter",
		icon = "__SmartSplitters__/graphics/smartsplitter-icon.png",
		flags = {"goes-to-quickbar"},
		order = "a[transport-belt]-d[smartsplitter]",
		subgroup = "belt",
		place_result = "smartsplitter",
		stack_size = 50
	},
})