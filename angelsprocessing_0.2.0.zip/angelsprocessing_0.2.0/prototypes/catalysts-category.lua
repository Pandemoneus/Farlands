data:extend(
{
  {
    type = "item-subgroup",
    name = "catalysts",
	group = "resource-processing",
	order = "m-h",
  },
}
)