DF_Under_Debug=0
DF_Print=0
DF_MakeItems=0
DF_DrawBuildMarkers=0
DF_PrintNonMoved=0
DF_EnableDump = 0
DF_ModuleName="__SmartSplitters__"

