data:extend(
{
	{
		type = "recipe",
		name = "smartsplitter",
		ingredients = { {"express-splitter", 1},
						{"advanced-circuit", 10},
					  },
		result = "smartsplitter",
		result_count = 2,
		enabled = "true"
	},
})