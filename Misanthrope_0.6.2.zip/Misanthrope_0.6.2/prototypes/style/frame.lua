data:extend({
    misanthrope_wide_naked_frame_style =
    {
      type = "frame_style",
      parent = "naked_frame_style",
      minimal_width = 256,
      maximal_width = 256
    },
})
