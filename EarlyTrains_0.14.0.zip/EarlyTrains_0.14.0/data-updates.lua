bobmods.lib.tech.remove_science_pack("engine", "science-pack-2")
bobmods.lib.tech.remove_science_pack("railway", "science-pack-2")
bobmods.lib.tech.remove_science_pack("automated-rail-transportation", "science-pack-2")
bobmods.lib.tech.remove_science_pack("rail-signals", "science-pack-2")

bobmods.lib.tech.remove_science_pack("rail-tanker", "science-pack-2")
bobmods.lib.tech.remove_science_pack("shuttleTrain_tech", "science-pack-2")
