-- Size of a region, in chunks (default is 56 to be a multiple of RSO's value)

RegionSize = 56



-- Search radius for finding neighbors in the same resource field (default is 1, max is 20 which is rather slow)

ResourceFieldSearchRadius = 5



-- Whether to search in all directions (default is false, not needed if find_entities_filtered returns results sorted by position)

ResourceFieldSearchAllDirections = false



-- Preferred names for resources on map, or blank to hide (default is to replace non-alphanumeric characters with space, upper-case the first letter, and prepend a tilde)

ResourceDisplayName = {}

ResourceDisplayName["infinite-iron-ore"] = ""
ResourceDisplayName["infinite-copper-ore"] = ""
ResourceDisplayName["infinite-coal"] = ""
ResourceDisplayName["infinite-stone"] = ""
ResourceDisplayName["infinite-bauxite-ore"] = ""
ResourceDisplayName["infinite-cobalt-ore"] = ""
ResourceDisplayName["infinite-zinc-ore"] = ""
ResourceDisplayName["infinite-tin-ore"] = ""
ResourceDisplayName["infinite-quartz"] = ""
ResourceDisplayName["infinite-gem-ore"] = ""
ResourceDisplayName["infinite-gold-ore"] = ""
ResourceDisplayName["infinite-lead-ore"] = ""
ResourceDisplayName["infinite-nickel-ore"] = ""
ResourceDisplayName["infinite-rutile-ore"] = ""
ResourceDisplayName["infinite-silver-ore"] = ""
ResourceDisplayName["infinite-sulfur"] = ""
ResourceDisplayName["infinite-tungsten-ore"] = ""
ResourceDisplayName["infinite-uranium-ore"] = ""

ResourceDisplayName["angels-fissure"] = "~Fissure"
ResourceDisplayName["angels-ore1"] = "~Saphirite"
ResourceDisplayName["infinite-angels-ore1"] = ""
ResourceDisplayName["angels-ore2"] = "~Jivolite"
ResourceDisplayName["infinite-angels-ore2"] = ""
ResourceDisplayName["angels-ore3"] = "~Stiratite"
ResourceDisplayName["infinite-angels-ore3"] = ""
ResourceDisplayName["angels-ore4"] = "~Crotinnium"
ResourceDisplayName["infinite-angels-ore4"] = ""
ResourceDisplayName["angels-ore5"] = "~Rubyte"
ResourceDisplayName["infinite-angels-ore5"] = ""
ResourceDisplayName["angels-ore6"] = "~Bobmonium"
ResourceDisplayName["infinite-angels-ore6"] = ""




--ResourceDisplayName[ "iron-ore" ] = "~Iron ore"
--ResourceDisplayName[ "copper-ore" ] = ""
--ResourceDisplayName[ "crude-oil" ] = ""
