data:extend({
  {
    type = "custom-input",
    name = "blueprint_delete_book",
    key_sequence = "SHIFT + mouse-button-2",
  }
})