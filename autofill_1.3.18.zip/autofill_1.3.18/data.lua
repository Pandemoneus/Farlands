data:extend({
  {
    type = "custom-input",
    name = "autofill-entity",
    key_sequence = "CONTROL + F",
    consuming = "all"
  }
})