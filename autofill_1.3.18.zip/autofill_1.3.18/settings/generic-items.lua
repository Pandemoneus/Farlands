--
-- Disclaimer: mp warranty void if edited.
--

return {
  ["ammo-bullets"] = {"uranium-bullet-magazine"}, --Uranium Power
  ["ammo-bullets"] = {"basic-bullet-ammo-box", "piercing-bullet-ammo-box"}, --Ammobox
  ["ammo-shells"] = {"uranium-small-nuke-shell", "uranium-cannon-shell"}, --Uranium Power
  ["ammo-shells"] = {"high-explosive-cannon-shell"} --Aircraft
}