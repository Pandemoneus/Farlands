data:extend(
{
  {
    type = "recipe-category",
    name = "water-treatment",
  },
  {
    type = "recipe-category",
    name = "angels-water-void",
  },
  {
    type = "item-group",
    name = "angels-void",
    order = "aaaaa",
    inventory_order = "z",
    icon = "__angelsrefining__/graphics/technology/clarifier.png",
  },
  {
    type = "item-subgroup",
    name = "angels-void",
    group = "angels-void",
    order = "a-a",
  },
  }
  )