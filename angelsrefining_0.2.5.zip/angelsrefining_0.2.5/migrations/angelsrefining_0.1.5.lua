game.reload_script()

for index, force in pairs(game.forces) do
  force.reset_recipes()
  force.reset_technologies()
end

if not bobmods.ores then
	if force.technologies["ore-crushing"].researched then
		force.recipes["angelsore1-crushed"].enabled = true
		force.recipes["angelsore2-crushed"].enabled = true
		force.recipes["angelsore3-crushed"].enabled = true
		force.recipes["angelsore4-crushed"].enabled = true
		force.recipes["angelsore5-crushed"].enabled = true
		force.recipes["angelsore6-crushed"].enabled = true
		
		force.recipes["angelsore1-crushed-processing"].enabled = true
		force.recipes["angelsore2-crushed-processing"].enabled = true
		force.recipes["angelsore3-crushed-processing"].enabled = true
		force.recipes["angelsore4-crushed-processing"].enabled = true
		force.recipes["angelsore5-crushed-processing"].enabled = true
		force.recipes["angelsore6-crushed-processing"].enabled = true

		force.recipes["iron-ore-chunk-processing"].enabled = true
		force.recipes["copper-ore-chunk-processing"].enabled = true
		force.recipes["iron-ore-crystal-processing"].enabled = true
		force.recipes["copper-ore-crystal-processing"].enabled = true
		force.recipes["iron-ore-pure-processing"].enabled = true
		force.recipes["copper-ore-pure-processing"].enabled = true
		
		force.recipes["slag-processing-stone"].enabled = true
	end
end

