data:extend({
 {
  type = "recipe",
  name = "power-sensor",
  energy_required = 0.5,
  enabled = false,
  category = "crafting",
  ingredients =
  {
	{"copper-cable", 6},
	{"electronic-circuit", 5},
  },
  result= "power-sensor"
 },
})