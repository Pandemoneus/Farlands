Biter Spawner
        type = "physical",
        decrease = 2,
        type = "explosion",
        decrease = 5,
        percent = 15,
                     res[1] = {"small-biter", {{0.0, 0.3}, {0.7, 0.0}}}
                       res[2] = {"medium-biter", {{0.3, 0.0}, {0.6, 0.3}, {0.8, 0.1}}}
                       res[3] = {"big-biter", {{0.6, 0.0}, {1.0, 0.4}}}
                       res[4] = {"behemoth-biter", {{0.99, 0.0}, {1.0, 0.3}}}

spitter spawner
        type = "physical",
        decrease = 2,
        type = "explosion",
        decrease = 5,
        percent = 15,
                     res[1] = {"small-biter", {{0.0, 0.3}, {0.35, 0}}}
                     res[2] = {"small-spitter", {{0.25, 0.0}, {0.5, 0.3}, {0.7, 0.0}}}
                     res[3] = {"medium-spitter", {{0.5, 0.0}, {0.7, 0.3}, {0.9, 0.1}}}
                     res[4] = {"big-spitter", {{0.6, 0.0}, {1.0, 0.4}}}
                     res[5] = {"behemoth-spitter", {{0.99, 0.0}, {1.0, 0.3}}}


medium biter
        type = "physical",
        decrease = 4,
        type = "explosion",
        percent = 10

big biter
        type = "physical",
        decrease = 8,
        type = "explosion",
        percent = 10

behemoth biter
        type = "physical",
        decrease = 8,
        percent = 20
        type = "explosion",
        decrease = 10,
        percent = 20


medium spitter
        type = "explosion",
        percent = 15

big spitter
        type = "explosion",
        percent = 30

behemoth spitter
        type = "explosion",
        percent = 35

