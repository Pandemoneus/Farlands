local vehiclesnap_amount = 16.0
-- snap amount is the amount of different angles car can drive on, 
-- (360 / vehiclesnap_amount) is the difference between 2 axis
-- car will slowly turn towards such angle axis

local lastorientation = {}
local player_ticks = {}
local tick = 2

script.on_event(defines.events.on_tick, function(event)
  tick = tick - 1
  if tick == 0 then
    -- If noone is in vehicles, take longer delay to do this whole check
    tick = 40
    for index, player in pairs(game.players) do
      if player.vehicle and player.vehicle.valid then
        local v = player.vehicle.type
        if v == "car" or v == "tank" then
          tick = 2
          if player.vehicle.speed > 0.1 then
            local o = player.vehicle.orientation
            if lastorientation[index] == nil then lastorientation[index] = 0 end
            if player_ticks[index] == nil then player_ticks[index] = 0 end
            if math.abs(o - lastorientation[index]) < 0.001 then
              if player_ticks[index] > 1 then
                local o2 = math.floor(o * vehiclesnap_amount + 0.5) / vehiclesnap_amount
                o = (o * 4.0 + o2) * 0.2
                player.vehicle.orientation = o
              else
                player_ticks[index] = player_ticks[index] + 1
              end
            else
              player_ticks[index] = 0
            end
            lastorientation[index] = o;
          end
        end
      end
    end
  end
end)