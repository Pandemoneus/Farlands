data:extend(
{
	{
		type = "item-group",
		name = "uranium",
		order = "f",
		inventory_order = "f",
		icon = "__UraniumPower__/graphics/icons/orbital.png"
	}
})