data:extend(
{
  {
    type = "item-subgroup",
    name = "catalysts",
	group = "bio-processing",
	order = "n-h",
  },
}
)