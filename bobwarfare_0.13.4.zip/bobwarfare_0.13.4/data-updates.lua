require("prototypes.overides")
require("prototypes.recipe.recipe-updates")
require("prototypes.technology.technology-updates")
require("prototypes.productivity-limitations")

if bobmods.warfare.RobotUpdate == true then
  require("prototypes.robots-updates")
end
