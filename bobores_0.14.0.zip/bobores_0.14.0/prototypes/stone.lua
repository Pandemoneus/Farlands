data.raw.resource.stone.autoplace = bobmods.lib.resource.create_autoplace{name = "stone", starting_area = true, size = 1.5, richness = 1.2}
