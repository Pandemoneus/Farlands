# Treefarm-Lite
This Factorio mod adds Treefarms, which let you cultivate trees and plants and grow your own wood!

This mod adds treefarms, coal-processing and a production-chain for organic plastic. Treefarm initially and primarily allows you to cultivate trees and other plants, at its core allowing the player to renewably source wood to supply their factory. It offers a more automated solution than chopping wood or directing many drones to 'deconstruct' tracts of forest, while offering a more visually appealing solution than mods based on Assembly machines, such as Greenhouses. Plus, treefarms are cool!

Treefarm is originally by drs9999 and is maintained by myself, Blu3wolf. Treefarm was released under a permissive license, and under that license this version of Treefarm is released under the GPLv3. This newer Treefarm has been updated to run on newer Factorio versions, and folds in performance enhancements from Rseding91 and StephenWard. Much thanks to them for their work on this newer faster version!

Treefarm-Lite
Copyright (C) 2016  drs, Bill 'Blu3wolf' Teale

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
