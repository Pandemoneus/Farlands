data:extend({
    {
        type = "item",
        name = "shuttleTrain",
        icon = "__ShuttleTrain__/graphics/icon_shuttleTrain.png",
        flags = {"goes-to-quickbar"},
        subgroup = "transport",
        place_result = "shuttleTrain",
        stack_size = 1,
    }
})