-- Use the new labs new tiered labs.
require("tweaks.newIntermediates.newlabs")
require("tweaks.newIntermediates.tweakedsciencepacks")
