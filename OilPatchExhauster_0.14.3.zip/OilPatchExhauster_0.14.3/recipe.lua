data:extend(
{
  {
    type = "recipe",
    name = "oil-exhauster",
	energy_required = 10,
    ingredients =
    {
	  {"iron-stick", 4},
	  {"stone-brick", 8},
	  {"stone", 40},
	  {"pipe-to-ground", 1},
	  {"pumpjack", 1}
    },
	result_count = 1,
    result = "oil-exhauster"
  }
})