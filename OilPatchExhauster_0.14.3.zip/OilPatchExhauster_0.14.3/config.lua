--Oil exhauster is a storage tank. Specify it's capacity. Default capacity for vanilla storage tank is 2500. Not less than 10!
--Mod default is 1000.
EXHAUSTER_CAPACITY = 1000

--If richness of oil patch is higher than this value, then oil patch will not be affected by exhauster. 10% = 0.1 oil/sec, 100% = 1 oil/sec and so on.
--Mod default is 10 (in %).
MINIMAL_YIELD_PERCENTAGE_TO_EXHAUST = 100