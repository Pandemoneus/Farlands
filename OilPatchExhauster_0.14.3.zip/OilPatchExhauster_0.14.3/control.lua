require "util"
require "config"

--script.on_event(defines.events.on_gui_click, function(event)
--  game.players[event.player_index].print("GUI element clicked: " .. event.element.name)
--end)

script.on_event(defines.events.on_tick, function(event)
	TickGuiUpdates(event)
	TickTanks(event)
end)

script.on_event({
    defines.events.on_built_entity, 
    defines.events.on_robot_built_entity
  }, 
  function(event)
    if event.created_entity.name == "oil-exhauster" then
      RememberOilPatchExhauster(event.created_entity)
    end
  end)

script.on_event({
    defines.events.on_preplayer_mined_item, 
    defines.events.on_robot_pre_mined, 
    defines.events.on_entity_died
  }, 
  function(event)
    if event.entity.name == "oil-exhauster" then
      ForgetOilPatchExhauster(event.entity)
    end
  end)

--[[
global.OPExhausters = array of exhausters
	global.OPExhausters[N] = {key = string, ent = LuaEntity of exhauster, patches_to_exhaust = array of patches}
		global.OPExhausters[N].patches_to_exhaust[N] = {ent = LuaEntity of oil patch, oil_at_start = int, estimated_oil = int}
]]
function RememberOilPatchExhauster(entity)
  if global.OPExhausters == nil then
    global.OPExhausters = {}
  end
  local OPExhauster = {}
  OPExhauster.key = GetEntityKey(entity)
  OPExhauster.ent = entity
  --PExhauster.drained = 0 --outdated
  OPExhauster.patches_to_exhaust = {}
  for i,oil_patch in pairs(FindOilPatchesUnder(entity)) do
    --entity.built_by.print("Yield = " .. oil_patch.amount)
    if oil_patch.amount <= (MINIMAL_YIELD_PERCENTAGE_TO_EXHAUST * 150) then
      local oil = oil_patch.amount * 5
      local valid_patch = {ent = oil_patch, oil_at_start = oil, estimated_oil = oil}
      table.insert(OPExhauster.patches_to_exhaust, valid_patch)
    end
  end
  table.insert(global.OPExhausters, OPExhauster)
end

function ForgetOilPatchExhauster(entity)
  if global.OPExhausters ~= nil then
    for i,OPExhauster in pairs(global.OPExhausters) do
      if OPExhauster.ent.surface == entity.surface then
        if OPExhauster.ent.position.x == entity.position.x and OPExhauster.ent.position.y == entity.position.y then
          for j,oil_patch in pairs(OPExhauster.patches_to_exhaust) do
            oil_patch.ent.destroy()
          end
          table.remove(global.OPExhausters, i)
          return
        end
      end
    end
  end
end

function TickTanks(event)
	if global.OPExhausters ~= nil then 
		for i = #global.OPExhausters,1,-1 do
			local OPExhauster = global.OPExhausters[i]
			if OPExhauster.ent.valid then
        if not OPExhauster.key then
          OPExhauster.key = GetEntityKey(OPExhauster.ent)
        end
				for j = #OPExhauster.patches_to_exhaust, 1, -1 do
          local oil_patch = OPExhauster.patches_to_exhaust[j]
          if oil_patch.ent.valid then
            if oil_patch.estimated_oil > 0 then
              if not oil_patch.oil_at_start then
                oil_patch.oil_at_start = oil_patch.estimated_oil
              end
              local amount = 1
              if OPExhauster.ent.fluidbox[1] ~= nil then
                amount = OPExhauster.ent.fluidbox[1].amount
              end
              if (amount + 1) <= EXHAUSTER_CAPACITY then --is there free capacity for new portion?
                OPExhauster.ent.fluidbox[1] = {
                  ["type"] = "crude-oil",
                  ["amount"] = amount + 1
                }
                oil_patch.estimated_oil = oil_patch.estimated_oil - 1
              end
            else --oil_patch.estimated_oil == 0
              oil_patch.ent.destroy()
              table.remove(OPExhauster.patches_to_exhaust, j)
            end
          else --oil_patch.ent.valid == false
            table.remove(OPExhauster.patches_to_exhaust, j)
          end
        end
			else --OPExhauster.ent.valid == false
				table.remove(global.OPExhausters, i)
			end
		end
	end
end

function FindOilPatchesUnder(entity)
  local pos = entity.position
  local srf = entity.surface
  local dlt = 1
  local search_area = {{pos.x - dlt, pos.y - dlt}, {pos.x + dlt, pos.y + dlt}}
  local oil_patches = srf.find_entities_filtered{area = search_area, name = "crude-oil"}
  return oil_patches
end

function TickGuiUpdates(event)
	if not global.last_check_tick then
    global.last_check_tick = event.tick
  end
  if event.tick - global.last_check_tick > 15 then
		global.last_check_tick = event.tick
    for i, player in pairs(game.players) do
			if player.valid and player.connected then
				if player.selected and player.selected.valid and player.selected.name == "oil-exhauster" then
					local ent_key = GetEntityKey(player.selected)
          local OPExhauster = GetOPExhausterByKey(ent_key)
          if OPExhauster then
            UpdateGui(player, OPExhauster)
          else
            HideGui(player)
          end
				else
          HideGui(player)
				end
			end
		end
	end
end

function GetEntityKey(entity)
	if entity and entity.valid then
		return "n" .. entity.name .. "s" .. entity.surface.name .. "x" .. entity.position.x .. "y" .. entity.position.y
	end
end

function GetOPExhausterByKey(key)
  for i, OPExhauster in pairs(global.OPExhausters) do
    if OPExhauster.key == key then 
      return OPExhauster
    end
  end
end

local gui_window_name = "OPE_Status"

function UpdateGui(player, OPExhauster)
  local window = GetGuiWindow(player)
  for i, child_name in pairs(window.children_names) do
    window[child_name].destroy()
  end
  if #OPExhauster.patches_to_exhaust > 0 then
    for i, patch in pairs(OPExhauster.patches_to_exhaust) do
      local pb = window.add({type="progressbar", name=GetEntityKey(patch.ent), size=400, value=patch.estimated_oil/patch.oil_at_start})
    end
  else
    window.add({type="label", name="label_empty", caption={"label-empty"}})
  end
end

function GetGuiWindow(player)
  if not player.gui.center[gui_window_name] then
    ShowGui(player)
  end
  return player.gui.center[gui_window_name]
end

function ShowGui(player)
  local gui = player.gui.center
  local window = gui.add({type="frame", name=gui_window_name, direction="vertical", caption={"entity-name.oil-exhauster"}})
end

function HideGui(player)
  if player.gui.center[gui_window_name] then
    player.gui.center[gui_window_name].destroy()
  end
end