--
-- Disclaimer: mp warranty void if edited.
--

return {
  ["ammo-bullets"] = {"piercing-rounds-magazine", "firearm-magazine"},
  ["ammo-rockets"] = {"rocket", "explosive-rocket"},
  ["ammo-shells"] = {"explosive-cannon-shell", "cannon-shell"},
  ["ammo-shotgun"]	= {"shotgun-shell"},
  ["fuels-all"] = {}, -- fuel tables not filled here because lack of "game" in this scope.
  ["fuels-high"] = {}
}
