if data.raw["item"]["pipe"].stack_size == 100 then
	function update_recipe(name, values)
		local recipe = data.raw.recipe[name]
		if recipe then
			for key, value in pairs(values) do
				recipe[key] = value
			end
		end
	end
	require("prototypes.recipe-marathon-update")
end

if not bobmods then bobmods = {} end
if bobmods.config then
	require("prototypes.recipe-bob-update")
end

if bobmods.config and data.raw["item"]["pipe"].stack_size == 100 then
	require("prototypes.recipe-bob-marathon-update")
end