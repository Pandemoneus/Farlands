update_recipe("oil-refinery",
{
	ingredients = {
		{type="item", name="steel-plate", amount=100},
		{type="item", name="iron-gear-wheel", amount=25},
		{type="item", name="stone-brick", amount=40},
		{type="item", name="electronic-circuit", amount=20},
		{type="item", name="pipe", amount=25}
	}
})

update_recipe("oil-refinery-mk2",
{
	ingredients = {
		{type="item", name="oil-refinery", amount=1},
		{type="item", name="steel-plate", amount=50},
		{type="item", name="iron-gear-wheel", amount=25},
		{type="item", name="concrete", amount=25},
		{type="item", name="advanced-circuit", amount=20},
		{type="item", name="pipe", amount=25}
	}
})

update_recipe("oil-refinery-mk3",
{
	ingredients = {
		{type="item", name="oil-refinery-mk2", amount=1},
		{type="item", name="steel-plate", amount=50},
		{type="item", name="iron-gear-wheel", amount=25},
		{type="item", name="concrete", amount=25},
		{type="item", name="processing-unit", amount=10},
		{type="item", name="pipe", amount=25}
	}
})