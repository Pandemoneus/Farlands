data:extend(
{
  {
    type = "item",
    name = "oil-refinery-mk2",
    icon = "__base__/graphics/icons/oil-refinery.png",
    flags = {"goes-to-quickbar"},
    subgroup = "production-machine",
    order = "e[refinery]",
    place_result = "oil-refinery-mk2",
    stack_size = 10
  },
  {
    type = "item",
    name = "oil-refinery-mk3",
    icon = "__base__/graphics/icons/oil-refinery.png",
    flags = {"goes-to-quickbar"},
    subgroup = "production-machine",
    order = "f[refinery]",
    place_result = "oil-refinery-mk3",
    stack_size = 10
  },
}
)