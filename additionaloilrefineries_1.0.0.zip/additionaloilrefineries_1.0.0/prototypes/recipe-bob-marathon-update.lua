update_recipe("oil-refinery-mk2",
{
	ingredients = {
		{type="item", name="oil-refinery", amount=1},
		{type="item", name="aluminium-plate", amount=50},
		{type="item", name="brass-gear-wheel", amount=25},
		{type="item", name="steel-bearing", amount=10},
		{type="item", name="advanced-circuit", amount=20},
		{type="item", name="brass-pipe", amount=25},
		{type="item", name="concrete", amount=25}
	}
})

update_recipe("oil-refinery-mk3",
{
	ingredients = {
		{type="item", name="oil-refinery-mk2", amount=1},
		{type="item", name="nitinol-alloy", amount=50},
		{type="item", name="nitinol-gear-wheel", amount=25},
		{type="item", name="nitinol-bearing", amount=10},
		{type="item", name="advanced-processing-unit", amount=10},
		{type="item", name="tungsten-pipe", amount=25},
		{type="item", name="concrete", amount=25}
	}
})