if data.raw.item["aluminium-plate"] then
  bobmods.lib.replace_recipe_item("oil-refinery-mk2", "steel-plate", "aluminium-plate")
end

if data.raw.item["brass-gear-wheel"] then
  bobmods.lib.replace_recipe_item("oil-refinery-mk2", "iron-gear-wheel", "brass-gear-wheel")
end

if data.raw.item["steel-bearing"] then
  bobmods.lib.add_recipe_item("oil-refinery-mk2", {"steel-bearing", 5})
end

if data.raw.item["tungsten-bearing"] then
  bobmods.lib.add_recipe_item("oil-refinery-mk3", {"tungsten-bearing", 5})
end

if data.raw.item["brass-pipe"] then
  bobmods.lib.replace_recipe_item("oil-refinery-mk2", "pipe", "brass-pipe")
  bobmods.lib.add_technology_prerequisite("oil-refinery-1", "zinc-processing")
end

if data.raw.item["nitinol-alloy"] then
  bobmods.lib.add_recipe_item("oil-refinery-mk3", {"nitinol-alloy", 15})
end

if data.raw.item["nitinol-gear-wheel"] then
  bobmods.lib.add_recipe_item("oil-refinery-mk3", {"nitinol-gear-wheel", 10})
end

if data.raw.item["tungsten-pipe"] then
  bobmods.lib.add_recipe_item("oil-refinery-mk3", {"tungsten-pipe", 10})
end

if data.raw.technology["nitinol-processing"] then
	bobmods.lib.add_technology_prerequisite("oil-refinery-2", "nitinol-processing")
end

if data.raw.tool["science-pack-4"] then
	bobmods.lib.replace_science_pack("oil-refinery-2", "alien-science-pack", "science-pack-4")
end