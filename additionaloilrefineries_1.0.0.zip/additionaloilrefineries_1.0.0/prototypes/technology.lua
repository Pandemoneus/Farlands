data:extend(
{
  {
    type = "technology",
    name = "oil-refinery-1",
    icon = "__base__/graphics/icons/oil-refinery.png",
    upgrade = "true",
    prerequisites = {"advanced-oil-processing"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "oil-refinery-mk2"
      }
    },
    unit =
    {
      count = 100,
      ingredients =
		{{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1}},
      time = 30
    },
    order = "d-a-d-1"
  },
  {
    type = "technology",
    name = "oil-refinery-2",
    icon = "__base__/graphics/icons/oil-refinery.png",
    upgrade = "true",
    prerequisites = {"oil-refinery-1"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "oil-refinery-mk3"
      }
    },
    unit =
    {
      count = 100,
      ingredients =
		{{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}},
      time = 30
    },
    order = "d-a-d-2"
  },
})
