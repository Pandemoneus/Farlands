data:extend(
{
  {
    type = "recipe",
    name = "oil-refinery-mk2",
    energy_required = 20,
    ingredients =
    {
	  {"oil-refinery", 1},
      {"steel-plate", 15},
      {"iron-gear-wheel", 10},
      {"advanced-circuit", 10},
      {"concrete", 10},
      {"pipe", 10}
    },
    result = "oil-refinery-mk2",
    enabled = false
  },
  {
    type = "recipe",
    name = "oil-refinery-mk3",
    energy_required = 20,
    ingredients =
    {
	  {"oil-refinery-mk2", 1},
      {"speed-module", 8},
      {"concrete", 20},
      {"processing-unit", 3}
    },
    result = "oil-refinery-mk3",
    enabled = false
  }
}
)
