vehiclesnap_amount = 16.0
vehiclesnap_lastorientation = 0
vehiclesnap_ticks = 0

script.on_event(defines.events.on_tick, function(event)
  if game.tick % 2 == 0 then
    for i = 1, #game.players do
      local player = game.players[i]
      if player.vehicle and player.vehicle.valid then
        local v = player.vehicle.type
        if v == "car" or v == "tank" then
          local s = player.vehicle.speed
          if s > 0.1 then
            local o = player.vehicle.orientation
            if math.abs(o - vehiclesnap_lastorientation) < 0.001 then
              if vehiclesnap_ticks > 1 then
                local o2 = math.floor(o * vehiclesnap_amount + 0.5) / vehiclesnap_amount
                o = (o * 4.0 + o2) * 0.2
                player.vehicle.orientation = o
              else
                vehiclesnap_ticks = vehiclesnap_ticks + 1
              end
            else
              vehiclesnap_ticks = 0
            end
            vehiclesnap_lastorientation = player.vehicle.orientation;
          end
        end
      end
    end
  end
end)