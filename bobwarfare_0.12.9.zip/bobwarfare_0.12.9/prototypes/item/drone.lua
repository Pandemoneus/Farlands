data:extend(
{
  {
    type = "item",
    name = "bob-robot-tank",
    icon = "__base__/graphics/icons/tank.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "b[personal-transport]-b[tank]",
    place_result = "bob-robot-tank",
    stack_size = 10
  },
}
)

