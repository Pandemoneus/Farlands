if not angelsmods then angelsmods = {} end
if not angelsmods.addons then angelsmods.addons = {} end
if not angelsmods.addons.oresilos then angelsmods.addons.oresilos = {} end

require("prototypes.angels-silos-category")
	
require("prototypes.buildings.ore-silos")

require("prototypes.recipes.ore-silos")

require("prototypes.technology.ore-silo-technology")