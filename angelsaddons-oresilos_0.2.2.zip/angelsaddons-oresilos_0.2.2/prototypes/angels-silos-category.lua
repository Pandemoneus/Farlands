data:extend(
{
  {
    type = "item-subgroup",
    name = "angels-silos",
	group = "resource-refining",
	order = "zc",
  },
  }
  )