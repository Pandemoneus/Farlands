# RadarGridGuide

Factorio mod. Adds a visual guide to the map to help keep radars on a regular grid, for 100% coverage without overlaps.
