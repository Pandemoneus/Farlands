-- Enabling this increases the recipe costs for Logistics Rails to include an Advanced circuit.
-- This also causes Logistics Rails to no longer give you back a regular rail when picked up, but instead gives you the appropriate type of rail.

expensiveRails = false
