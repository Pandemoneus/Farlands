require "lib"
require("prototypes.entity.entities")
require("prototypes.entity.farl_player")
require("prototypes.item.item")
require("prototypes.recipe.recipe")
require("prototypes.styles")