max_history = 50
default_polling = 7*13 -- default polling time in 1/60th second, should be >14