turbine_tint = { r = 0.125, g = 0.25, b = 0.5, a = 0.333 }

require("prototypes.entities")
require("prototypes.equipment")
require("prototypes.items")
require("prototypes.fluid")
require("prototypes.ammo")
require("prototypes.recipes")
require("prototypes.resources")
require("prototypes.signals")
require("prototypes.technology")