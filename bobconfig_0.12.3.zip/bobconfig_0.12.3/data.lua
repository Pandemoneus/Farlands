if not bobmods then bobmods = {} end
if not bobmods.config then bobmods.config = {} end

if not bobmods.config.enemies then bobmods.config.enemies = {} end
if not bobmods.config.logistics then bobmods.config.logistics = {} end
if not bobmods.config.mining then bobmods.config.mining = {} end
if not bobmods.config.modules then bobmods.config.modules = {} end
if not bobmods.config.ores then bobmods.config.ores = {} end
if not bobmods.config.gems then bobmods.config.gems = {} end
if not bobmods.config.plates then bobmods.config.plates = {} end
if not bobmods.config.warfare then bobmods.config.warfare = {} end
if not bobmods.config.power then bobmods.config.power = {} end


require("config")

-- Just some stats on how the game works to help you figure out what the values mean.
-- water = 100(max_temperature) - 15(default_temperature) = 85(Temperature range).
-- 85 * 1kJ(heat_capacity) per degree = 85kJ. 85kJ * 60(Ticks) = 5100kJ
-- Base game steam engine power generator = 5100kJ * 1(effectivity) * 0.1(fluid_usage_per_tick) = 510kJ

if bobmods.config.power.OverideBoilerValues then
-- A total of 5100kW is required to reach 100 degrees.
-- A lower efficiency means the fuel is burned faster to meet the energy consumption value.
  bobmods.config.power.boiler1 = {burner = {effectivity = 0.5}, energy_consumption = "390kW"}
  bobmods.config.power.boiler2 = {burner = {effectivity = 0.6}, energy_consumption = "520kW"}
  bobmods.config.power.boiler3 = {burner = {effectivity = 0.7}, energy_consumption = "700kW"}
  bobmods.config.power.boiler4 = {burner = {effectivity = 0.8}, energy_consumption = "1.1MW"}
end

if bobmods.config.power.OverideSteamEngineValues then
-- Higher efficiency means more power generated per unit of water consumed.
-- Higher values mean they consume more water, resulting in energy being produced faster.
-- Higher values also means less generators on a chain.
  bobmods.config.power.steamengine1 = {effectivity = 1, fluid_usage_per_tick = 0.1}
  bobmods.config.power.steamengine2 = {effectivity = 1.1, fluid_usage_per_tick = 0.15}
  bobmods.config.power.steamengine3 = {effectivity = 1.2, fluid_usage_per_tick = 0.2}
end


if bobmods.config.logistics.OverideRobotValues then
bobmods.config.logistics.logisticrobot1 = {
  max_health = 100,
  max_payload_size = 1,
  speed = 0.05,
  max_energy = "300kJ",
  energy_per_tick = "10J",
  energy_per_move = "1000J"
}

bobmods.config.logistics.logisticrobot2 = {
  max_health = 125,
  max_payload_size = 3,
  speed = 0.07,
  max_energy = "450kJ",
  energy_per_tick = "13J",
  energy_per_move = "1000J"
}

bobmods.config.logistics.logisticrobot3 = {
  max_health = 150,
  max_payload_size = 6,
  speed = 0.09,
  max_energy = "600kJ",
  energy_per_tick = "16J",
  energy_per_move = "1000J"
}

bobmods.config.logistics.logisticrobot4 = {
  max_health = 175,
  max_payload_size = 11,
  speed = 0.12,
  max_energy = "750kJ",
  energy_per_tick = "20J",
  energy_per_move = "1000J"
}


bobmods.config.logistics.constructionrobot1 = {
  max_health = 100,
  max_payload_size = 1,
  speed = 0.06,
  max_energy = "300kJ",
  energy_per_tick = "10J",
  energy_per_move = "1000J"
}

bobmods.config.logistics.constructionrobot2 = {
  max_health = 225,
  max_payload_size = 2,
  speed = 0.09,
  max_energy = "450kJ",
  energy_per_tick = "12J",
  energy_per_move = "1000J"
}

bobmods.config.logistics.constructionrobot3 = {
  max_health = 350,
  max_payload_size = 4,
  speed = 0.12,
  max_energy = "600kJ",
  energy_per_tick = "14J",
  energy_per_move = "1000J"
}

bobmods.config.logistics.constructionrobot4 = {
  max_health = 500,
  max_payload_size = 6,
  speed = 0.15,
  max_energy = "750kJ",
  energy_per_tick = "16J",
  energy_per_move = "1000J"
}
end



