data:extend({
  {
    type = "recipe",
    name = "shuttleTrain",
    enabled = false,
    ingredients =
    {
      {"engine-unit", 20},
      {"electronic-circuit", 10},
      {"steel-plate", 30}
    },
    result = "shuttleTrain"
  },
})