data:extend({
	{
		type = "resource-category",
		name = "null"
	},
	{
		type = "recipe-category",
		name = "null"
	}
})
