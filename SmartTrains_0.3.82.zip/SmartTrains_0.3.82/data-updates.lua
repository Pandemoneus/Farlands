table.insert(data.raw["technology"]["automated-rail-transportation"].effects,
  {
    type="unlock-recipe",
    recipe = "smart-train-stop"
  })
