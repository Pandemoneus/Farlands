require("prototypes.entity.MMT-entity")
require("prototypes.item.MMT-item")
require("prototypes.recipe.MMT-recipe")
require("prototypes.style.MMT-style")