data.raw["simple-entity"]["stone-rock"].minable =
{
  count = 25,
  hardness = 0.8,
  mining_particle = "stone-particle",
  mining_time = 5,
  result = "stone"
}