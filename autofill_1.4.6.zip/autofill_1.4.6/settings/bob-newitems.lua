--
-- Disclaimer: mp warranty void if edited.
--



return {
  ["ammo-artillery"] = {"explosive-artillery-shell","poison-artillery-shell","distractor-artillery-shell"},
  ["ammo-battery"] = {"laser-rifle-battery-diamond","laser-rifle-battery-topaz","laser-rifle-battery-amethyst","laser-rifle-battery-emerald","laser-rifle-battery-sapphire","laser-rifle-battery-ruby","laser-rifle-battery"}
}
