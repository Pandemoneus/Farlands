--
-- Disclaimer: mp warranty void if edited.
--

--[[
y-bullet-case=Bullet Case -- Not needed
y-ammo-acid=Acid Ammo -- Not Needed?
y-ammo-acid-2=Acid Projectile
y-ammo-hohlspitz=Standard Ammo
y-ammo-explosiv=Explosive Ammo 
y-ammo-poison=Poison Ammo
y-ammo-biggun=Tracer Ammo
y-ammo-krakon=Impact Ammo
--]]


return {
  ["ammo-bullets"] = {"y-ammo-acid-2","y-ammo-hohlspitz", "y-ammo-explosiv", "y-ammo-poison", "y-ammo-biggun", "y-ammo-krakon"}
}

