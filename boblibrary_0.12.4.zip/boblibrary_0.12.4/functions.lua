-- Merges table2's contents into table1.
function bobmods.lib.table_merge(table1, table2)
  for index, value in pairs(table2) do
    if type(value) == "table" then
      bobmods.lib.table_merge(table1[index], table2[index])
    else
      table1[index] = value
    end
  end
end
