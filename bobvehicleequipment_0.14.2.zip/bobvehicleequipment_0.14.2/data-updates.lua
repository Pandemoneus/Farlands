require("prototypes.recipe-updates")
require("prototypes.technology-updates")

