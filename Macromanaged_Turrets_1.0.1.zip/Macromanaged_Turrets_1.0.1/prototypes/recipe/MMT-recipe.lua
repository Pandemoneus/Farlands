data:extend(
{
	{
		type = "recipe",
		name = "MMT-logistic-turret-remote",
		ingredients =
		{
			{"electronic-circuit", 1},
			{"plastic-bar", 1}
		},
		result = "MMT-logistic-turret-remote"
	}
})