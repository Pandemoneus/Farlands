Repository for the Factorio Misanthrope mod.

Description
===========
Alters biter expansion mechanics, adds vastly improved biter AI behavior

Mod compatibility
=================
No known incompatibilities

Contributing
============
Contributions are welcome.
