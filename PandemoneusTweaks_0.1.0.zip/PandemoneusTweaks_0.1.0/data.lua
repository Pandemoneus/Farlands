-- Bob's mods config changes
bobmods.modules.EnableMergedModules = false
bobmods.ores.cobalt.enabled = true
bobmods.ores.sulfur.enabled = true

-- Angel's mods config changes
angelsmods.ores.yield = 10