-- Bob's mods config changes
bobmods.modules.EnableMergedModules = false
bobmods.ores.cobalt.enabled = true
bobmods.ores.sulfur.enabled = true

-- Angel's mods config changes
angelsmods.ores.yield = 10

-- Add Angel's fluids to flare stack mod
incineratelist = {  
  -- Angel's
  {name="water-purified",energy=0.5,amount=1},
  {name="water-mineralized",energy=0.5,amount=1},
  {name="water-floatation-waste",energy=0.5,amount=1},
  {name="water-saline",energy=0.5,amount=1},
}

-- Creates a recipe to incinerate given fluid, if said fluid exists
-- "fluid" is a table of name, energy, amount
function createIncinerationRecipe(fluid)
  if data.raw.fluid[fluid.name] then
    data:extend({
      {
        type = "recipe",
        name = fluid.name.."-incineration",
        category = "incineration",
        enabled = true,
        hidden = true,
        energy_required = fluid.energy,
        ingredients =
        {
          {type="fluid", name=fluid.name, amount=fluid.amount}
        },
        results =
        {
          {type="fluid", name=fluid.name, amount=0}
        },
        icon = "__Flare Stack__/graphics/icon/no.png",
        subgroup = "fluid-recipes",
        order = "z[incineration]"
      }
    })
  end
end

-- generate fluid incineration recipes
for i, fluid in pairs(incineratelist) do
  createIncinerationRecipe(fluid)
end