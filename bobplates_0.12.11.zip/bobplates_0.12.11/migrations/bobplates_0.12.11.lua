game.reload_script()

for index, force in pairs(game.forces) do
  force.reset_recipes()
  force.reset_technologies()

  if force.technologies["void-fluid"].researched then
    force.recipes["void-sulfur-dioxide"].enabled = true
  end
  if force.technologies["barrels"].researched then
    force.recipes["fill-water-barrel"].enabled = true
    force.recipes["empty-water-barrel"].enabled = true
    force.recipes["fill-lithia-water-barrel"].enabled = true
    force.recipes["empty-lithia-water-barrel"].enabled = true
  end
end


