-- Use the new labs new tiered labs.
require("tweaks.newlabs")
require("tweaks.tweakedsciencepacks")
