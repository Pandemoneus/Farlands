
script.on_event(defines.events.on_built_entity, function(event)
   
	local entity = event.created_entity
	local player = game.players[event.player_index]

	if entity.type ~= "underground-belt" then
		return
	end
	local belt_type = "transport-belt"
	if entity.neighbours[1] == nil then
		return
	else 
		nb = entity.neighbours[1]
		local belts = nil
		if entity.direction == defines.direction.north or entity.direction == defines.direction.west then
			belts = entity.surface.find_entities_filtered{type = belt_type, area = {{entity.position.x, entity.position.y}, {nb.position.x, nb.position.y}}}
		else
			belts = entity.surface.find_entities_filtered{type = belt_type, area = {{nb.position.x, nb.position.y}, {entity.position.x, entity.position.y}}}
		end
		if belts ~= nil then 
			num_belt = 0
			for i,belt in ipairs(belts) do
				if belt.direction == entity.direction then
					for name,count in pairs(belt.get_transport_line(1).get_contents()) do
						player.get_inventory(defines.inventory.player_main).insert({name = name, count = count})
					end
					belt.get_transport_line(1).clear()
					for name,count in pairs(belt.get_transport_line(2).get_contents()) do
						player.get_inventory(defines.inventory.player_main).insert({name = name, count = count})
					end
					belt.get_transport_line(2).clear()
					player.get_inventory(defines.inventory.player_main).insert({name = belt.name, count = 1})
					belt.destroy()
				end
			end
		end
	end
end)
 