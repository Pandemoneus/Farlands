data:extend(
{
  {
    type = "recipe-category",
    name = "bio-processing",
  },
  {
    type = "item-group",
    name = "resource-processing",
    order = "m",
    inventory_order = "m-a",
    icon = "__angelsprocessing__/graphics/item-group/ore-processing-plant.png",
	icon_size = 64,
  },
    {
    type = "item-subgroup",
    name = "bio-processing-intermediate",
	group = "resource-processing",
	order = "m-m",
  },
  {
    type = "item-subgroup",
    name = "bio-processing",
	group = "resource-processing",
	order = "m-o",
  },
  }
  )
