if angelsmods.refining then
    --CREATE SPLITTER
   angelsmods.functions.make_splitter()
   
   --ADD UNLOCK TO BARRELS
   angelsmods.functions.OV.add_prereq("fluid-barreling", "angels-fluid-control")
   
	--CREATE BARRELS
	angelsmods.functions.make_barrel("gas-compressed-air", "basic-chemistry", "c")
	angelsmods.functions.make_barrel("gas-hydrogen", "basic-chemistry", "c")
	angelsmods.functions.make_barrel("gas-oxygen", "basic-chemistry", "c")
	angelsmods.functions.make_barrel("gas-carbon-monoxide", "basic-chemistry", "c")
	angelsmods.functions.make_barrel("gas-carbon-dioxide", "basic-chemistry", "c")	
	angelsmods.functions.make_barrel("liquid-hydrofluoric-acid", "basic-chemistry", "c")	
	
	angelsmods.functions.make_barrel("gas-chlorine", "chlorine", "d")
	angelsmods.functions.make_barrel("gas-hydrogen-chloride", "chlorine", "d")
	angelsmods.functions.make_barrel("liquid-hydrochloric-acid", "chlorine", "d")
	angelsmods.functions.make_barrel("gas-allylchlorid", "chlorine", "d")
	angelsmods.functions.make_barrel("gas-epichlorhydrin", "chlorine", "d")
	angelsmods.functions.make_barrel("gas-chlor-methane", "chlorine", "d")
	angelsmods.functions.make_barrel("perchloric-acid", "chlorine", "d")
	
	angelsmods.functions.make_barrel("gas-nitrogen", "nitrogen", "e")
	angelsmods.functions.make_barrel("gas-ammonia", "nitrogen", "e")
	angelsmods.functions.make_barrel("gas-nitrogen-dioxide", "nitrogen", "e")
	angelsmods.functions.make_barrel("gas-ammonium-chloride", "nitrogen", "e")
	angelsmods.functions.make_barrel("gas-urea", "nitrogen", "e")
	angelsmods.functions.make_barrel("gas-melamine", "nitrogen", "e")
	angelsmods.functions.make_barrel("gas-liquid-nitric-acid", "nitrogen", "e")
	angelsmods.functions.make_barrel("gas-monochloramine", "nitrogen", "e")
	angelsmods.functions.make_barrel("gas-hydrazine", "nitrogen", "e")
	
	angelsmods.functions.make_barrel("gas-methylamine", "nitrogen-2", "f")
	angelsmods.functions.make_barrel("gas-dimethylamine", "nitrogen-2", "f")
	angelsmods.functions.make_barrel("gas-dimethylhydrazine", "nitrogen-2", "f")
	
	angelsmods.functions.make_barrel("gas-natural-1", "raws", "g")
	angelsmods.functions.make_barrel("liquid-multi-phase-oil", "raws", "g")
	angelsmods.functions.make_barrel("gas-raw-1", "raws", "g")
	angelsmods.functions.make_barrel("liquid-condensates", "raws", "g")
	angelsmods.functions.make_barrel("liquid-ngl", "raws", "g")
	angelsmods.functions.make_barrel("gas-residual", "raws", "g")
	
	angelsmods.functions.make_barrel("gas-methane", "carbons", "h")
	angelsmods.functions.make_barrel("gas-ethane", "carbons", "h")
	angelsmods.functions.make_barrel("gas-butane", "carbons", "h")
	angelsmods.functions.make_barrel("gas-propene", "carbons", "h")
	angelsmods.functions.make_barrel("liquid-naphtha", "carbons", "h")
	angelsmods.functions.make_barrel("liquid-mineral-oil", "carbons", "h")
	angelsmods.functions.make_barrel("liquid-fuel-oil", "carbons", "h")	
	angelsmods.functions.make_barrel("gas-methanol", "carbons", "h")	
	angelsmods.functions.make_barrel("gas-ethylene", "carbons", "h")	
	angelsmods.functions.make_barrel("gas-benzene", "carbons", "h")	

	angelsmods.functions.make_barrel("gas-synthesis", "carbons-2", "i")	
	angelsmods.functions.make_barrel("gas-butadiene", "carbons-2", "i")	
	angelsmods.functions.make_barrel("gas-phenol", "carbons-2", "i")	
	angelsmods.functions.make_barrel("gas-ethylbenzene", "carbons-2", "i")	
	angelsmods.functions.make_barrel("gas-styrene", "carbons-2", "i")	
	angelsmods.functions.make_barrel("gas-formaldehyde", "carbons-2", "i")	
	angelsmods.functions.make_barrel("gas-polyethylene", "carbons-2", "i")	
	angelsmods.functions.make_barrel("gas-glycerol", "carbons-2", "i")	
	
	angelsmods.functions.make_barrel("gas-acid", "sulfur", "j")
	angelsmods.functions.make_barrel("gas-hydrogen-sulfide", "sulfur", "j")
	angelsmods.functions.make_barrel("gas-sulfur-dioxide", "sulfur", "j")
	angelsmods.functions.make_barrel("liquid-sulfuric-acid", "sulfur", "j")
	
	--MOVE FLUID CONTROL
	data.raw["item-subgroup"]["petrochem-well-head"].group = "angels-barrels"
	data.raw["item-subgroup"]["petrochem-tanks"].group = "angels-barrels"
end