atom_loco = util.table.deepcopy(data.raw["locomotive"]["diesel-locomotive"])
atom_loco.name = "atomic-locomotive"
atom_loco.icon = "__Atomic Locomotives__/graphics/icons/atomic-locomotive.png"
atom_loco.minable.result = "atomic-locomotive"
atom_loco.weight = 4000
atom_loco.max_power = "1200kW"
atom_loco.braking_force = 30
atom_loco.energy_source.fuel_inventory_size = 0
atom_loco.energy_source.smoke = nil
atom_loco.color = { r = 0, g = 0.75, b = 0.5, a = 0.5 }
atom_loco.working_sound.sound.filename = "__base__/sound/idle1.ogg"
atom_loco.working_sound.sound.volume = 1


data:extend({
  atom_loco
})