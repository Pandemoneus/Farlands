local vehiclesnap_amount = 16.0
-- snap amount is the amount of different angles car can drive on, 
-- (360 / vehiclesnap_amount) is the difference between 2 axis
-- car will slowly turn towards such angle axis

global.lastorientation = {}
global.player_ticks = {}
global.tick = 2

script.on_configuration_changed(function(data)
  if data.mod_changes == nil then return end
  if global.lastorientation == nil then global.lastorientation = {} end
  if global.player_ticks == nil then global.player_ticks = {} end
  if global.tick == nil then global.tick = 2 end
end)

script.on_event(defines.events.on_tick, function(event)
  global.tick = global.tick - 1
  if global.tick == 0 then
    -- If noone is in vehicles, take longer delay to do this whole check
    global.tick = 40
    for index, player in pairs(game.players) do
      if player.vehicle and player.vehicle.valid then
        local v = player.vehicle.type
        if v == "car" or v == "tank" then
          global.tick = 2
          if player.vehicle.speed > 0.1 then
            local o = player.vehicle.orientation
            if global.lastorientation[index] == nil then global.lastorientation[index] = 0 end
            if global.player_ticks[index] == nil then global.player_ticks[index] = 0 end
            if math.abs(o - global.lastorientation[index]) < 0.001 then
              if global.player_ticks[index] > 1 then
                local o2 = math.floor(o * vehiclesnap_amount + 0.5) / vehiclesnap_amount
                o = (o * 4.0 + o2) * 0.2
                player.vehicle.orientation = o
              else
                global.player_ticks[index] = global.player_ticks[index] + 1
              end
            else
              global.player_ticks[index] = 0
            end
            global.lastorientation[index] = o;
          end
        end
      end
    end
  end
end)