data:extend({
  {
    type = "item",
    name = "flantenna",
    icon = "__FLAN__/graphics/icons/flantenna.png",
    flags = { "goes-to-quickbar" },
    subgroup = "circuit-network",
    place_result="flantenna",
    order = "c[other]-b[flantenna]",
    stack_size= 50,
  }
})