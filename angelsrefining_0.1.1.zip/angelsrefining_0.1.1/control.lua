require "defines"

script.on_event(defines.events.on_player_created,function()
local iteminsert = game.player.insert
iteminsert{name="burner-ore-crusher", count=1}
end)
