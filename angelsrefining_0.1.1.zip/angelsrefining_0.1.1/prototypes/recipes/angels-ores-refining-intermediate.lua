data:extend(
{
--TIER 1
	{
    type = "recipe",
    name = "angelsore1-crushed",
    category = "ore-sorting-t1",
	subgroup = "ore-processing-a",
    energy_required = 1,
	enabled = "true",
    ingredients ={{"angels-ore1", 2}},
    results=
    {
      {type="item", name="angels-ore1-crushed", amount=2},
      {type="item", name="stone-crushed", amount=1}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore1-crushed.png",
    order = "a[angelsore1-crushed]",
	},
	{
    type = "recipe",
    name = "angelsore1-crushed-hand",
	category = "crafting",
	subgroup = "ore-processing-a",
    energy_required = 4,
	enabled = "true",
    ingredients ={{"angels-ore1", 2}},
    results=
    {
      {type="item", name="angels-ore1-crushed", amount=2},
      {type="item", name="stone-crushed", amount=1}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore1-crushed.png",
    order = "g[angelsore1-crushed-hand]",
	},
	{
    type = "recipe",
    name = "angelsore2-crushed",
    category = "ore-sorting-t1",
	subgroup = "ore-processing-a",
    energy_required = 1,
	enabled = "false",
    ingredients ={{"angels-ore2", 2}},
    results=
    {
      {type="item", name="angels-ore2-crushed", amount=2},
      {type="item", name="stone-crushed", amount=1}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore2-crushed.png",
    order = "b[angelsore2-crushed]",
	},
	{
    type = "recipe",
    name = "angelsore3-crushed",
    category = "ore-sorting-t1",
	subgroup = "ore-processing-a",
    energy_required = 1,
	enabled = "true",
    ingredients ={{"angels-ore3", 2}},
    results=
    {
      {type="item", name="angels-ore3-crushed", amount=2},
      {type="item", name="stone-crushed", amount=1}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore3-crushed.png",
    order = "c[angelsore3-crushed]",
	},
	{
    type = "recipe",
    name = "angelsore3-crushed-hand",
    category = "crafting",
	subgroup = "ore-processing-a",
    energy_required = 4,
	enabled = "true",
    ingredients ={{"angels-ore3", 2}},
    results=
    {
      {type="item", name="angels-ore3-crushed", amount=2},
      {type="item", name="stone-crushed", amount=1}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore3-crushed.png",
    order = "h[angelsore3-crushed-hand]",
	},
	{
    type = "recipe",
    name = "angelsore4-crushed",
    category = "ore-sorting-t1",
	subgroup = "ore-processing-a",
    energy_required = 1,
	enabled = "false",
    ingredients ={{"angels-ore4", 2}},
    results=
    {
      {type="item", name="angels-ore4-crushed", amount=2},
      {type="item", name="stone-crushed", amount=1}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore4-crushed.png",
    order = "d[angelsore4-crushed]",
	},
	{
    type = "recipe",
    name = "angelsore5-crushed",
    category = "ore-sorting-t1",
	subgroup = "ore-processing-a",
    energy_required = 1,
	enabled = "false",
    ingredients ={{"angels-ore5", 2}},
    results=
    {
      {type="item", name="angels-ore5-crushed", amount=2},
      {type="item", name="stone-crushed", amount=1}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore5-crushed.png",
    order = "e[angelsore5-crushed]",
	},
	{
    type = "recipe",
    name = "angelsore6-crushed",
    category = "ore-sorting-t1",
	subgroup = "ore-processing-a",
    energy_required = 1,
	enabled = "false",
    ingredients ={{"angels-ore6", 2}},
    results=
    {
      {type="item", name="angels-ore6-crushed", amount=2},
      {type="item", name="stone-crushed", amount=1}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore6-crushed.png",
    order = "f[angelsore6-crushed]",
	},
--TIER 2
	{
    type = "recipe",
    name = "angelsore1-chunk",
    category = "ore-sorting-t2",
	subgroup = "ore-processing-b",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="angels-ore1-crushed", amount=2},
	{type="fluid", name="water", amount=2},
	},
    results=
    {
      {type="item", name="angels-ore1-chunk", amount=2},
      {type="item", name="sulfur", amount=1, probability=0.75}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore1-chunk.png",
    order = "m-b-a[angelsore1-chunk]",
	},
	{
    type = "recipe",
    name = "angelsore2-chunk",
    category = "ore-sorting-t2",
	subgroup = "ore-processing-b",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="angels-ore2-crushed", amount=2},
	{type="fluid", name="water", amount=2},
	},
    results=
    {
      {type="item", name="angels-ore2-chunk", amount=2},
      {type="item", name="sulfur", amount=1, probability=0.75}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore2-chunk.png",
    order = "m-b-b[angelsore2-chunk]",
	},
	{
    type = "recipe",
    name = "angelsore3-chunk",
    category = "ore-sorting-t2",
	subgroup = "ore-processing-b",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="angels-ore3-crushed", amount=3},
	{type="fluid", name="water", amount=2},
	},
    results=
    {
      {type="item", name="angels-ore3-chunk", amount=2},
      {type="item", name="sulfur", amount=1, probability=0.75}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore3-chunk.png",
    order = "m-b-c[angelsore3-chunk]",
	},
	{
    type = "recipe",
    name = "angelsore4-chunk",
    category = "ore-sorting-t2",
	subgroup = "ore-processing-b",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="angels-ore4-crushed", amount=2},
	{type="fluid", name="water", amount=2},
	},
    results=
    {
      {type="item", name="angels-ore4-chunk", amount=2},
      {type="item", name="sulfur", amount=1, probability=0.75}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore4-chunk.png",
    order = "m-b-d[angelsore4-chunk]",
	},
	{
    type = "recipe",
    name = "angelsore5-chunk",
    category = "ore-sorting-t2",
	subgroup = "ore-processing-b",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="angels-ore5-crushed", amount=2},
	{type="fluid", name="water", amount=2},
	},
    results=
    {
      {type="item", name="angels-ore5-chunk", amount=2},
      {type="item", name="sulfur", amount=1, probability=0.75}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore5-chunk.png",
    order = "m-b-e[angelsore5-chunk]",
	},
	{
    type = "recipe",
    name = "angelsore6-chunk",
    category = "ore-sorting-t2",
	subgroup = "ore-processing-b",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="angels-ore6-crushed", amount=2},
	{type="fluid", name="water", amount=2},
	},
    results=
    {
      {type="item", name="angels-ore6-chunk", amount=2},
      {type="item", name="sulfur", amount=1, probability=0.75}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore6-chunk.png",
    order = "m-b-f[angelsore6-chunk]",
	},
--TIER 3
	{
    type = "recipe",
    name = "angelsore1-crystal",
    category = "ore-sorting-t3",
	subgroup = "ore-processing-c",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="angels-ore1-chunk", amount=2},
	{type="fluid", name="sulfuric-acid", amount=0.5}
	},
    results=
    {
      {type="item", name="angels-ore1-crystal", amount=2},
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore1-crystal.png",
    order = "m-c-a[angelsore1-crystal]",
	},
	{
    type = "recipe",
    name = "angelsore2-crystal",
    category = "ore-sorting-t3",
	subgroup = "ore-processing-c",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="angels-ore2-chunk", amount=2},
	{type="fluid", name="sulfuric-acid", amount=0.5}
	},
    results=
    {
      {type="item", name="angels-ore2-crystal", amount=2},
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore2-crystal.png",
    order = "m-c-b[angelsore2-crystal]",
	},
	{
    type = "recipe",
    name = "angelsore3-crystal",
    category = "ore-sorting-t3",
	subgroup = "ore-processing-c",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="angels-ore3-chunk", amount=2},
	{type="fluid", name="sulfuric-acid", amount=0.5}
	},
    results=
    {
      {type="item", name="angels-ore3-crystal", amount=2},
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore3-crystal.png",
    order = "m-c-c[angelsore3-crystal]",
	},
	{
    type = "recipe",
    name = "angelsore4-crystal",
    category = "ore-sorting-t3",
	subgroup = "ore-processing-c",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="angels-ore4-chunk", amount=2},
	{type="fluid", name="sulfuric-acid", amount=0.5}
	},
    results=
    {
      {type="item", name="angels-ore4-crystal", amount=2},
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore4-crystal.png",
    order = "m-c-d[angelsore4-crystal]",
	},
	{
    type = "recipe",
    name = "angelsore5-crystal",
    category = "ore-sorting-t3",
	subgroup = "ore-processing-c",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="angels-ore5-chunk", amount=2},
	{type="fluid", name="sulfuric-acid", amount=0.5}
	},
    results=
    {
      {type="item", name="angels-ore5-crystal", amount=2},
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore5-crystal.png",
    order = "m-c-e[angelsore5-crystal]",
	},
	{
    type = "recipe",
    name = "angelsore6-crystal",
    category = "ore-sorting-t3",
	subgroup = "ore-processing-c",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="angels-ore6-chunk", amount=2},
	{type="fluid", name="sulfuric-acid", amount=0.5}
	},
    results=
    {
      {type="item", name="angels-ore6-crystal", amount=2},
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore6-crystal.png",
    order = "m-c-f[angelsore6-crystal]",
	},
--TIER 4
	{
    type = "recipe",
    name = "angelsore1-pure",
    category = "ore-sorting-t4",
	subgroup = "ore-processing-d",
    energy_required = 2,
	enabled = "false",
    ingredients ={{type="item", name="angels-ore1-crystal", amount=4}},
    results=
    {
      {type="item", name="angels-ore1-pure", amount=4},
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore1-pure.png",
    order = "m-d-a[angelsore1-pure]",
	},
	{
    type = "recipe",
    name = "angelsore2-pure",
    category = "ore-sorting-t4",
	subgroup = "ore-processing-d",
    energy_required = 2,
	enabled = "false",
    ingredients ={{type="item", name="angels-ore2-crystal", amount=4}},
    results=
    {
      {type="item", name="angels-ore2-pure", amount=4},
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore2-pure.png",
    order = "m-d-b[angelsore2-pure]",
	},
	{
    type = "recipe",
    name = "angelsore3-pure",
    category = "ore-sorting-t4",
	subgroup = "ore-processing-d",
    energy_required = 2,
	enabled = "false",
    ingredients ={{type="item", name="angels-ore3-crystal", amount=4}},
    results=
    {
      {type="item", name="angels-ore3-pure", amount=4},
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore3-pure.png",
    order = "m-d-c[angelsore3-pure]",
	},
	{
    type = "recipe",
    name = "angelsore4-pure",
    category = "ore-sorting-t4",
	subgroup = "ore-processing-d",
    energy_required = 2,
	enabled = "false",
    ingredients ={{type="item", name="angels-ore4-crystal", amount=4}},
    results=
    {
      {type="item", name="angels-ore4-pure", amount=4},
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore4-pure.png",
    order = "m-d-d[angelsore4-pure]",
	},
	{
    type = "recipe",
    name = "angelsore5-pure",
    category = "ore-sorting-t4",
	subgroup = "ore-processing-d",
    energy_required = 2,
	enabled = "false",
    ingredients ={{type="item", name="angels-ore5-crystal", amount=4}},
    results=
    {
      {type="item", name="angels-ore5-pure", amount=4},
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore5-pure.png",
    order = "m-d-e[angelsore5-pure]",
	},
	{
    type = "recipe",
    name = "angelsore6-pure",
    category = "ore-sorting-t4",
	subgroup = "ore-processing-d",
    energy_required = 2,
	enabled = "false",
    ingredients ={{type="item", name="angels-ore6-crystal", amount=4}},
    results=
    {
      {type="item", name="angels-ore6-pure", amount=4},
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore6-pure.png",
    order = "m-d-f[angelsore6-pure]",
	},
}
)

if bobmods.config.ores.UnsortedGemOre then
table.insert(data.raw["recipe"]["angelsore1-chunk"].results,{type="item", name="gem-ore", amount=1, probability=0.2})
table.insert(data.raw["recipe"]["angelsore2-chunk"].results,{type="item", name="gem-ore", amount=1, probability=0.2})
table.insert(data.raw["recipe"]["angelsore3-chunk"].results,{type="item", name="gem-ore", amount=1, probability=0.2})
table.insert(data.raw["recipe"]["angelsore4-chunk"].results,{type="item", name="gem-ore", amount=1, probability=0.2})
table.insert(data.raw["recipe"]["angelsore5-chunk"].results,{type="item", name="gem-ore", amount=1, probability=0.2})
table.insert(data.raw["recipe"]["angelsore6-chunk"].results,{type="item", name="gem-ore", amount=1, probability=0.2})
else
table.insert(data.raw["recipe"]["angelsore1-chunk"].results,{type="item", name="ruby-ore", amount=1, probability=0.2})
table.insert(data.raw["recipe"]["angelsore2-chunk"].results,{type="item", name="sapphire-ore", amount=1, probability=0.2})
table.insert(data.raw["recipe"]["angelsore3-chunk"].results,{type="item", name="emerald-ore", amount=1, probability=0.2})
table.insert(data.raw["recipe"]["angelsore4-chunk"].results,{type="item", name="amethyst-ore", amount=1, probability=0.2})
table.insert(data.raw["recipe"]["angelsore5-chunk"].results,{type="item", name="topaz-ore", amount=1, probability=0.2})
table.insert(data.raw["recipe"]["angelsore6-chunk"].results,{type="item", name="diamond-ore", amount=1, probability=0.2})
end