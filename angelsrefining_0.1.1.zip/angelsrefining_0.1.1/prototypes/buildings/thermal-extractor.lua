data:extend(
  {
  {
    type = "item",
    name = "thermal-extractor",
    icon = "__angelsrefining__/graphics/icons/thermal-extractor.png",
    flags = {"goes-to-quickbar"},
    subgroup = "refining-buildings",
    order = "e[thermal-extractor]",
    place_result = "thermal-extractor",
    stack_size = 10,
  },
  {
    type = "mining-drill",
    name = "thermal-extractor",
    icon = "__angelsrefining__/graphics/icons/thermal-extractor.png",
    flags = {"placeable-neutral", "player-creation"},
    minable = {mining_time = 1, result = "thermal-extractor"},
    resource_categories = {"angels-fissure"},
    max_health = 100,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    collision_box = {{ -4.4, -4.4}, {4.4, 4.4}},
    selection_box = {{ -4.5, -4.5}, {4.5, 4.5}},
    energy_source =
    {
      type = "electric",
      emissions = 0.15 / 1.5,
      usage_priority = "secondary-input"
    },
    fluid_box =
    {
      base_area = 1,
      base_level = 1,
      --pipe_picture = thermalpipepictures(),
      pipe_covers = thermalpipepictures(),
	  pipe_connections =
      { 
		{
          position = {-2, 5},
        },
      },
    },
    energy_usage = "90kW",
    mining_speed = 2,
    mining_power = 3,
    resource_searching_radius = 0.49,
    vector_to_place_result = {0, 0},
    module_specification =
    {
      module_slots = 2
    },
    radius_visualisation_picture =
    {
      filename = "__base__/graphics/entity/pumpjack/pumpjack-radius-visualization.png",
      width = 12,
      height = 12
    },
	-- base_picture =
    -- {
      -- sheet =
      -- {
        -- filename = "__angelsrefining__/graphics/entity/thermal-extractor/grube-base.png",
        -- priority = "extra-high",
        -- width = 384,
        -- height = 384,
        -- shift = {0, 0}
      -- }
    -- },
    animations =
    {
      north =
      {
        priority = "extra-high",
        width = 384,
        height = 384,
        line_length = 4,
        shift = {0, 0},
        filename = "__angelsrefining__/graphics/entity/thermal-extractor/thermal-extractor-animation.png",
        frame_count = 16,
		animation_speed = 0.5
      }
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = { filename = "__base__/sound/pumpjack.ogg" },
      apparent_volume = 1.5,
    },
    fast_replaceable_group = "thermal-extractor"
  }
}
)