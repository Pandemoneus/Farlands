--Enables the ore refining technology
angelsmods.refining.enableorerefining = true