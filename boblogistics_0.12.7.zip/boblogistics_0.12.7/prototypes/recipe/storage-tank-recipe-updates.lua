if data.raw.item["invar-alloy"] then
  bobmods.lib.replace_recipe_item ("storage-tank-2", "steel-plate", "invar-alloy")
end

if data.raw.item["titanium-plate"] then
  bobmods.lib.replace_recipe_item ("storage-tank-3", "steel-plate", "titanium-plate")
end

if data.raw.item["nitinol-alloy"] then
  bobmods.lib.replace_recipe_item ("storage-tank-4", "steel-plate", "nitinol-alloy")
end

