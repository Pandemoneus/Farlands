--[[Example:
      input: "500MJ"
      output: props = {value = 500, unit = "MJ"}
]]
function GetProps(str)
  local props = {value = 0, unit = ""}
  for i = 1, string.len(str), 1 do
    local cur_char = string.sub(str, i, i)
    local try_digit = tonumber(cur_char, 10)
    if try_digit then
      props.value = props.value * 10 + try_digit
    else
      props.unit = props.unit .. cur_char
    end
  end
  return props
end

--[[Example:
      input: {value = 500, unit = "MJ"}
      output: {value = 500000000, unit = "J"}
]]
function SimplifyProps(shortened_props)
  local multiplier = 1
  if string.find(string.lower(shortened_props.unit), "k") then
    multiplier = 1000
  elseif string.find(string.lower(shortened_props.unit), "m") then
    multiplier = 1000000
  elseif string.find(string.lower(shortened_props.unit), "g") then
    multiplier = 1000000000
  end
  shortened_props.value = shortened_props.value * multiplier
  shortened_props.unit = string.sub(shortened_props.unit, string.len(shortened_props.unit))
end

--[[Example:
      input: {value = 500000000, unit = "J"}
      output: {value = 500, unit = "MJ"}
]]
function ShortenProps(simplified_props)
  local unit_prefix = ""
  if simplified_props.value / 1000000000 > 1 then
    simplified_props.unit = "G" .. simplified_props.unit
    simplified_props.value = simplified_props.value / 1000000000
  elseif simplified_props.value / 1000000 > 1 then
    unit_prefix = "M"
    simplified_props.value = simplified_props.value / 1000000
  elseif simplified_props.value / 1000 > 1 then
    unit_prefix = "k"
    simplified_props.value = simplified_props.value / 1000
  end
end

require "config"
local beacon_energy_buffer = data.raw["electric-energy-interface"]["teleportation-beacon-electric-energy-interface"].energy_source.buffer_capacity
local beacon_energy_props = GetProps(beacon_energy_buffer)
SimplifyProps(beacon_energy_props)
data.raw["gui-style"].default["teleportation_beacon_energy_progressbar"] = {
	type = "progressbar_style",
	name = "teleportation_beacon_energy_progressbar",
	smooth_color = {g = 1},
	other_smooth_colors = {
   		{
      		less_then = Teleportation.config.energy_in_beacon_to_activate / beacon_energy_props.value,
      		color = {r = 1, g = 0, b = 0}
    	},
    	{
      		less_then = 2 * Teleportation.config.energy_in_beacon_to_activate / beacon_energy_props.value,
      		color = {r = 1, g = 1, b = 0}
    	}
  	}
}
