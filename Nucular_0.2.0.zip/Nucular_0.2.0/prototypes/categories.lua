data:extend(
  {
    {
      type = "recipe-category",
      name = "nuclear"
    },
    {
      type = "recipe-category",
      name = "nuclear-output"
    },
    {
      type = "recipe-category",
      name = "nuclear-input"
    }
  })
