Autofill
========

Factorio mod for automatic insertion of items to build entities.
