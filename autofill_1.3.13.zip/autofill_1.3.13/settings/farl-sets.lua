return {
  ["farl"] = {group="locomotives", "fuels-high"}
}
