--
-- Disclaimer: mp warranty void if edited.
--

return {
  ["ammobox-gun-turret-2"]= {group="turrets", limits= {10}, "ammo-bullets" }
}
