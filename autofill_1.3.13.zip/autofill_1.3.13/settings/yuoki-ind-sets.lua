--
-- Disclaimer: mp warranty void if edited.
--

local turretset = {group="turrets", limits= {20}, "ammo-bullets" }

return {
  ["y_turret_gun1f12"] = turretset,
  ["y_turret_gun2f12"] = turretset
}
