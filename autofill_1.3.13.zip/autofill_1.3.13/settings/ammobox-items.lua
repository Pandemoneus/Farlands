--
-- Disclaimer: mp warranty void if edited.
--



return {
  ["ammo-bullets"] = {"basic-bullet-ammo-box", "piercing-bullet-ammo-box"}
}
