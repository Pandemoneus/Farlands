return {
  ["shuttleTrain"] = {group="locomotives", "fuels-high"}
}