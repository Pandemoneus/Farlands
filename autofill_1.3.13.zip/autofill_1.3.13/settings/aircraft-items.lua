
return {
  ["ammo-shells"] = {"high-explosive-cannon-shell"}
}
