--
-- Disclaimer: mp warranty void if edited.
--

return {
  ["ammo-bullets"] = {"piercing-bullet-magazine", "basic-bullet-magazine"},
  ["ammo-rockets"] = {"rocket", "explosive-rocket"},
  ["ammo-shells"] = {"cannon-shell"},
  ["fuels-all"] = {}, -- fuel tables not filled here because lack of "game" in this scope.
  ["fuels-high"] = {}
}
