--local colors ={"red","orange","yellow","green","cyan","blue","purple","magenta","white","black"}

return {
  ["diesel-locomotive-*"] = {group="locomotives", "fuels-high"}
}
