data:extend(
{
	{
		type = "item",
		name = "MMT-logistic-turret-remote",
		icon = "__Macromanaged_Turrets__/graphics/remote_32.png",
		flags = {"goes-to-quickbar"},
		subgroup = "tool",
		order = "m[MMT-logistic-turret-remote]",
		place_result = "MMT-logistic-turret-remote",
		stack_size = 1
	}
})