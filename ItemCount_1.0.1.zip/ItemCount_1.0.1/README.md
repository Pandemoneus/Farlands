# ItemCount

Port of the Item Count mod by ThaPear

Will display a count of all of the items in your inventory that you have in your hand.

v1.0.0 - Add in vechicle inventory count, sleeker and faster code
v0.0.5 - Changes for Factorio.14
v0.0.4 - Removed onTick event and using new .13 on_player_cursor_stack_changed event
v0.0.3 - Changes for Factorio.13
