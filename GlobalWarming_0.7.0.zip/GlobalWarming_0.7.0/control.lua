WATER_THRESHOLD = 5000
RAY_DISTANCE = 500

function runOnce()
	if not global.shore then
		-- These are threshhold tiles.
		global.shore = {}
		updateLakes()
		
		global.shiftingSands = {}
		updateDeserts()
		
		global.waterDebt = 0
		global.desserts = 0 --Delicious desserts
				
	end
end

function waterWorld(event)
	if not global.shore then
		runOnce()
	end
	-- Run once every 5 minutes.
	-- For minutes * pollution / WATER_THRESHHOLD, create a new water tile.
	if event.tick % (60 * 60 * 5) == 0 then
	--if event.tick % 600 == 0 then -- Debug mode
		local pollution = getPollution()
		global.waterDebt = global.waterDebt + pollution / WATER_THRESHOLD
		--game.print("Global Warming: Water to add: " .. global.waterDebt)
		-- Check if table needs cleaning
		if #global.shore > 20 * math.max(global.waterDebt, 1) then
			updateLakes()
		end
	end
	
	-- Run six times per second.
	if event.tick % 10 == 0 and global.waterDebt > 0 then
	--if event.tick % (120) == 0 then
		-- local retries = 0 --Changed to add water more often, only determine debt occasionally.
		
		--For minutes * pollution / WATER_THRESHHOLD, create a new water tile.
		local tides = {}
		-- If debt > number of tiles that can possibly be converted over 5 minutes, then increase radius
		local radius = math.max(2, math.floor(math.sqrt(global.waterDebt / 1800)))
				
		--for i = global.waterDebt, 1, -1 do
			local shore = findShore()
			if shore and shore.valid then
				--game.print("Adding water with radius " .. radius)
				-- if checkTile(shore) then -- Is tile still valid?  Check if a wall was built or landfill added. Edit: Baked into findShore()
					for xx = -radius, radius, 1 do
						for yy = -radius, radius, 1 do
							local tile = game.surfaces[1].get_tile(shore.position.x+xx, shore.position.y+yy)
							if tile and tile.valid and tile.collides_with("ground-tile") and not checkWall(tile) and not checkPump(tile) then
								table.insert(tides, {name = "water", position = {tile.position.x, tile.position.y}})
								global.waterDebt = global.waterDebt - 1
								--i = i - 1
							end
						end
					end
					-- Add corners to table, 
					local corner
					corner = game.surfaces[1].get_tile(shore.position.x - radius-1, shore.position.y -radius-1)
					if checkTile(corner) then
						table.insert(global.shore, corner)
					end
					corner = game.surfaces[1].get_tile(shore.position.x + radius+1, shore.position.y - radius-1)
					if checkTile(corner) then
						table.insert(global.shore, corner)
					end
					corner = game.surfaces[1].get_tile(shore.position.x + radius+1, shore.position.y + radius+1)
					if checkTile(corner) then
						table.insert(global.shore, corner)
					end
					corner = game.surfaces[1].get_tile(shore.position.x - radius-1, shore.position.y + radius+1)
					if checkTile(corner) then
						table.insert(global.shore, corner)
					end
						
				-- else
					-- if retries < 10 then
						-- i = i+1 --Try again.
						-- retries  = retries + 1
					-- end
				-- end
				-- if retries >= 10 then
					-- game.print("Global Warming: Not enough tiles found to convert.")
					-- return
				-- end
			end
		--end
		-- Set tiles to water and add them to the list of candidates
		-- TODO: look for anything that can die()
		if #tides > 0 then
			game.surfaces[1].set_tiles(tides)
			--game.print("Global Warming: Converted " .. #tides .. " tiles to water.")
			-- for i, tide in pairs(tides) do
				-- local tile = game.surfaces[1].get_tile(tide.position[1], tide.position[2])
				-- table.insert(global.shore, tile)
			-- end
		end
	end
end

-- In progress
function desertification(event)
	if not global.shore then
		runOnce()
	end
	-- Run once every 5 minutes.
	-- For minutes * pollution / WATER_THRESHHOLD, create a new water tile.
	if (event.tick + 2) % (60 * 60 * 5) == 0 then
	--if (event.tick + 2) % 600 == 0 then --Debug mode
		local pollution = getPollution()
		global.desserts = global.desserts + pollution / WATER_THRESHOLD
		if #global.shiftingSands > 20 * math.max(global.desserts, 1) then
			updateDeserts()
		end
		--game.print("Global Warming: Adding " .. global.desserts .. "desert tiles.  Eventually.")
	end
	
	-- Run six times per second.
	if (event.tick + 2) % 10 == 0 and global.desserts > 0 then
		local tides = {}
		-- If debt > number of tiles that can possibly be converted, then increase radius
		local radius = math.max(2, math.floor(math.sqrt(global.desserts / 1800)))

		
		local sand = findSand()
		if sand and sand.valid then
			--game.print("Global Warming: Desert found, adding more sand.")
			for xx = -radius, radius, 1 do
				for yy = -radius, radius, 1 do
					local tile = game.surfaces[1].get_tile(sand.position.x+xx, sand.position.y+yy)
					if tile and tile.valid and not string.find(tile.name, "sand") then
						table.insert(tides, {name = "sand", position = {tile.position.x, tile.position.y}})
						global.desserts = global.desserts - 1
						--i = i - 1
					end
				end
			end
			
			local corner
			local function addCorner(tile)
				if checkSand(tile) then
					table.insert(global.shiftingSands, tile)
				end
			end
			
			corner = game.surfaces[1].get_tile(sand.position.x - radius-1, sand.position.y -radius-1)
			addCorner(corner)
			
			corner = game.surfaces[1].get_tile(sand.position.x + radius+1, sand.position.y - radius-1)
			addCorner(corner)
			
			corner = game.surfaces[1].get_tile(sand.position.x + radius+1, sand.position.y + radius+1)
			addCorner(corner)
			
			corner = game.surfaces[1].get_tile(sand.position.x - radius-1, sand.position.y + radius+1)
			addCorner(corner)
		--else
			--game.print("Global Warming: No valid desert edges found.")
		end
		if #tides > 0 then
			game.surfaces[1].set_tiles(tides)
			--game.print("Global Warming: Converted " .. #tides .. " tiles to desert.")
			-- for i, tide in pairs(tides) do
				-- local tile = game.surfaces[1].get_tile(tide.position[1], tide.position[2])
				-- table.insert(global.shore, tile)
			-- end
		end
	end
end

function getPollution()
	-- Iterate over all chunks and sum pollution.
	--if event.tick % (60 * 60 *5+ 1) == 0 then
		local pollution = 0
		-- local surface = game.surfaces[1]
		for chunk in game.surfaces[1].get_chunks() do
			pollution = pollution + game.surfaces[1].get_pollution({chunk.x*32, chunk.y*32})
		end
		return pollution
	--end
end

function findShore()
	
	-- 80% chance: Pick a random point near a random player and draw a line.
	-- 20% chance: Use a value from the global table.
	if math.random() > 0.2 then
		-- Raycast
		-- Pick a random point and a random direction and travel for RAY_DISTANCE units checking for a transition from water_tile to ground_tile or vice versa.
		for retries = 20, 1, -1 do
			if #game.connected_players > 0 then
			local p = game.connected_players[math.random(1, #game.connected_players)]
			if p and p.valid then
				local chunk = {}
				chunk.x = p.position.x + math.random(-250,250)
				chunk.y = p.position.y + math.random(-250,250)
				--local tile = game.surfaces[1].get_tile(chunk.x + math.random(-15,15), chunk.y + math.random(-15,15))
				local tile = game.surfaces[1].get_tile(chunk.x, chunk.y)
				if not tile then 
					log("Global Warming: Tile not valid.")
					return nil
				end
				if not tile.valid then
					log("Global Warming: Tile not valid.")
					return nil
				end
				local dx = 0
				local dy = 0
				local direction = math.random(1, 4)
				if direction == 1 then
					dy = -1
				end
				if direction == 2 then
					dx = 1
				end
				if direction == 3 then
					dy = 1
				end
				if direction == 4 then
					dx = -1
				end	
				for i = 0, RAY_DISTANCE, 1 do
					local tileNext = game.surfaces[1].get_tile(tile.position.x + dx, tile.position.y + dy)
					if checkTile(tileNext, direction) then
						return tileNext
					else
						if tileNext and tileNext.valid then
							tile = tileNext
						else
							return nil
						end
					end
				end
			end
			end
		end
	
	else
		-- Table lookup
		for retries = 10, 1, -1 do
			if #global.shore > 0 then
				local index = math.random(1, #global.shore)
				local tile = global.shore[index]
				table.remove(global.shore, index) --These entries are only good once.  Succeed or fail, we don't need it anymore.
				if checkTile(tile) then
					return tile
				end
			end
		end
	end
		
		
	
	--game.print("GlobalWarming: Failed to find a valid lake.")
	return nil
end	

function findSand()
	
	-- 80% chance: Pick a random point near a random player and draw a line.
	-- 20% chance: Use a value from the global table.
	if math.random() > 0.2 then
		-- Raycast
		-- Pick a random point and a random direction and travel for RAY_DISTANCE units checking for a transition from water_tile to ground_tile or vice versa.
		for retries = 20, 1, -1 do
			if #game.connected_players > 0 then
				local p = game.connected_players[math.random(1, #game.connected_players)]
				if p and p.valid then
					local chunk = {}
					chunk.x = p.position.x + math.random(-250,250)
					chunk.y = p.position.y + math.random(-250,250)
					--local tile = game.surfaces[1].get_tile(chunk.x + math.random(-15,15), chunk.y + math.random(-15,15))
					local tile = game.surfaces[1].get_tile(chunk.x, chunk.y)
					if not tile then 
						log("Global Warming: Tile not valid.")
						return nil
					end
					if not tile.valid then
						log("Global Warming: Tile not valid.")
						return nil
					end
					local dx = 0
					local dy = 0
					local direction = math.random(1, 4)
					if direction == 1 then
						dy = -1
					end
					if direction == 2 then
						dx = 1
					end
					if direction == 3 then
						dy = 1
					end
					if direction == 4 then
						dx = -1
					end	
					for i = 0, RAY_DISTANCE, 1 do
						local tileNext = game.surfaces[1].get_tile(tile.position.x + dx, tile.position.y + dy)
						if checkSand(tileNext, direction) then
							return tileNext
						else
							if tileNext and tileNext.valid then
								tile = tileNext
							else
								return nil
							end
						end
					end
				end
			end
		end
	
	else
		-- Table lookup
		for retries = 10, 1, -1 do
			if #global.shiftingSands > 0 then
				local index = math.random(1, #global.shiftingSands)
				local tile = global.shiftingSands[index]
				table.remove(global.shiftingSands, index) --These entries are only good once.  Succeed or fail, we don't need it anymore.
				if checkSand(tile) then
					return tile
				end
			end
		end
	end
		
		
	
	--game.print("GlobalWarming: Failed to find a valid desert tile.")
	return nil
end	

function updateLakes()
	-- Changing to a raycasting method
	--return
	-- Iterate over table and clean invalid candidates.
	for i = #global.shore, 1, -1 do
		local tile = global.shore[i]
		if not checkTile(tile) then
			table.remove(global.shore, i)
		end
		if i <= math.max(math.floor(#global.shore/100, 1)) then
			table.remove(global.shore, i)
		end
	end
end

function updateDeserts()
	for i = #global.shiftingSands, 1, -1 do
		local tile = global.shiftingSands[i]
		if not checkSand(tile) then
			table.remove(global.shiftingSands, i)
		end
		if i <= math.max(math.floor(#global.shiftingSands/100, 1)) then
			table.remove(global.shiftingSands, i)
		end
	end
end

function checkChunk(area)
	return -- Changed to a raycasting method
	-- local tiles = game.surfaces[1].find_entities_filtered{area = area, type = "tile"}
	-- for i, tile in pairs(tiles) do
		-- if checkTile(tile) then
			-- table.insert(global.shore, tile)
		-- end
	-- end
end

--Check tile to see if it's a ground tile next to water with no wall on it.  If so, return true
function checkTile(tile, dir)
	if tile and tile.valid then
		if tile.collides_with("ground-tile") then
			if not checkWall(tile) and not checkPump(tile) then
				
				local neigh
				-- north
				neigh = game.surfaces[1].get_tile(tile.position.x, tile.position.y -1)
				if neigh and neigh.valid and neigh.collides_with("water-tile") then
					return true
				end
				-- east
				neigh = game.surfaces[1].get_tile(tile.position.x+1, tile.position.y )
				if neigh and neigh.valid and neigh.collides_with("water-tile") then
					return true
				end
				-- south
				neigh = game.surfaces[1].get_tile(tile.position.x, tile.position.y +1)
				if neigh and neigh.valid and neigh.collides_with("water-tile") then
					return true
				end
				-- west
				neigh = game.surfaces[1].get_tile(tile.position.x-1, tile.position.y)
				if neigh and neigh.valid and neigh.collides_with("water-tile") then
					return true
				end
			end
			-- Still here?  Not a candidate
		end
	end
	return false
end

function checkSand(tile, dir)
	if tile and tile.valid then
		if string.find(tile.name, "sand") then
			--game.print("Sand tile found, checking neighbors.")
			local neigh
			
			local function checkNeighbor(neighbor)
				if neighbor and neighbor.valid and not string.find(neighbor.name, "sand") then
					return true
				end
			end
			
			-- north
			neigh = game.surfaces[1].get_tile(tile.position.x, tile.position.y -1)
			if checkNeighbor(neigh) then
				return true
			end
			
			-- east
			neigh = game.surfaces[1].get_tile(tile.position.x+1, tile.position.y )
			if checkNeighbor(neigh) then
				return true
			end
			-- south
			neigh = game.surfaces[1].get_tile(tile.position.x, tile.position.y +1)
			if checkNeighbor(neigh) then
				return true
			end
			-- west
			neigh = game.surfaces[1].get_tile(tile.position.x-1, tile.position.y)
			if checkNeighbor(neigh) then
				return true
			end
		-- Still here?  Not a candidate
		end
	end
	return false
end

function checkWall(tile)
	local walls = game.surfaces[1].find_entities_filtered{area = {{tile.position.x-0.49, tile.position.y-0.49}, {tile.position.x+0.49, tile.position.y+0.49}}, type = "wall"}
	if #walls == 0 then
		return false
	else
		return true
	end
end

function checkPump(tile)
	local pumps = game.surfaces[1].find_entities_filtered{area = {{tile.position.x-1.49, tile.position.y-1.49}, {tile.position.x+1.49, tile.position.y+1.49}}, type = "offshore-pump"}
	if #pumps == 0 then
		return false
	else
		return true
	end
end

script.on_init(function() 
	runOnce()
end)

script.on_event(defines.events.on_tick, function(event)
	waterWorld(event)
	desertification(event)
end)

script.on_configuration_changed(function()
	runOnce()
end)