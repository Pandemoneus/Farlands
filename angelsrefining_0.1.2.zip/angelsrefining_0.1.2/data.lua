if not angelsmods then angelsmods = {} end
if not angelsmods.refining then angelsmods.refining = {} end
if not angelsmods.ores then angelsmods.ores = {} end
if not bobmods then bobmods = {false} end

if angelsmods.ores.angelsoretrigger then
angelsmods.ores.enableangelsores = false
else
angelsmods.ores.enableangelsores = true
end

require("config")

if angelsmods.refining.enableorerefining then
	require("prototypes.ore-refining-category")
		
	require("prototypes.buildings.pipes-overlay")
	require("prototypes.buildings.ore-crusher")
	require("prototypes.buildings.ore-sorting-facility")
	require("prototypes.buildings.ore-floatation-cell")
	require("prototypes.buildings.ore-leaching-plant")
	require("prototypes.buildings.ore-refinery")
	require("prototypes.buildings.crystallizer")
	require("prototypes.buildings.filtration-unit")
	if not data.raw.resource["small-alien-artifact"] then
		require("prototypes.catalysts-inject")
	end	
	if bobmods.ores and angelsmods.ores.enableangelsores then
		require("prototypes.items.angels-ores-item")
		require("prototypes.items.angels-ores-refining")
		require("prototypes.buildings.thermal-extractor")
		
		require("prototypes.recipes.angels-ores-refining-intermediate")
		require("prototypes.recipes.angels-ores-refining-output")
		require("prototypes.recipes.ore-refining-entity")
		
		require("prototypes.technology.angels-ores-technology")
		require("prototypes.angels-refining-override")
		else
		require("prototypes.vanilla-refining-override")
		require("prototypes.items.vanilla-refining-item")
				
		require("prototypes.recipes.vanilla-refining-entity")
		require("prototypes.recipes.vanilla-refining-intermediate")
		require("prototypes.recipes.vanilla-refining-output")
				
		require("prototypes.technology.vanilla-technology")
	end
end