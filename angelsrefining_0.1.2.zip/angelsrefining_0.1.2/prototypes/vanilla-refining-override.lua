data:extend(
{
  {
    type = "item",
    name = "raw-copper-ore",
    icon = "__angelsrefining__/graphics/icons/raw-copper-ore.png",
    flags = {"goes-to-main-inventory"},
    stack_size = 200
  },
  {
    type = "item",
    name = "raw-iron-ore",
    icon = "__angelsrefining__/graphics/icons/raw-iron-ore.png",
    flags = {"goes-to-main-inventory"},
    stack_size = 200
  },
}
)

data.raw["resource"]["iron-ore"]["minable"].result = "raw-iron-ore"
data.raw["resource"]["copper-ore"]["minable"].result = "raw-copper-ore"