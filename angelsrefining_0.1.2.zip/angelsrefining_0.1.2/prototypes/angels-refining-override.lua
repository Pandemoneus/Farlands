--OVERRIDE FOR YUOKI
if data.raw.item["y-res1"] then
--TIER 2
data.raw["recipe"]["angelsore1-chunk-processing"].ingredients[1]={"angels-ore1-chunk", 7}
data.raw["recipe"]["angelsore3-chunk-processing"].ingredients[1]={"angels-ore3-chunk", 7}

table.insert(data.raw["recipe"]["angelsore1-chunk-processing"].results,{type = "item", name = "y-res1", amount=1})
table.insert(data.raw["recipe"]["angelsore3-chunk-processing"].results,{type = "item", name = "y-res2", amount=1})

--TIER 3
data.raw["recipe"]["angelsore1-crystal-processing"].ingredients[1]={"angels-ore1-crystal", 9}
data.raw["recipe"]["angelsore3-crystal-processing"].ingredients[1]={"angels-ore3-crystal", 9}

table.insert(data.raw["recipe"]["angelsore1-crystal-processing"].results,{type = "item", name = "y-res1", amount=1})
table.insert(data.raw["recipe"]["angelsore3-crystal-processing"].results,{type = "item", name = "y-res2", amount=1})

--TIER 4
data.raw["recipe"]["angelsore1-pure-processing"].ingredients[1]={"angels-ore1-pure", 10}
data.raw["recipe"]["angelsore3-pure-processing"].ingredients[1]={"angels-ore3-pure", 10}

table.insert(data.raw["recipe"]["angelsore1-pure-processing"].results,{type = "item", name = "y-res1", amount=1})
table.insert(data.raw["recipe"]["angelsore3-pure-processing"].results,{type = "item", name = "y-res2", amount=1})

data:extend({
	{
    type = "recipe",
    name = "slag-processing-yi",
    category = "crystallizing",
	subgroup = "slag-processing",
    energy_required = 8,
	enabled = "false",
    ingredients ={
	{type="fluid", name="slag-slurry-filtered", amount=1},
	},
    results=
    {
      {type="item", name="y-res1", amount=1, probability=0.5},
	  {type="item", name="y-res2", amount=1, probability=0.5},
    },
    icon = "__angelsrefining__/graphics/icons/slag.png",
    order = "a-a [slag-processing-yi]",
	},
})
table.insert(data.raw["technology"]["slag-processing-1"].effects,{type = "unlock-recipe", recipe = "slag-processing-yi"})
end

--OVERRIDE FOR URANIUM POWER
if data.raw.item["uraninite"]then
--TIER 2
data.raw["recipe"]["angelsore2-chunk-processing"].ingredients[1]={"angels-ore2-chunk", 7}
data.raw["recipe"]["angelsore4-chunk-processing"].ingredients[1]={"angels-ore4-chunk", 7}

table.insert(data.raw["recipe"]["angelsore2-chunk-processing"].results,{type = "item", name = "uraninite", amount=1})
table.insert(data.raw["recipe"]["angelsore4-chunk-processing"].results,{type = "item", name = "fluorite", amount=1})

--TIER 3
data.raw["recipe"]["angelsore2-crystal-processing"].ingredients[1]={"angels-ore2-crystal", 9}
data.raw["recipe"]["angelsore4-crystal-processing"].ingredients[1]={"angels-ore4-crystal", 9}

table.insert(data.raw["recipe"]["angelsore2-crystal-processing"].results,{type = "item", name = "uraninite", amount=1})
table.insert(data.raw["recipe"]["angelsore4-crystal-processing"].results,{type = "item", name = "fluorite", amount=1})

--TIER 4
data.raw["recipe"]["angelsore2-pure-processing"].ingredients[1]={"angels-ore2-pure", 10}
data.raw["recipe"]["angelsore4-pure-processing"].ingredients[1]={"angels-ore4-pure", 10}

table.insert(data.raw["recipe"]["angelsore2-pure-processing"].results,{type = "item", name = "uraninite", amount=1})
table.insert(data.raw["recipe"]["angelsore4-pure-processing"].results,{type = "item", name = "fluorite", amount=1})

data:extend({
	{
    type = "recipe",
    name = "slag-processing-up",
    category = "crystallizing",
	subgroup = "slag-processing",
    energy_required = 8,
	enabled = "false",
    ingredients ={
	{type="fluid", name="slag-slurry-filtered", amount=1},
	},
    results=
    {
      {type="item", name="uraninite", amount=1, probability=0.5},
	  {type="item", name="fluorite", amount=1, probability=0.5},
    },
    icon = "__angelsrefining__/graphics/icons/slag.png",
    order = "a-a [slag-processing-up]",
	},
})
table.insert(data.raw["technology"]["slag-processing-1"].effects,{type = "unlock-recipe", recipe = "slag-processing-up"})
end

--OVERRIDE FOR NUCULAR
if data.raw.item["uranium-ore"]then
--TIER 2
data.raw["recipe"]["angelsore5-chunk-processing"].ingredients[1]={"angels-ore2-chunk", 7}

table.insert(data.raw["recipe"]["angelsore5-chunk-processing"].results,{type = "item", name = "uranium-ore", amount=1})

--TIER 3
data.raw["recipe"]["angelsore5-crystal-processing"].ingredients[1]={"angels-ore2-crystal", 9}

table.insert(data.raw["recipe"]["angelsore5-crystal-processing"].results,{type = "item", name = "uranium-ore", amount=1})

--TIER 4
data.raw["recipe"]["angelsore5-pure-processing"].ingredients[1]={"angels-ore2-pure", 10}

table.insert(data.raw["recipe"]["angelsore5-pure-processing"].results,{type = "item", name = "uranium-ore", amount=1})

data:extend({
	{
    type = "recipe",
    name = "slag-processing-nuc",
    category = "crystallizing",
	subgroup = "slag-processing",
    energy_required = 8,
	enabled = "false",
    ingredients ={
	{type="fluid", name="slag-slurry-filtered", amount=1},
	},
    results=
    {
      {type="item", name="uranium-ore", amount=1, probability=0.8},
    },
    icon = "__angelsrefining__/graphics/icons/slag.png",
    order = "a-a [slag-processing-up]",
	},
})
table.insert(data.raw["technology"]["slag-processing-1"].effects,{type = "unlock-recipe", recipe = "slag-processing-nuc"})
end