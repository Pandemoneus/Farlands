data:extend(
{
  {
    type = "resource-category",
    name = "angels-fissure",
  },
  {
    type = "item-subgroup",
    name = "angels-ores",
	group = "resource-refining",
	order = "m-aaa",
  },
}
)