buttons = {
	["upgrade-planner-config-button"] = {type = "button", name = "upgrade-planner-config-button", technology = "automated-construction"},
	["blueprintTools"] = {type = "button", name = "blueprintTools", technology = "automated-construction"},
	["fatControllerButtons"] = {type = "flow", name = "toggleTrainInfo", technology = "rail-signals"},
	["research_Q"] = {type = "button", name = "research_Q"},
	["ion-cannon-button"] = {type = "button", name = "ion-cannon-button", technology = "rocket-silo"},
	["logistics-view-button"] = {type = "botton", name = "logistics-view-button", technology = "advanced-logistics-systems"},
}
