require("config")
require("prototypes.style")