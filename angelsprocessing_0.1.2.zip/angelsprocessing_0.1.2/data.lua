if not angelsmods then angelsmods = {} end
if not angelsmods.processing then angelsmods.processing = {} end
if not bobmods then bobmods = {false} end

require("config")

if angelsmods.processing.enableoreprocessing then
	if not angelsmods.refining and not data.raw.resource["small-alien-artifact"] then
		require("prototypes.catalysts-inject")
	end
	require("prototypes.ore-processing-category")
	require("prototypes.items.vanilla-ore-processing-item")
	require("prototypes.recipes.vanilla-ore-processing")
	--if angelsmods.processing.enable_ore_compressing then
		--	require("prototypes.recipes.vanilla-ore-compressing-recipe")
		--	require("prototypes.items.vanilla-ore-compressing-item")
		--	require("prototypes.technology.vanilla-ore-compression-technology")
	--end
	if bobmods.ores then 
		--if angelsmods.processing.enable_ore_compressing then
		--	require("prototypes.recipes.bob-ore-compressing-recipe")
		--	require("prototypes.items.bob-ore-compressing-item")
		--	require("prototypes.technology.bob-ore-compression-technology")
		--end
		require("prototypes.items.bob-ore-processing-item")
		require("prototypes.recipes.bob-ore-processing")
		require("prototypes.technology.bob-ore-processing-technology")
		require("prototypes.recipes.bob-ore-processing-entity")
		else
		require("prototypes.technology.vanilla-ore-processing-technology")
		require("prototypes.recipes.vanilla-ore-processing-entity")
	end

	require("prototypes.buildings.blast-furnace")
	require("prototypes.buildings.ore-processing-plant")

	
	if angelsmods.processing.enablebioprocessing then
		if bobmods.ores then
			require("prototypes.bio-processing-category")
			require("prototypes.buildings.bio-processing-plant")

			require("prototypes.recipes.bio-processing")
			require("prototypes.recipes.bio-processing-entity")
			require("prototypes.items.bio-processing-item")
	
			require("prototypes.technology.bio-processing-technology")
		end
	end
end

