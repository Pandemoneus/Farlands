--Enables the ore processing technology
angelsmods.processing.enableoreprocessing = true
--Enables the ore compressing technology (not implemented yet)
angelsmods.processing.enableorecompressing = false
--Enables the bio processing technology
angelsmods.processing.enablebioprocessing = true