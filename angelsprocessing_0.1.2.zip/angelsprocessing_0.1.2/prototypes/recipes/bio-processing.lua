data:extend(
{
{
    type = "recipe",
    name = "algae-farming",
    category = "bio-processing",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 4,
    ingredients ={
	{type="fluid", name="water", amount=1},
	{type="item", name="stone", amount=1},
	},
    results=
    {
      {type="fluid", name="oxygen", amount=1},
      {type="item", name="algae", amount=2},
    },
    main_product= "algae",
    icon = "__angelsprocessing__/graphics/icons/algae.png",
    order = "d-a [algae-farming]",
  },
  {
    type = "recipe",
    name = "paste",
    category = "chemistry",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 2,
    ingredients ={
	{type="item", name="sodium-hydroxide", amount=1},
	{type="item", name="cellulose-fiber", amount=2},
	},
    results=
    {
      {type="item", name="paste", amount=1},
    },
    main_product= "paste",
    icon = "__angelsprocessing__/graphics/icons/paste.png",
    order = "d-a [paste]",
  },
  -- {
    -- type = "recipe",
    -- name = "liquid-chlor-methane",
    -- category = "chemistry",
	-- subgroup = "bio-processing",
	-- enabled = "false",
    -- energy_required = 4,
    -- ingredients ={
	-- {type="fluid", name="chlorine", amount=1},
	-- {type="fluid", name="petroleum-gas", amount=1},
	-- },
    -- results=
    -- {
      -- {type="fluid", name="liquid-chlor-methane", amount=2},
    -- },
    -- main_product= "liquid-chlor-methane",
    -- icon = "__angelsprocessing__/graphics/icons/chlor-methane.png",
    -- order = "d-a [liquid-chlor-methane]",
  -- },
  {
    type = "recipe",
    name = "cellulose-fiber-algae",
    category = "chemistry",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 3,
    ingredients ={
	{type="item", name="algae", amount=1},
	},
    results=
    {
      {type="item", name="cellulose-fiber", amount=3},
    },
    main_product= "cellulose-fiber",
    icon = "__angelsprocessing__/graphics/icons/cellulose-fiber-algae.png",
    order = "d-a [cellulose-fiber-algae]",
  },
  {
    type = "recipe",
    name = "petri-dish",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 2,
    ingredients ={
	{type="item", name="glass", amount=1},
	},
    results=
    {
      {type="item", name="petri-dish", amount=2},
    },
    main_product= "petri-dish",
    icon = "__angelsprocessing__/graphics/icons/petri-dish.png",
    order = "d-a [petri-dish]",
  },
  {
    type = "recipe",
    name = "powdered-stone",
    category = "ore-processing",
	subgroup = "bio-processing-intermediate",
	enabled = "false",
    energy_required = 4,
    ingredients ={
	{type="item", name="stone", amount=1},
	},
    results=
    {
      {type="item", name="powdered-stone", amount=3},
    },
    main_product= "powdered-stone",
    icon = "__angelsprocessing__/graphics/icons/powdered-stone.png",
    order = "d-a [powdered-stone]",
  },
  {
    type = "recipe",
    name = "powdered-silver",
    category = "ore-processing",
	subgroup = "bio-processing-intermediate",
	enabled = "false",
    energy_required = 4,
    ingredients ={
	{type="item", name="silver-processed", amount=1},
	},
    results=
    {
      {type="item", name="powdered-silver", amount=3},
    },
    main_product= "powdered-silver",
    icon = "__angelsprocessing__/graphics/icons/powdered-silver.png",
    order = "d-a [powdered-silver]",
  },
  {
    type = "recipe",
    name = "powdered-cobalt",
    category = "ore-processing",
	subgroup = "bio-processing-intermediate",
	enabled = "false",
    energy_required = 4,
    ingredients ={
	{type="item", name="cobalt-processed", amount=1},
	},
    results=
    {
      {type="item", name="powdered-cobalt", amount=3},
    },
    main_product= "powdered-cobalt",
    icon = "__angelsprocessing__/graphics/icons/powdered-cobalt.png",
    order = "d-a [powdered-cobalt]",
  },
  {
    type = "recipe",
    name = "powdered-copper",
    category = "ore-processing",
	subgroup = "bio-processing-intermediate",
	enabled = "false",
    energy_required = 4,
    ingredients ={
	{type="item", name="copper-processed", amount=1},
	},
    results=
    {
      {type="item", name="powdered-copper", amount=3},
    },
    main_product= "powdered-copper",
    icon = "__angelsprocessing__/graphics/icons/powdered-copper.png",
    order = "d-a [powdered-copper]",
  },
  {
    type = "recipe",
    name = "powdered-gold",
    category = "ore-processing",
	subgroup = "bio-processing-intermediate",
	enabled = "false",
    energy_required = 4,
    ingredients ={
	{type="item", name="gold-processed", amount=1},
	},
    results=
    {
      {type="item", name="powdered-gold", amount=3},
    },
    main_product= "powdered-gold",
    icon = "__angelsprocessing__/graphics/icons/powdered-gold.png",
    order = "d-a [powdered-gold]",
  },
  {
    type = "recipe",
    name = "powdered-iron",
    category = "ore-processing",
	subgroup = "bio-processing-intermediate",
	enabled = "false",
    energy_required = 4,
    ingredients ={
	{type="item", name="iron-processed", amount=1},
	},
    results=
    {
      {type="item", name="powdered-iron", amount=3},
    },
    main_product= "powdered-iron",
    icon = "__angelsprocessing__/graphics/icons/powdered-iron.png",
    order = "d-a [powdered-iron]",
  },
  {
    type = "recipe",
    name = "powdered-rutile",
    category = "ore-processing",
	subgroup = "bio-processing-intermediate",
	enabled = "false",
    energy_required = 4,
    ingredients ={
	{type="item", name="rutile-processed", amount=1},
	},
    results=
    {
      {type="item", name="powdered-rutile", amount=3},
    },
    main_product= "powdered-rutile",
    icon = "__angelsprocessing__/graphics/icons/powdered-rutile.png",
    order = "d-a [powdered-rutile]",
  },
  {
    type = "recipe",
    name = "powdered-tungsten",
    category = "ore-processing",
	subgroup = "bio-processing-intermediate",
	enabled = "false",
    energy_required = 4,
    ingredients ={
	{type="item", name="tungsten-processed", amount=1},
	},
    results=
    {
      {type="item", name="powdered-tungsten", amount=3},
    },
    main_product= "powdered-tungsten",
    icon = "__angelsprocessing__/graphics/icons/powdered-tungsten.png",
    order = "d-a [powdered-tungsten]",
  },
  {
    type = "recipe",
    name = "powdered-zinc",
    category = "ore-processing",
	subgroup = "bio-processing-intermediate",
	enabled = "false",
    energy_required = 4,
    ingredients ={
	{type="item", name="zinc-processed", amount=1},
	},
    results=
    {
      {type="item", name="powdered-zinc", amount=3},
    },
    main_product= "powdered-zinc",
    icon = "__angelsprocessing__/graphics/icons/powdered-zinc.png",
    order = "d-a [powdered-zinc]",
  },
  {
    type = "recipe",
    name = "substrate-dish",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="petri-dish", amount=3},
	{type="item", name="powdered-silver", amount=1},
	{type="item", name="paste", amount=1},
	},
    results=
    {
      {type="item", name="substrate-dish", amount=3},
    },
    main_product= "substrate-dish",
    icon = "__angelsprocessing__/graphics/icons/substrate-dish.png",
    order = "d-a [substrate-dish]",
  },
  {
    type = "recipe",
    name = "alien-pre-artifact",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 2,
    ingredients ={
	{type="item", name="substrate-dish", amount=3},
	{type="item", name="alien-bacteria", amount=1},
	},
    results=
    {
      {type="item", name="alien-pre-artifact", amount=3},
    },
    main_product= "alien-pre-artifact",
    icon = "__angelsprocessing__/graphics/icons/alien-pre-artifact.png",
    order = "d-a [alien-pre-artifact]",
  },
  {
    type = "recipe",
    name = "alien-pre-artifact-base",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact", amount=1},
	{type="item", name="powdered-iron", amount=1},
	},
    results=
    {
      {type="item", name="alien-pre-artifact-base", amount=1},
    },
    main_product= "alien-pre-artifact-base",
    icon = "__angelsprocessing__/graphics/icons/alien-pre-artifact-base.png",
    order = "d-a [alien-pre-artifact-base]",
  },
  {
    type = "recipe",
    name = "alien-pre-artifact-yellow",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact", amount=1},
	{type="item", name="powdered-gold", amount=1},
    {type="item", name="diamond-5", amount=1},
	},
    results=
    {
      {type="item", name="alien-pre-artifact-yellow", amount=1},
    },
    main_product= "alien-pre-artifact-yellow",
    icon = "__angelsprocessing__/graphics/icons/alien-pre-artifact-yellow.png",
    order = "d-a [alien-pre-artifact-yellow]",
  },
  {
    type = "recipe",
    name = "alien-pre-artifact-blue",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact", amount=1},
	{type="item", name="powdered-cobalt", amount=1},
    {type="item", name="sapphire-5", amount=1},
	},
    results=
    {
      {type="item", name="alien-pre-artifact-blue", amount=1},
    },
    main_product= "alien-pre-artifact-blue",
    icon = "__angelsprocessing__/graphics/icons/alien-pre-artifact-blue.png",
    order = "d-a [alien-pre-artifact-blue]",
  },
  {
    type = "recipe",
    name = "alien-pre-artifact-green",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact", amount=1},
	{type="item", name="powdered-zinc", amount=1},
    {type="item", name="emerald-5", amount=1},
	},
    results=
    {
      {type="item", name="alien-pre-artifact-green", amount=1},
    },
    main_product= "alien-pre-artifact-green",
    icon = "__angelsprocessing__/graphics/icons/alien-pre-artifact-green.png",
    order = "d-a [alien-pre-artifact-green]",
  },
  {
    type = "recipe",
    name = "alien-pre-artifact-purple",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact", amount=1},
	{type="item", name="powdered-rutile", amount=1},
    {type="item", name="amethyst-5", amount=1},
	},
    results=
    {
      {type="item", name="alien-pre-artifact-purple", amount=1},
    },
    main_product= "alien-pre-artifact-purple",
    icon = "__angelsprocessing__/graphics/icons/alien-pre-artifact-purple.png",
    order = "d-a [alien-pre-artifact-purple]",
  },
  {
    type = "recipe",
    name = "alien-pre-artifact-orange",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact", amount=1},
	{type="item", name="powdered-tungsten", amount=1},
    {type="item", name="topaz-5", amount=1},
	},
    results=
    {
      {type="item", name="alien-pre-artifact-orange", amount=1},
    },
    main_product= "alien-pre-artifact-orange",
    icon = "__angelsprocessing__/graphics/icons/alien-pre-artifact-orange.png",
    order = "d-a [alien-pre-artifact-orange]",
  },
  {
    type = "recipe",
    name = "alien-pre-artifact-red",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact", amount=1},
	{type="item", name="powdered-copper", amount=1},
    {type="item", name="ruby-5", amount=1},
	},
    results=
    {
      {type="item", name="alien-pre-artifact-red", amount=1},
    },
    main_product= "alien-pre-artifact-red",
    icon = "__angelsprocessing__/graphics/icons/alien-pre-artifact-red.png",
    order = "d-a [alien-pre-artifact-red]",
  },
  {
    type = "recipe",
    name = "small-alien-artifact-red",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact-red", amount=1},
	},
    results=
    {
      {type="item", name="small-alien-artifact-red", amount=5},
    },
    main_product= "small-alien-artifact-red",
    icon = "__bobenemies__/graphics/icons/small-alien-artifact-red.png",
    order = "d-a [small-alien-artifact-red]",
  },
  {
    type = "recipe",
    name = "small-alien-artifact-yellow",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact-yellow", amount=1},
	},
    results=
    {
      {type="item", name="small-alien-artifact-yellow", amount=5},
    },
    main_product= "small-alien-artifact-yellow",
    icon = "__bobenemies__/graphics/icons/small-alien-artifact-yellow.png",
    order = "d-a [small-alien-artifact-yellow]",
  },
  {
    type = "recipe",
    name = "small-alien-artifact-orange",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact-orange", amount=1},
	},
    results=
    {
      {type="item", name="small-alien-artifact-orange", amount=5},
    },
    main_product= "small-alien-artifact-orange",
    icon = "__bobenemies__/graphics/icons/small-alien-artifact-orange.png",
    order = "d-a [small-alien-artifact-orange]",
  },
  {
    type = "recipe",
    name = "small-alien-artifact-blue",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact-blue", amount=1},
	},
    results=
    {
      {type="item", name="small-alien-artifact-blue", amount=5},
    },
    main_product= "small-alien-artifact-blue",
    icon = "__bobenemies__/graphics/icons/small-alien-artifact-blue.png",
    order = "d-a [small-alien-artifact-blue]",
  },
  {
    type = "recipe",
    name = "small-alien-artifact-purple",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact-purple", amount=1},
	},
    results=
    {
      {type="item", name="small-alien-artifact-purple", amount=5},
    },
    main_product= "small-alien-artifact-purple",
    icon = "__bobenemies__/graphics/icons/small-alien-artifact-purple.png",
    order = "d-a [small-alien-artifact-purple]",
  },
    {
    type = "recipe",
    name = "small-alien-artifact-green",
	category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact-green", amount=1},
	},
    results=
    {
      {type="item", name="small-alien-artifact-green", amount=5},
    },
    main_product= "small-alien-artifact-green",
    icon = "__bobenemies__/graphics/icons/small-alien-artifact-green.png",
    order = "d-a [small-alien-artifact-green]",
  },
  {
    type = "recipe",
    name = "small-alien-artifact",
    category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 5,
    ingredients ={
	{type="item", name="alien-pre-artifact-base", amount=1},
	},
    results=
    {
      {type="item", name="small-alien-artifact", amount=5},
    },
    main_product= "small-alien-artifact",
    icon = "__bobenemies__/graphics/icons/small-alien-artifact.png",
    order = "d-a [small-alien-artifact]",
  },
    {
    type = "recipe",
    name = "alien-bacteria",
    category = "bio-processing",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 3,
    ingredients ={
	{type="fluid", name="alien-goo", amount=1},
	},
    results=
    {
      {type="item", name="alien-bacteria", amount=1},
    },
    main_product= "alien-bacteria",
    icon = "__angelsprocessing__/graphics/icons/alien-bacteria.png",
    order = "d-a [alien-bacteria]",
  },
      {
    type = "recipe",
    name = "alien-goo",
    category = "chemistry",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 3,
    ingredients ={
		{type="item", name="small-alien-artifact", amount=1},
	},
    results=
    {
		{type="fluid", name="alien-goo", amount=1},
    },
    main_product= "alien-goo",
    icon = "__angelsprocessing__/graphics/icons/alien-goo.png",
    order = "d-a [alien-goo]",
  },
    {
    type = "recipe",
    name = "cellulose-fiber-raw-wood",
    category = "chemistry",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 2,
    ingredients ={
	{type="item", name="raw-wood", amount=1},
	},
    results=
    {
      {type="item", name="cellulose-fiber", amount=1},
    },
    main_product= "cellulose-fiber",
    icon = "__angelsprocessing__/graphics/icons/cellulose-fiber-raw-wood.png",
    order = "d-a [cellulose-fiber-raw-wood]",
  },
    {
    type = "recipe",
    name = "wood-from-cellulose",
    category = "crafting",
	subgroup = "bio-processing",
	enabled = "false",
    energy_required = 2,
    ingredients ={
		{type="item", name="cellulose-fiber", amount=1},
		{type="item", name="paste", amount=1},
	},
    results=
    {
      {type="item", name="wood", amount=3},
    },
    main_product= "wood",
    icon = "__angelsprocessing__/graphics/icons/wood-cellulose.png",
    order = "d-a [wood-cellulose]",
  },
  {
    type = "recipe",
    name = "concrete-pulver",
	category = "crafting",
	subgroup = "bio-processing-intermediate",
	enabled = "false",
    energy_required = 4,
    ingredients ={
		{type="item", name="powdered-stone", amount=1},
		{type="item", name="powdered-iron", amount=1},
	},
    results=
    {
      {type="item", name="concrete-pulver", amount=4},
    },
    main_product= "concrete-pulver",
    icon = "__angelsprocessing__/graphics/icons/concrete-pulver.png",
    order = "d-a [concrete-pulver]",
  },
  {
    type = "recipe",
    name = "concrete-brick",
	category = "crafting-with-fluid",
	subgroup = "terrain",
	enabled = "false",
    energy_required = 4,
    ingredients ={
		{type="item", name="concrete-pulver", amount=2},
		{type="fluid", name="water", amount=5},
	},
    results=
    {
      {type="item", name="concrete-brick", amount=5},
    },
    main_product= "concrete-brick",
    icon = "__angelsprocessing__/graphics/icons/concrete-brick.png",
    order = "d-a [concrete-brick]",
  },
  {
    type = "recipe",
    name = "concrete-from-pulver",
	category = "crafting-with-fluid",
	subgroup = "terrain",
	enabled = "false",
    energy_required = 4,
    ingredients ={
		{type="item", name="concrete-pulver", amount=2},
		{type="fluid", name="water", amount=5},
	},
    results=
    {
      {type="item", name="concrete", amount=10},
    },
    main_product= "concrete",
    icon = "__angelsprocessing__/graphics/icons/concrete.png",
    order = "d-a [concrete-from-pulver]",
  },
  }
  )