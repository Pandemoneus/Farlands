data:extend(
{
--BIO PROCESSING PLANT
{
    type = "recipe",
    name = "bio-processing-plant",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"steel-plate", 10},
	{"stone-brick", 30},
	{"electronic-circuit", 5},
	},
    result= "bio-processing-plant",
    icon = "__angelsprocessing__/graphics/icons/bio-processing-plant.png",
   },
  }
  )