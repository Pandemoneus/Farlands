data:extend(
{
  {
    type = "item-subgroup",
    name = "processing-crafting",
	group = "resource-processing",
	order = "m-aa",
  },
  {
    type = "item-subgroup",
    name = "catalysts",
	group = "resource-processing",
	order = "m-ab",
  },
}
)
if bobmods.ores then

data:extend(
{
  {
    type = "item",
    name = "alien-artifact-red",
    icon = "__angelsprocessing__/graphics/icons/alien-artifact-red.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "g[alien-artifact]-b[red]",
    stack_size = 500,
    default_request_amount = 10
  },

  {
    type = "item",
    name = "alien-artifact-orange",
    icon = "__angelsprocessing__/graphics/icons/alien-artifact-orange.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "g[alien-artifact]-c[orange]",
    stack_size = 500,
    default_request_amount = 10
  },

  {
    type = "item",
    name = "alien-artifact-yellow",
    icon = "__angelsprocessing__/graphics/icons/alien-artifact-yellow.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "g[alien-artifact]-d[yellow]",
    stack_size = 500,
    default_request_amount = 10
  },

  {
    type = "item",
    name = "alien-artifact-green",
    icon = "__angelsprocessing__/graphics/icons/alien-artifact-green.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "g[alien-artifact]-e[green]",
    stack_size = 500,
    default_request_amount = 10
  },

  {
    type = "item",
    name = "alien-artifact-blue",
    icon = "__angelsprocessing__/graphics/icons/alien-artifact-blue.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "g[alien-artifact]-f[blue]",
    stack_size = 500,
    default_request_amount = 10
  },
  {
    type = "item",
    name = "alien-artifact-purple",
    icon = "__angelsprocessing__/graphics/icons/alien-artifact-purple.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "g[alien-artifact]-g[purple]",
    stack_size = 500,
    default_request_amount = 10
  },
 {
    type = "item",
    name = "small-alien-artifact-red",
    icon = "__angelsprocessing__/graphics/icons/small-alien-artifact-red.png",
    flags = { "goes-to-main-inventory" },
    subgroup = "raw-material",
    order = "g[alien-artifact]-b[red]-a[small]",
    stack_size = 500,
    default_request_amount = 100
  },
  {
    type = "recipe",
    name = "alien-artifact-red-from-small",
    result = "alien-artifact-red",
    ingredients =
    {
      {"small-alien-artifact-red", 25}
    },
    energy_required = 1,
    enabled = "true",
    category = "crafting"
  },
  {
    type = "item",
    name = "small-alien-artifact-orange",
    icon = "__angelsprocessing__/graphics/icons/small-alien-artifact-orange.png",
    flags = { "goes-to-main-inventory" },
    subgroup = "raw-material",
    order = "g[alien-artifact]-c[orange]-a[small]",
    stack_size = 500,
    default_request_amount = 100
  },
  {
    type = "recipe",
    name = "alien-artifact-orange-from-small",
    result = "alien-artifact-orange",
    ingredients =
    {
      {"small-alien-artifact-orange", 25}
    },
    energy_required = 1,
    enabled = "true",
    category = "crafting"
  },
  {
    type = "item",
    name = "small-alien-artifact-yellow",
    icon = "__angelsprocessing__/graphics/icons/small-alien-artifact-yellow.png",
    flags = { "goes-to-main-inventory" },
    subgroup = "raw-material",
    order = "g[alien-artifact]-d[yellow]-a[small]",
    stack_size = 500,
    default_request_amount = 100
  },
  {
    type = "recipe",
    name = "alien-artifact-yellow-from-small",
    result = "alien-artifact-yellow",
    ingredients =
    {
      {"small-alien-artifact-yellow", 25}
    },
    energy_required = 1,
    enabled = "true",
    category = "crafting"
  },
  {
    type = "item",
    name = "small-alien-artifact-green",
    icon = "__angelsprocessing__/graphics/icons/small-alien-artifact-green.png",
    flags = { "goes-to-main-inventory" },
    subgroup = "raw-material",
    order = "g[alien-artifact]-e[green]-a[small]",
    stack_size = 500,
    default_request_amount = 100
  },
  {
    type = "recipe",
    name = "alien-artifact-green-from-small",
    result = "alien-artifact-green",
    ingredients =
    {
      {"small-alien-artifact-green", 25}
    },
    energy_required = 1,
    enabled = "true",
    category = "crafting"
  },
  {
    type = "item",
    name = "small-alien-artifact-blue",
    icon = "__angelsprocessing__/graphics/icons/small-alien-artifact-blue.png",
    flags = { "goes-to-main-inventory" },
    subgroup = "raw-material",
    order = "g[alien-artifact]-f[blue]-a[small]",
    stack_size = 500,
    default_request_amount = 100
  },
  {
    type = "recipe",
    name = "alien-artifact-blue-from-small",
    result = "alien-artifact-blue",
    ingredients =
    {
      {"small-alien-artifact-blue", 25}
    },
    energy_required = 1,
    enabled = "true",
    category = "crafting"
  },
  {
    type = "item",
    name = "small-alien-artifact-purple",
    icon = "__angelsprocessing__/graphics/icons/small-alien-artifact-purple.png",
    flags = { "goes-to-main-inventory" },
    subgroup = "raw-material",
    order = "g[alien-artifact]-g[purple]-a[small]",
    stack_size = 500,
    default_request_amount = 100
  },
  {
    type = "recipe",
    name = "alien-artifact-purple-from-small",
    result = "alien-artifact-purple",
    ingredients =
    {
      {"small-alien-artifact-purple", 25}
    },
    energy_required = 1,
    enabled = "true",
    category = "crafting"
  },
  {
    type = "item",
    name = "catalysator-blue",
    icon = "__angelsprocessing__/graphics/icons/catalysator-blue.png",
    flags = {"goes-to-main-inventory"},
	subgroup = "processing-crafting",
    stack_size = 200
  },
  {
    type = "item",
    name = "catalysator-green",
    icon = "__angelsprocessing__/graphics/icons/catalysator-green.png",
    flags = {"goes-to-main-inventory"},
	subgroup = "processing-crafting",
    stack_size = 200
  },
  {
    type = "item",
    name = "catalysator-orange",
    icon = "__angelsprocessing__/graphics/icons/catalysator-orange.png",
    flags = {"goes-to-main-inventory"},
	subgroup = "processing-crafting",
    stack_size = 200
  },
  {
    type = "item",
    name = "catalysator-purple",
    icon = "__angelsprocessing__/graphics/icons/catalysator-purple.png",
    flags = {"goes-to-main-inventory"},
	subgroup = "processing-crafting",
    stack_size = 200
  },
  {
    type = "item",
    name = "catalysator-red",
    icon = "__angelsprocessing__/graphics/icons/catalysator-red.png",
    flags = {"goes-to-main-inventory"},
	subgroup = "processing-crafting",
    stack_size = 200
  },
  {
    type = "item",
    name = "catalysator-yellow",
    icon = "__angelsprocessing__/graphics/icons/catalysator-yellow.png",
    flags = {"goes-to-main-inventory"},
	subgroup = "processing-crafting",
    stack_size = 200
  },
  	{
    type = "recipe",
    name = "catalysator-blue",
    category = "crafting-with-fluid",
	subgroup = "catalysts",
    energy_required = 2,
	enabled = "false",
    ingredients ={
    {type="fluid", name="chlorine", amount=1},
	{type="item", name="small-alien-artifact-blue", amount=1},
    },
    results=
    {
      {type="item", name="catalysator-blue", amount=4},
    },
    icon = "__angelsprocessing__/graphics/icons/catalysator-blue.png",
    order = "a-a [catalysator-blue]",
	},
	{
    type = "recipe",
    name = "catalysator-green",
    category = "crafting-with-fluid",
	subgroup = "catalysts",
    energy_required = 2,
	enabled = "false",
    ingredients ={
    {type="fluid", name="chlorine", amount=1},
	{type="item", name="small-alien-artifact-green", amount=1},
    },
    results=
    {
      {type="item", name="catalysator-green", amount=4},
    },
    icon = "__angelsprocessing__/graphics/icons/catalysator-green.png",
    order = "a-a [catalysator-green]",
	},
	{
    type = "recipe",
    name = "catalysator-orange",
    category = "crafting-with-fluid",
	subgroup = "catalysts",
    energy_required = 2,
	enabled = "false",
    ingredients ={
    {type="fluid", name="chlorine", amount=1},
	{type="item", name="small-alien-artifact-orange", amount=1},
    },
    results=
    {
      {type="item", name="catalysator-orange", amount=4},
    },
    icon = "__angelsprocessing__/graphics/icons/catalysator-orange.png",
    order = "a-a [catalysator-orange]",
	},
	{
    type = "recipe",
    name = "catalysator-purple",
    category = "crafting-with-fluid",
	subgroup = "catalysts",
    energy_required = 2,
	enabled = "false",
    ingredients ={
    {type="fluid", name="chlorine", amount=1},
	{type="item", name="small-alien-artifact-purple", amount=1},
    },
    results=
    {
      {type="item", name="catalysator-purple", amount=4},
    },
    icon = "__angelsprocessing__/graphics/icons/catalysator-purple.png",
    order = "a-a [catalysator-purple]",
	},
	{
    type = "recipe",
    name = "catalysator-red",
    category = "crafting-with-fluid",
	subgroup = "catalysts",
    energy_required = 2,
	enabled = "false",
    ingredients ={
    {type="fluid", name="chlorine", amount=1},
	{type="item", name="small-alien-artifact-red", amount=1},
    },
    results=
    {
      {type="item", name="catalysator-red", amount=4},
    },
    icon = "__angelsprocessing__/graphics/icons/catalysator-red.png",
    order = "a-a [catalysator-red]",
	},
	{
    type = "recipe",
    name = "catalysator-yellow",
    category = "crafting-with-fluid",
	subgroup = "catalysts",
    energy_required = 2,
	enabled = "false",
    ingredients ={
    {type="fluid", name="chlorine", amount=1},
	{type="item", name="small-alien-artifact-yellow", amount=1},
    },
    results=
    {
      {type="item", name="catalysator-yellow", amount=4},
    },
    icon = "__angelsprocessing__/graphics/icons/catalysator-yellow.png",
    order = "a-a [catalysator-yellow]",
	},
		{
    type = "item",
    name = "small-alien-artifact",
    icon = "__angelsprocessing__/graphics/icons/small-alien-artifact.png",
    flags = { "goes-to-main-inventory" },
    subgroup = "raw-material",
    order = "g[alien-artifact]-a[pink]-a[small]",
    stack_size = 500,
    default_request_amount = 100
  },
  {
    type = "recipe",
    name = "alien-artifact-from-small",
    result = "alien-artifact",
    ingredients =
    {
      {"small-alien-artifact", 25}
    },
    energy_required = 1,
    enabled = "true",
    category = "crafting"
  },
  {
    type = "item",
    name = "catalysator-base",
    icon = "__angelsprocessing__/graphics/icons/catalysator-base.png",
    flags = {"goes-to-main-inventory"},
	subgroup = "processing-crafting",
    stack_size = 200
  },
  	{
    type = "recipe",
    name = "catalysator-base",
    category = "crafting-with-fluid",
	subgroup = "catalysts",
    energy_required = 2,
	enabled = "false",
    ingredients ={
    {type="fluid", name="petroleum-gas", amount=1},
	{type="item", name="small-alien-artifact", amount=1},
    },
    results=
    {
      {type="item", name="catalysator-base", amount=4},
    },
    icon = "__angelsprocessing__/graphics/icons/catalysator-base.png",
    order = "a-a [catalysator-base]",
	},
}
)
else
data:extend(
{
  {
    type = "item",
    name = "small-alien-artifact",
    icon = "__angelsprocessing__/graphics/icons/small-alien-artifact.png",
    flags = { "goes-to-main-inventory" },
    subgroup = "raw-material",
    order = "g[alien-artifact]-a[pink]-a[small]",
    stack_size = 500,
    default_request_amount = 100
  },
  {
    type = "recipe",
    name = "alien-artifact-from-small",
    result = "alien-artifact",
    ingredients =
    {
      {"small-alien-artifact", 25}
    },
    energy_required = 1,
    enabled = "true",
    category = "crafting"
  },
  {
    type = "item",
    name = "catalysator-base",
    icon = "__angelsprocessing__/graphics/icons/catalysator-base.png",
    flags = {"goes-to-main-inventory"},
	subgroup = "processing-crafting",
    stack_size = 200
  },
  	{
    type = "recipe",
    name = "catalysator-base",
    category = "crafting-with-fluid",
	subgroup = "catalysts",
    energy_required = 2,
	enabled = "false",
    ingredients ={
    {type="fluid", name="petroleum-gas", amount=1},
	{type="item", name="small-alien-artifact", amount=1},
    },
    results=
    {
      {type="item", name="catalysator-base", amount=4},
    },
    icon = "__angelsprocessing__/graphics/icons/catalysator-base.png",
    order = "a-a [catalysator-base]",
	},
}
)

end