-- Tech unlocks added for Base
table.insert(data.raw["technology"]["advanced-material-processing"].effects,{
	type="unlock-recipe",
	recipe="furnace-stone-steel"
})
table.insert(data.raw["technology"]["advanced-material-processing-2"].effects,{
	type="unlock-recipe",
	recipe="furnace-steel-electric"
})
table.insert(data.raw["technology"]["military"].effects,{
	type="unlock-recipe",
	recipe="gun-pistol-submachine"
})
table.insert(data.raw["technology"]["military-3"].effects,{
	type="unlock-recipe",
	recipe="shotgun-basic-combat"
})