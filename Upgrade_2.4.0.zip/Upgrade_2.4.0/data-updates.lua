require("prototypes.recipe.bobs-mods")
require("prototypes.recipe.ks-power")