require("prototypes.assembly")
require("prototypes.assembly-electronics")
require("prototypes.category")
