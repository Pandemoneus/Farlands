data.raw["item"]["raw-wood"].stack_size = 200
data.raw["item"]["stone-brick"].stack_size = 200
data.raw["item"]["concrete"].stack_size = 200

data.raw["item"]["straight-rail"].stack_size = 200
data.raw["item"]["curved-rail"].stack_size = 200

data.raw["item"]["sulfur"].stack_size = 200

if not (data.raw["item"]["tf-coke-coal"] == nil) then
    data.raw["item"]["tf-coke-coal"].stack_size = 200 
end
if not (data.raw["item"]["tf-charcoal"] == nil) then
    data.raw["item"]["tf-charcoal"].stack_size = 200
end

if not (data.raw["item"]["uranium-ore"] == nil) then
    data.raw["item"]["uranium-ore"].stack_size = 200
end