data.raw["item"]["raw-wood"].stack_size = 200
data.raw["item"]["stone-brick"].stack_size = 200
data.raw["item"]["concrete"].stack_size = 200

data.raw["item"]["straight-rail"].stack_size = 200
data.raw["item"]["curved-rail"].stack_size = 200

data.raw["item"]["sulfur"].stack_size = 200

if data.raw.item["tf-coke-coal"] then
    data.raw.item["tf-coke-coal"].stack_size = 200 
end
if data.raw.item["tf-charcoal"] then
    data.raw.item["tf-charcoal"].stack_size = 200
end

if data.raw.item["uranium-ore"] then
    data.raw.item["uranium-ore"].stack_size = 200
end

if data.raw.item["radar-mk2"] then
    data.raw.recipe["radar-mk2"].ingredients =
    {
        {"radar", 1},
        {"electronic-circuit", 5},
        {"steel-plate", 10},
        {"invar-alloy", 20},
        {"brass-alloy", 20}
    }
    
    data.raw.technology["radar-1"].prerequisites = {"electronics", "steel-processing", "invar-processing", "zinc-processing"}
    data.raw.technology["radar-1"].unit.count = 100
end

if data.raw.item["radar-mk3"] then
    data.raw.recipe["radar-mk3"].ingredients =
    {
        {"radar-mk2", 1},
        {"advanced-circuit", 5},
        {"cobalt-steel-alloy", 10},
        {"silver-plate", 20},
        {"gold-plate", 20},
    }
    
    data.raw.technology["radar-2"].prerequisites = {"radar-1", "advanced-electronics", "gold-processing", "cobalt-processing"}
    data.raw.technology["radar-2"].unit.count = 200
    data.raw.technology["radar-2"].unit.ingredients =
    {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
    }
end

if data.raw.item["radar-mk4"] then
    data.raw.recipe["radar-mk4"].ingredients =
    {
        {"radar-mk3", 1},
        {"processing-unit", 5},
        {"titanium-plate", 20},
        {"electrum-alloy", 20},
        {"silicon-wafer", 80},
    }
    
    data.raw.technology["radar-3"].prerequisites = {"radar-2", "advanced-electronics-2", "titanium-processing", "electrum-processing"}
    data.raw.technology["radar-3"].unit.count = 200
    data.raw.technology["radar-3"].unit.ingredients =
    {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
    }
end

if data.raw.item["radar-mk5"] then
    data.raw.recipe["radar-mk5"].ingredients =
    {
        {"radar-mk4", 1},
        {"advanced-processing-unit", 5},
        {"copper-tungsten-alloy", 20},
        {"nitinol-alloy", 20},
        {"large-accumulator-3", 1},
    }
    
    data.raw.technology["radar-4"].prerequisites = {"radar-3", "advanced-electronics-3", "tungsten-alloy-processing", "nitinol-processing", "bob-electric-energy-accumulators-4"}
    data.raw.technology["radar-4"].unit.count = 200
    data.raw.technology["radar-4"].unit.ingredients =
    {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"science-pack-4", 1},
    }
end