if data.raw.technology["titanium-processing"] then
  table.insert(data.raw.technology["titanium-processing"].effects,{type = "unlock-recipe", recipe = "titanium-chest"})
end

if data.raw.technology["tungsten-processing"] then
  table.insert(data.raw.technology["tungsten-processing"].effects,{type = "unlock-recipe", recipe = "tungsten-chest"})
end

if data.raw.technology["logistic-chests-bigger1"] then
  table.insert(data.raw.technology["logistic-chests-bigger1"].effects,{type = "unlock-recipe", recipe = "logistic-chest-titanium-storage"})
end



require("prototypes.inserter-recipe-updates")
require("prototypes.technology-updates")

--------------- ASSEMBLING MACHINES graphics -------------------

if assembling_graphics then
	data.raw["assembling-machine"]["assembling-machine-1"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-1.png"
	data.raw["assembling-machine"]["assembling-machine-2"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-2.png"
	data.raw["assembling-machine"]["assembling-machine-3"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-3.png"
	data.raw["assembling-machine"]["assembling-machine-4"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-4.png"
	data.raw["assembling-machine"]["assembling-machine-5"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-5.png"
	data.raw["assembling-machine"]["assembling-machine-6"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-6.png"

	data.raw["assembling-machine"]["electronics-machine-1"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/electronics-machine-1.png"
	data.raw["assembling-machine"]["electronics-machine-2"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/electronics-machine-2.png"
	data.raw["assembling-machine"]["electronics-machine-3"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/electronics-machine-3.png"

	data.raw.item["assembling-machine-1"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-1.png"
	data.raw.item["assembling-machine-2"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-2.png"
	data.raw.item["assembling-machine-3"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-3.png"
	data.raw.item["assembling-machine-4"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-4.png"
	data.raw.item["assembling-machine-5"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-5.png"
	data.raw.item["assembling-machine-6"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-6.png"

	data.raw.item["electronics-machine-1"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/electronics-machine-1.png"
	data.raw.item["electronics-machine-2"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/electronics-machine-2.png"
	data.raw.item["electronics-machine-3"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/electronics-machine-3.png"

	data.raw["assembling-machine"]["assembling-machine-2"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-2.png"

	data.raw["assembling-machine"]["assembling-machine-3"]["animation"] =
		{
		  filename = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-3.png",
		  priority = "high",
		  width = 142,
		  height = 113,
		  frame_count = 32,
		  line_length = 8,
		  shift = {0.84, -0.09},
		}



	data.raw["assembling-machine"]["assembling-machine-4"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-4.png"

	data.raw["assembling-machine"]["assembling-machine-5"]["fluid_boxes"][1]["pipe_picture"] = assembler2pipepictures()
	data.raw["assembling-machine"]["assembling-machine-5"]["fluid_boxes"][2]["pipe_picture"] = assembler2pipepictures()
	data.raw["assembling-machine"]["assembling-machine-5"]["animation"] = 
	    {
	      filename = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-5.png",
	      priority = "high",
	      width = 113,
	      height = 99,
	      frame_count = 32,
	      line_length = 8,
	      shift = {0.4, -0.06},
	    }

	data.raw["assembling-machine"]["assembling-machine-6"]["animation"] =
		{
		  filename =  "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-6.png",
		  priority = "high",
		  width = 142,
		  height = 113,
		  frame_count = 32,
		  line_length = 8,
		  shift = {0.84, -0.09},
		}




	data.raw["assembling-machine"]["electronics-machine-1"]["animation"] =
		{
		  filename = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-2.png",
		  priority = "high",
		  width = 113,
		  height = 99,
		  frame_count = 32,
		  line_length = 8,
		  shift = {0.4, -0.11},
		  scale = 0.66,
		}
	data.raw["assembling-machine"]["electronics-machine-2"]["animation"] =
		{
		  filename = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-4.png",
		  priority = "high",
		  width = 113,
		  height = 99,
		  frame_count = 32,
		  line_length = 8,
		  shift = {0.4, -0.08},
		  scale = 0.66,
		}
	data.raw["assembling-machine"]["electronics-machine-3"]["animation"] =
		{
		  filename = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-6.png",
		  priority = "high",
		  width = 142,
		  height = 113,
		  frame_count = 32,
		  line_length = 8,
		  shift = {0.84, -0.15},
		  scale = 0.66,
		}



end


-------- POLES graphics ---------------------
if poles_graphics_icons or poles_graphics then
	data.raw["electric-pole"]["medium-electric-pole"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole.png"
	data.raw["electric-pole"]["medium-electric-pole-2"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole-2.png"
	data.raw["electric-pole"]["medium-electric-pole-3"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole-3.png"
	data.raw["electric-pole"]["medium-electric-pole-4"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole-4.png"
	
	data.raw["electric-pole"]["big-electric-pole"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole.png"
	data.raw["electric-pole"]["big-electric-pole-2"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole-2.png"
	data.raw["electric-pole"]["big-electric-pole-3"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole-3.png"
	data.raw["electric-pole"]["big-electric-pole-4"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole-4.png"
	
	data.raw["electric-pole"]["substation"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation.png"
	data.raw["electric-pole"]["substation-2"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation-2.png"
	data.raw["electric-pole"]["substation-3"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation-3.png"
	data.raw["electric-pole"]["substation-4"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation-4.png"


	data.raw["item"]["medium-electric-pole"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole.png"
	data.raw["item"]["medium-electric-pole-2"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole-2.png"
	data.raw["item"]["medium-electric-pole-3"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole-3.png"
	data.raw["item"]["medium-electric-pole-4"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole-4.png"

	data.raw["item"]["big-electric-pole"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole.png"
	data.raw["item"]["big-electric-pole-2"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole-2.png"
	data.raw["item"]["big-electric-pole-3"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole-3.png"
	data.raw["item"]["big-electric-pole-4"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole-4.png"

	data.raw["item"]["substation"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation.png"
	data.raw["item"]["substation-2"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation-2.png"
	data.raw["item"]["substation-3"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation-3.png"
	data.raw["item"]["substation-4"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation-4.png"
end


if poles_graphics then
	data.raw["electric-pole"]["small-electric-pole"].fast_replaceable_group = "electric-pole-1x1"

	data.raw["electric-pole"]["medium-electric-pole"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/medium-electric-pole.png"
	data.raw["electric-pole"]["medium-electric-pole"].fast_replaceable_group = "electric-pole-1x1"

	data.raw["electric-pole"]["medium-electric-pole-2"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/medium-electric-pole-2.png"
	data.raw["electric-pole"]["medium-electric-pole-2"].fast_replaceable_group = "electric-pole-1x1"

	data.raw["electric-pole"]["medium-electric-pole-3"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/medium-electric-pole-3.png"
	data.raw["electric-pole"]["medium-electric-pole-3"].fast_replaceable_group = "electric-pole-1x1"

	data.raw["electric-pole"]["medium-electric-pole-4"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/medium-electric-pole-4.png"
	data.raw["electric-pole"]["medium-electric-pole-4"].fast_replaceable_group = "electric-pole-1x1"


	data.raw["electric-pole"]["big-electric-pole"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/big-electric-pole.png"
	data.raw["electric-pole"]["big-electric-pole"].fast_replaceable_group = "electric-pole-2x2"

	data.raw["electric-pole"]["big-electric-pole-2"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/big-electric-pole-2.png"
	data.raw["electric-pole"]["big-electric-pole-2"].fast_replaceable_group = "electric-pole-2x2"

	data.raw["electric-pole"]["big-electric-pole-3"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/big-electric-pole-3.png"
	data.raw["electric-pole"]["big-electric-pole-3"].fast_replaceable_group = "electric-pole-2x2"

	data.raw["electric-pole"]["big-electric-pole-4"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/big-electric-pole-4.png"
	data.raw["electric-pole"]["big-electric-pole-4"].fast_replaceable_group = "electric-pole-2x2"


	data.raw["electric-pole"]["substation"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/substation.png"
	data.raw["electric-pole"]["substation"].fast_replaceable_group = "electric-pole-2x2"

	data.raw["electric-pole"]["substation-2"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/substation-2.png"
	data.raw["electric-pole"]["substation-2"].fast_replaceable_group = "electric-pole-2x2"

	data.raw["electric-pole"]["substation-3"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/substation-3.png"
	data.raw["electric-pole"]["substation-3"].fast_replaceable_group = "electric-pole-2x2"

	data.raw["electric-pole"]["substation-4"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/substation-4.png"
	data.raw["electric-pole"]["substation-4"].fast_replaceable_group = "electric-pole-2x2"

end

-------- STORAGE TANK graphics ----------------------

if tank_graphics then

   if factorio_style then 
	data.raw["storage-tank"]["storage-tank"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-11.png"

	data.raw["storage-tank"]["storage-tank-2"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-21.png"

	data.raw["storage-tank"]["storage-tank-3"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-31.png"

	data.raw["storage-tank"]["storage-tank-4"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-41.png"

	data.raw["storage-tank"]["storage-tank"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-11.png"
	data.raw["storage-tank"]["storage-tank-2"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-21.png"
	data.raw["storage-tank"]["storage-tank-3"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-31.png"
	data.raw["storage-tank"]["storage-tank-4"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-41.png"

	data.raw["item"]["storage-tank"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-11.png"
	data.raw["item"]["storage-tank-2"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-21.png"
	data.raw["item"]["storage-tank-3"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-31.png"
	data.raw["item"]["storage-tank-4"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-41.png"
   else
	data.raw["storage-tank"]["storage-tank"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-1.png"

	data.raw["storage-tank"]["storage-tank-2"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-2.png"

	data.raw["storage-tank"]["storage-tank-3"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-3.png"

	data.raw["storage-tank"]["storage-tank-4"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-4.png"

	data.raw["storage-tank"]["storage-tank"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-1.png"
	data.raw["storage-tank"]["storage-tank-2"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-2.png"
	data.raw["storage-tank"]["storage-tank-3"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-3.png"
	data.raw["storage-tank"]["storage-tank-4"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-4.png"

	data.raw["item"]["storage-tank"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-1.png"
	data.raw["item"]["storage-tank-2"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-2.png"
	data.raw["item"]["storage-tank-3"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-3.png"
	data.raw["item"]["storage-tank-4"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-4.png"
   end   	
	
end
------------ BOILERS graphics ---------------

if boiler_graphics_icons or boiler_graphics then
	data.raw["boiler"]["boiler-2"].icon = "__ExtraChests__/graphics/entity/boilers/icon/boiler-2.png"
	data.raw["boiler"]["boiler-3"].icon = "__ExtraChests__/graphics/entity/boilers/icon/boiler-3.png"
	data.raw["boiler"]["boiler-4"].icon = "__ExtraChests__/graphics/entity/boilers/icon/boiler-4.png"

	data.raw["item"]["boiler-2"].icon = "__ExtraChests__/graphics/entity/boilers/icon/boiler-2.png"
	data.raw["item"]["boiler-3"].icon = "__ExtraChests__/graphics/entity/boilers/icon/boiler-3.png"
	data.raw["item"]["boiler-4"].icon = "__ExtraChests__/graphics/entity/boilers/icon/boiler-4.png"
end
if boiler_graphics then
	data.raw["boiler"]["boiler-2"]["fire"] ={left=boilerfires2.down,down=boilerfires2.left,left_down=boilerfires2.right,right_down=boilerfires2.left,left_up=boilerfires2.down,right_up=boilerfires2.down,t_up=boilerfires2.down,}

	data.raw["boiler"]["boiler-3"]["fire"] ={left=boilerfires3.down,down=boilerfires3.left,left_down=boilerfires3.right,right_down=boilerfires3.left,left_up=boilerfires3.down,right_up=boilerfires3.down,t_up=boilerfires3.down,}

	data.raw["boiler"]["boiler-4"]["fire"] ={left=boilerfires4.down,down=boilerfires4.left,left_down=boilerfires4.right,right_down=boilerfires4.left,left_up=boilerfires4.down,right_up=boilerfires4.down,t_up=boilerfires4.down,}

end

---------- STEAM ENGINE graphics --------------------

if steam_graphics_icons or steam_graphics then
	data.raw["generator"]["steam-engine"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine.png"
	data.raw["generator"]["steam-engine-2"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine-2.png"
	data.raw["generator"]["steam-engine-3"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine-3.png"
	--data.raw["generator"]["steam-engine-4"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine-4.png"

	data.raw["item"]["steam-engine"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine.png"
	data.raw["item"]["steam-engine-2"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine-2.png"
	data.raw["item"]["steam-engine-3"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine-3.png"
	--data.raw["item"]["steam-engine-4"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine-4.png"
end
if steam_graphics then

	if steam_lowres then
	
		data.raw["generator"]["steam-engine"]["horizontal_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-horizontal.png"
		data.raw["generator"]["steam-engine"]["horizontal_animation"]["line_length"] =  2
		data.raw["generator"]["steam-engine"]["horizontal_animation"]["animation_speed"] = 0.25
		data.raw["generator"]["steam-engine"]["horizontal_animation"]["frame_count"] = 8
		data.raw["generator"]["steam-engine"]["vertical_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-vertical.png"
		data.raw["generator"]["steam-engine"]["vertical_animation"]["line_length"] =  2
		data.raw["generator"]["steam-engine"]["vertical_animation"]["animation_speed"] = 0.25
		data.raw["generator"]["steam-engine"]["vertical_animation"]["frame_count"] = 8
		
		data.raw["generator"]["steam-engine-2"]["horizontal_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-horizontal-2.png"
		data.raw["generator"]["steam-engine-2"]["horizontal_animation"]["line_length"] =  2
		data.raw["generator"]["steam-engine-2"]["horizontal_animation"]["animation_speed"] = 0.25
		data.raw["generator"]["steam-engine-2"]["horizontal_animation"]["frame_count"] = 8
		data.raw["generator"]["steam-engine-2"]["vertical_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-vertical-2.png"
		data.raw["generator"]["steam-engine-2"]["vertical_animation"]["line_length"] =  2
		data.raw["generator"]["steam-engine-2"]["vertical_animation"]["animation_speed"] = 0.25
		data.raw["generator"]["steam-engine-2"]["vertical_animation"]["frame_count"] = 8
		
		data.raw["generator"]["steam-engine-3"]["horizontal_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-horizontal-3.png"
		data.raw["generator"]["steam-engine-3"]["horizontal_animation"]["line_length"] =  2
		data.raw["generator"]["steam-engine-3"]["horizontal_animation"]["animation_speed"] = 0.25
		data.raw["generator"]["steam-engine-3"]["horizontal_animation"]["frame_count"] = 8
		data.raw["generator"]["steam-engine-3"]["vertical_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-vertical-3.png"
		data.raw["generator"]["steam-engine-3"]["vertical_animation"]["line_length"] =  2
		data.raw["generator"]["steam-engine-3"]["vertical_animation"]["animation_speed"] = 0.25
		data.raw["generator"]["steam-engine-3"]["vertical_animation"]["frame_count"] = 8
	
	else
		data.raw["generator"]["steam-engine-2"]["horizontal_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-horizontal-2.png"
		data.raw["generator"]["steam-engine-2"]["vertical_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-vertical-2.png"

		data.raw["generator"]["steam-engine-3"]["horizontal_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-horizontal-3.png"
		data.raw["generator"]["steam-engine-3"]["vertical_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-vertical-3.png"

		--data.raw["generator"]["steam-engine-4"]["horizontal_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-horizontal-4.png"
		--data.raw["generator"]["steam-engine-4"]["vertical_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-vertical-4.png"
	end 
end

---------- SOLAR PLANES graphics --------------------

if solar_graphics_icons or solar_graphics then
	data.raw["solar-panel"]["solar-panel-small"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-s1.png"
	data.raw["solar-panel"]["solar-panel-small-2"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-s2.png"
	data.raw["solar-panel"]["solar-panel-small-3"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-s3.png"

	data.raw["solar-panel"]["solar-panel"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-m1.png"
	data.raw["solar-panel"]["solar-panel-2"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-m2.png"
	data.raw["solar-panel"]["solar-panel-3"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-m3.png"

	data.raw["solar-panel"]["solar-panel-large"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-l1.png"
	data.raw["solar-panel"]["solar-panel-large-3"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-l3.png"
	data.raw["solar-panel"]["solar-panel-large-2"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-l2.png"

	data.raw["item"]["solar-panel-small"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-s1.png"
	data.raw["item"]["solar-panel-small-2"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-s2.png"
	data.raw["item"]["solar-panel-small-3"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-s3.png"

	data.raw["item"]["solar-panel"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-m1.png"
	data.raw["item"]["solar-panel-2"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-m2.png"
	data.raw["item"]["solar-panel-3"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-m3.png"

	data.raw["item"]["solar-panel-large"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-l1.png"
	data.raw["item"]["solar-panel-large-2"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-l2.png"
	data.raw["item"]["solar-panel-large-3"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-l3.png"


	data.raw.technology["solar-energy"].icon       = "__ExtraChests__/graphics/icons/technology/solar-energy-t1-tech.png"
	data.raw.technology["bob-solar-energy-2"].icon = "__ExtraChests__/graphics/icons/technology/solar-energy-t2-tech.png"
	data.raw.technology["bob-solar-energy-3"].icon = "__ExtraChests__/graphics/icons/technology/solar-energy-t3-tech.png"
	data.raw.technology["bob-solar-energy-4"].icon = "__ExtraChests__/graphics/icons/technology/solar-energy-t4-tech.png"
end
if solar_graphics then

	data.raw["solar-panel"]["solar-panel-small"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-s1.png"

	data.raw["solar-panel"]["solar-panel-small-2"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-s2.png"

	data.raw["solar-panel"]["solar-panel-small-3"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-s3.png"


	data.raw["solar-panel"]["solar-panel"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-m1.png"

	data.raw["solar-panel"]["solar-panel-2"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-m2.png"

	data.raw["solar-panel"]["solar-panel-3"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-m3.png"


	data.raw["solar-panel"]["solar-panel-large"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-l1.png"

	data.raw["solar-panel"]["solar-panel-large-2"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-l2.png"

	data.raw["solar-panel"]["solar-panel-large-3"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-l3.png"



end

---------- ACCUMULATORS graphics --------------------

if accumlator_graphics_icons or accumlator_graphics then
	data.raw["accumulator"]["large-accumulator"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk1h-icon.png"
	data.raw["accumulator"]["fast-accumulator"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk1f-icon.png"
	data.raw["accumulator"]["slow-accumulator"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk1s-icon.png"
	data.raw["accumulator"]["large-accumulator-2"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk2h-icon.png"
	data.raw["accumulator"]["fast-accumulator-2"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk2f-icon.png"
	data.raw["accumulator"]["slow-accumulator-2"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk2s-icon.png"
	data.raw["accumulator"]["large-accumulator-3"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk3h-icon.png"
	data.raw["accumulator"]["fast-accumulator-3"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk3f-icon.png"
	data.raw["accumulator"]["slow-accumulator-3"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk3s-icon.png"

	data.raw["item"]["large-accumulator"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk1h-icon.png"
	data.raw["item"]["fast-accumulator"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk1f-icon.png"
	data.raw["item"]["slow-accumulator"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk1s-icon.png"
	data.raw["item"]["large-accumulator-2"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk2h-icon.png"
	data.raw["item"]["fast-accumulator-2"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk2f-icon.png"
	data.raw["item"]["slow-accumulator-2"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk2s-icon.png"
	data.raw["item"]["large-accumulator-3"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk3h-icon.png"
	data.raw["item"]["fast-accumulator-3"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk3f-icon.png"
	data.raw["item"]["slow-accumulator-3"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk3s-icon.png"
end

if accumlator_graphics then
	data.raw["accumulator"]["large-accumulator"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1h.png"
	data.raw["accumulator"]["fast-accumulator"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1f.png"
	data.raw["accumulator"]["slow-accumulator"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1s.png"
	data.raw["accumulator"]["large-accumulator-2"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2h.png"
	data.raw["accumulator"]["fast-accumulator-2"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2f.png"
	data.raw["accumulator"]["slow-accumulator-2"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2s.png"
	data.raw["accumulator"]["large-accumulator-3"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3h.png"
	data.raw["accumulator"]["fast-accumulator-3"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3f.png"
	data.raw["accumulator"]["slow-accumulator-3"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3s.png"

	if accumlator_lowres then 										
		data.raw["accumulator"]["large-accumulator"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk1h-charge-animation.png"
		data.raw["accumulator"]["large-accumulator"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["large-accumulator"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["large-accumulator"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["large-accumulator"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk1h-discharge-animation.png"
		data.raw["accumulator"]["large-accumulator"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["large-accumulator"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["large-accumulator"]["discharge_animation"]["frame_count"] = 12
		
		data.raw["accumulator"]["fast-accumulator"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk1f-charge-animation.png"
		data.raw["accumulator"]["fast-accumulator"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["fast-accumulator"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["fast-accumulator"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["fast-accumulator"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk1f-discharge-animation.png"
		data.raw["accumulator"]["fast-accumulator"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["fast-accumulator"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["fast-accumulator"]["discharge_animation"]["frame_count"] = 12

		data.raw["accumulator"]["slow-accumulator"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk1s-charge-animation.png"
		data.raw["accumulator"]["slow-accumulator"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["slow-accumulator"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["slow-accumulator"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["slow-accumulator"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk1s-discharge-animation.png"
		data.raw["accumulator"]["slow-accumulator"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["slow-accumulator"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["slow-accumulator"]["discharge_animation"]["frame_count"] = 12


		data.raw["accumulator"]["large-accumulator-2"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk2h-charge-animation.png"
		data.raw["accumulator"]["large-accumulator-2"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["large-accumulator-2"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["large-accumulator-2"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["large-accumulator-2"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk2h-discharge-animation.png"
		data.raw["accumulator"]["large-accumulator-2"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["large-accumulator-2"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["large-accumulator-2"]["discharge_animation"]["frame_count"] = 12
		
		data.raw["accumulator"]["fast-accumulator-2"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk2f-charge-animation.png"
		data.raw["accumulator"]["fast-accumulator-2"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["fast-accumulator-2"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["fast-accumulator-2"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["fast-accumulator-2"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk2f-discharge-animation.png"
		data.raw["accumulator"]["fast-accumulator-2"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["fast-accumulator-2"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["fast-accumulator-2"]["discharge_animation"]["frame_count"] = 12
		
		data.raw["accumulator"]["slow-accumulator-2"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk2s-charge-animation.png"
		data.raw["accumulator"]["slow-accumulator-2"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["slow-accumulator-2"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["slow-accumulator-2"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["slow-accumulator-2"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk2s-discharge-animation.png"
		data.raw["accumulator"]["slow-accumulator-2"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["slow-accumulator-2"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["slow-accumulator-2"]["discharge_animation"]["frame_count"] = 12


		data.raw["accumulator"]["large-accumulator-3"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk3h-charge-animation.png"
		data.raw["accumulator"]["large-accumulator-3"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["large-accumulator-3"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["large-accumulator-3"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["large-accumulator-3"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk3h-discharge-animation.png"
		data.raw["accumulator"]["large-accumulator-3"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["large-accumulator-3"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["large-accumulator-3"]["discharge_animation"]["frame_count"] = 12
		
		data.raw["accumulator"]["fast-accumulator-3"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk3f-charge-animation.png"
		data.raw["accumulator"]["fast-accumulator-3"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["fast-accumulator-3"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["fast-accumulator-3"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["fast-accumulator-3"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk3f-discharge-animation.png"
		data.raw["accumulator"]["fast-accumulator-3"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["fast-accumulator-3"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["fast-accumulator-3"]["discharge_animation"]["frame_count"] = 12
		
		data.raw["accumulator"]["slow-accumulator-3"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk3s-charge-animation.png"
		data.raw["accumulator"]["slow-accumulator-3"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["slow-accumulator-3"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["slow-accumulator-3"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["slow-accumulator-3"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk3s-discharge-animation.png"
		data.raw["accumulator"]["slow-accumulator-3"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["slow-accumulator-3"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["slow-accumulator-3"]["discharge_animation"]["frame_count"] = 12
		
	else
		data.raw["accumulator"]["large-accumulator"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1h-charge-animation.png"
		data.raw["accumulator"]["large-accumulator"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1h-discharge-animation.png"

		data.raw["accumulator"]["fast-accumulator"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1f-charge-animation.png"
		data.raw["accumulator"]["fast-accumulator"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1f-discharge-animation.png"

		data.raw["accumulator"]["slow-accumulator"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1s-charge-animation.png"
		data.raw["accumulator"]["slow-accumulator"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1s-discharge-animation.png"


		data.raw["accumulator"]["large-accumulator-2"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2h-charge-animation.png"
		data.raw["accumulator"]["large-accumulator-2"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2h-discharge-animation.png"

		data.raw["accumulator"]["fast-accumulator-2"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2f-charge-animation.png"
		data.raw["accumulator"]["fast-accumulator-2"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2f-discharge-animation.png"

		data.raw["accumulator"]["slow-accumulator-2"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2s-charge-animation.png"
		data.raw["accumulator"]["slow-accumulator-2"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2s-discharge-animation.png"


		data.raw["accumulator"]["large-accumulator-3"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3h-charge-animation.png"
		data.raw["accumulator"]["large-accumulator-3"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3h-discharge-animation.png"

		data.raw["accumulator"]["fast-accumulator-3"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3f-charge-animation.png"
		data.raw["accumulator"]["fast-accumulator-3"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3f-discharge-animation.png"

		data.raw["accumulator"]["slow-accumulator-3"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3s-charge-animation.png"
		data.raw["accumulator"]["slow-accumulator-3"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3s-discharge-animation.png"
	end
end

---------- ROBOCHESTS graphics --------------------

if robochest_graphics then

	data.raw["roboport"]["bob-robochest"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest.png"
	data.raw["roboport"]["bob-robochest-2"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest-2.png"
	data.raw["roboport"]["bob-robochest-3"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest-3.png"
	data.raw["roboport"]["bob-robochest-4"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest-4.png"

	data.raw["roboport"]["bob-robochest"]["base"]["filename"] = "__ExtraChests__/graphics/entity/roboports/robochest.png"
	data.raw["roboport"]["bob-robochest-2"]["base"]["filename"] = "__ExtraChests__/graphics/entity/roboports/robochest-2.png"
	data.raw["roboport"]["bob-robochest-3"]["base"]["filename"] = "__ExtraChests__/graphics/entity/roboports/robochest-3.png"
	data.raw["roboport"]["bob-robochest-4"]["base"]["filename"] = "__ExtraChests__/graphics/entity/roboports/robochest-4.png"

	data.raw["item"]["bob-robochest"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest.png"
	data.raw["item"]["bob-robochest-2"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest-2.png"
	data.raw["item"]["bob-robochest-3"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest-3.png"
	data.raw["item"]["bob-robochest-4"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest-4.png"

end

---------- RADARS graphics -------------------

if radar_graphics then
	data.raw["radar"]["radar"].icon = "__ExtraChests__/graphics/entity/radars/icon/radar-1.png"
	data.raw["radar"]["radar"]["pictures"]["filename"] = "__ExtraChests__/graphics/entity/radars/radar-1.png"

	data.raw["item"]["radar"].icon = "__ExtraChests__/graphics/entity/radars/icon/radar-1.png"
end

---------- DRILLS graphics -------------------

if drill_graphics or drill_graphics_icons then
	data.raw["mining-drill"]["bob-mining-drill-1"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-1.png"
	data.raw["mining-drill"]["bob-mining-drill-2"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-2.png"
	data.raw["mining-drill"]["bob-mining-drill-3"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-3.png"
	data.raw["mining-drill"]["bob-mining-drill-4"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-4.png"

	data.raw["mining-drill"]["bob-area-mining-drill-1"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-1.png"
	data.raw["mining-drill"]["bob-area-mining-drill-2"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-2.png"
	data.raw["mining-drill"]["bob-area-mining-drill-3"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-3.png"
	data.raw["mining-drill"]["bob-area-mining-drill-4"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-4.png"


	data.raw["item"]["bob-mining-drill-1"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-1.png"
	data.raw["item"]["bob-mining-drill-2"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-2.png"
	data.raw["item"]["bob-mining-drill-3"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-3.png"
	data.raw["item"]["bob-mining-drill-4"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-4.png"


	data.raw["item"]["bob-area-mining-drill-1"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-1.png"
	data.raw["item"]["bob-area-mining-drill-2"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-2.png"
	data.raw["item"]["bob-area-mining-drill-3"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-3.png"
	data.raw["item"]["bob-area-mining-drill-4"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-4.png"
end
if drill_graphics then

	if drill_lowres then

		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/north-0.png"
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/east-0.png"
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/south-0.png"
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/west-0.png"

		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/north-1.png"
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/east-1.png"
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/south-1.png"
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/west-1.png"

		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/north-2.png"
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/east-2.png"
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/south-2.png"
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/west-2.png"

		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/north-3.png"
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/east-3.png"
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/south-3.png"
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/west-3.png"

		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/north-4.png"
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/east-4.png"
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/south-4.png"
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/west-4.png"


		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["north"]["animation_speed"] = 0.18
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["north"]["frame_count"] = 16
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["north"]["shift"] = {0.2, -0.2}

		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["east"]["animation_speed"] = 0.18
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["east"]["frame_count"] = 16

		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["south"]["animation_speed"] = 0.18
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["south"]["frame_count"] = 16

		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["west"]["animation_speed"] = 0.18
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["west"]["frame_count"] = 16



		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["north"]["animation_speed"] = 0.25
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["north"]["frame_count"] = 16
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["north"]["shift"] = {0.2, -0.2}

		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["east"]["animation_speed"] = 0.25
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["east"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["south"]["animation_speed"] = 0.25
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["south"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["west"]["animation_speed"] = 0.25
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["west"]["frame_count"] = 16


		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["north"]["animation_speed"] = 0.5
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["north"]["frame_count"] = 16
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["north"]["shift"] = {0.2, -0.2}

		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["east"]["animation_speed"] = 0.5
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["east"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["south"]["animation_speed"] = 0.5
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["south"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["west"]["animation_speed"] = 0.5
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["west"]["frame_count"] = 16


		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["north"]["animation_speed"] = 0.75
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["north"]["frame_count"] = 16
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["north"]["shift"] = {0.2, -0.2}

		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["east"]["animation_speed"] = 0.75
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["east"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["south"]["animation_speed"] = 0.75
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["south"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["west"]["animation_speed"] = 0.75
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["west"]["frame_count"] = 16


		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["north"]["animation_speed"] = 1
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["north"]["frame_count"] = 16
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["north"]["shift"] = {0.2, -0.2}

		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["east"]["animation_speed"] = 1
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["east"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["south"]["animation_speed"] = 1
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["south"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["west"]["animation_speed"] = 1
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["west"]["frame_count"] = 16


	
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-north-1.png"
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-east-1.png"
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-south-1.png"
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-west-1.png"

		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-north-2.png"
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-east-2.png"
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-south-2.png"
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-west-2.png"

		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-north-3.png"
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-east-3.png"
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-south-3.png"
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-west-3.png"

		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-north-4.png"
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-east-4.png"
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-south-4.png"
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-west-4.png"
	

		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["north"]["animation_speed"] = 0.2
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["north"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["north"]["run_mode"] = "forward"

		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["east"]["animation_speed"] = 0.2
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["east"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["east"]["run_mode"] = "forward"

		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["south"]["animation_speed"] = 0.2
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["south"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["south"]["run_mode"] = "forward"

		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["west"]["animation_speed"] = 0.2
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["west"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["west"]["run_mode"] = "forward"



		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["north"]["animation_speed"] = 0.26
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["north"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["north"]["run_mode"] = "forward"

		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["east"]["animation_speed"] = 0.26
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["east"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["east"]["run_mode"] = "forward"

		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["south"]["animation_speed"] = 0.26
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["south"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["south"]["run_mode"] = "forward"

		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["west"]["animation_speed"] = 0.26
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["west"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["west"]["run_mode"] = "forward"


		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["north"]["animation_speed"] = 0.32
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["north"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["north"]["run_mode"] = "forward"

		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["east"]["animation_speed"] = 0.32
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["east"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["east"]["run_mode"] = "forward"

		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["south"]["animation_speed"] = 0.32
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["south"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["south"]["run_mode"] = "forward"

		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["west"]["animation_speed"] = 0.32
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["west"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["west"]["run_mode"] = "forward"



		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["north"]["animation_speed"] = 0.4
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["north"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["north"]["run_mode"] = "forward"

		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["east"]["animation_speed"] = 0.4
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["east"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["east"]["run_mode"] = "forward"

		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["south"]["animation_speed"] = 0.4
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["south"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["south"]["run_mode"] = "forward"

		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["west"]["animation_speed"] = 0.4
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["west"]["frame_count"] = 8
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["west"]["run_mode"] = "forward"


	else
	
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/north-0.png"
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/east-0.png"
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/south-0.png"
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/west-0.png"

		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/north-1.png"
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/east-1.png"
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/south-1.png"
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/west-1.png"

		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/north-2.png"
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/east-2.png"
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/south-2.png"
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/west-2.png"

		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/north-3.png"
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/east-3.png"
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/south-3.png"
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/west-3.png"

		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/north-4.png"
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/east-4.png"
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/south-4.png"
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/west-4.png"


		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-north-1.png"
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-east-1.png"
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-south-1.png"
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-west-1.png"

		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-north-2.png"
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-east-2.png"
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-south-2.png"
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-west-2.png"

		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-north-3.png"
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-east-3.png"
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-south-3.png"
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-west-3.png"

		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-north-4.png"
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-east-4.png"
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-south-4.png"
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-west-4.png"

		
	end

end



---------- PUMPJACKS graphics -------------------

if pumpjack_graphics then

	data.raw["mining-drill"]["pumpjack"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack.png"
	data.raw["mining-drill"]["pumpjack"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
	data.raw["mining-drill"]["pumpjack"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation.png"

	data.raw["mining-drill"]["bob-pumpjack-1"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-1.png"
	data.raw["mining-drill"]["bob-pumpjack-1"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
	data.raw["mining-drill"]["bob-pumpjack-1"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-1.png"

	data.raw["mining-drill"]["bob-pumpjack-2"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-2.png"
	data.raw["mining-drill"]["bob-pumpjack-2"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
	data.raw["mining-drill"]["bob-pumpjack-2"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-2.png"

	data.raw["mining-drill"]["bob-pumpjack-3"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-3.png"
	data.raw["mining-drill"]["bob-pumpjack-3"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
	data.raw["mining-drill"]["bob-pumpjack-3"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-3.png"

	data.raw["mining-drill"]["bob-pumpjack-4"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-4.png"
	data.raw["mining-drill"]["bob-pumpjack-4"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
	data.raw["mining-drill"]["bob-pumpjack-4"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-4.png"

	data.raw["item"]["pumpjack"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack.png"
	data.raw["item"]["bob-pumpjack-1"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-1.png"
	data.raw["item"]["bob-pumpjack-2"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-2.png"
	data.raw["item"]["bob-pumpjack-3"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-3.png"
	data.raw["item"]["bob-pumpjack-4"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-4.png"
end

--------------- TRANSPORT-BELTS graphics -------------------


if belts_graphics then

	data.raw["transport-belt"]["green-transport-belt"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/purple-transport-belt.png"
	data.raw["transport-belt"]["green-transport-belt"]["animations"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-transport-belt.png"
	data.raw["transport-belt"]["green-transport-belt"].belt_horizontal = purple_belt_horizontal
	data.raw["transport-belt"]["green-transport-belt"].belt_vertical = purple_belt_vertical
	data.raw["transport-belt"]["green-transport-belt"].ending_top = purple_belt_ending_top
	data.raw["transport-belt"]["green-transport-belt"].ending_bottom = purple_belt_ending_bottom
	data.raw["transport-belt"]["green-transport-belt"].ending_side = purple_belt_ending_side
	data.raw["transport-belt"]["green-transport-belt"].starting_top = purple_belt_starting_top
	data.raw["transport-belt"]["green-transport-belt"].starting_bottom = purple_belt_starting_bottom
	data.raw["transport-belt"]["green-transport-belt"].starting_side = purple_belt_starting_side



	data.raw["transport-belt"]["purple-transport-belt"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/green-transport-belt.png"
	data.raw["transport-belt"]["purple-transport-belt"]["animations"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-transport-belt.png"
	data.raw["transport-belt"]["purple-transport-belt"].belt_horizontal = green_belt_horizontal
	data.raw["transport-belt"]["purple-transport-belt"].belt_vertical = green_belt_vertical
	data.raw["transport-belt"]["purple-transport-belt"].ending_top = green_belt_ending_top
	data.raw["transport-belt"]["purple-transport-belt"].ending_bottom = green_belt_ending_bottom
	data.raw["transport-belt"]["purple-transport-belt"].ending_side = green_belt_ending_side
	data.raw["transport-belt"]["purple-transport-belt"].starting_top = green_belt_starting_top
	data.raw["transport-belt"]["purple-transport-belt"].starting_bottom = green_belt_starting_bottom
	data.raw["transport-belt"]["purple-transport-belt"].starting_side = green_belt_starting_side


	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/purple-transport-belt-to-ground.png"
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].belt_horizontal = purple_belt_horizontal
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].belt_vertical = purple_belt_vertical
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].ending_top = purple_belt_ending_top
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].ending_bottom = purple_belt_ending_bottom
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].ending_side = purple_belt_ending_side
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].starting_top = purple_belt_starting_top
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].starting_bottom = purple_belt_starting_bottom
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].starting_side = purple_belt_starting_side
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"]["structure"]["direction_in"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-transport-belt-to-ground-structure.png"
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"]["structure"]["direction_out"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-transport-belt-to-ground-structure.png"



	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/green-transport-belt-to-ground.png"
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].belt_horizontal = green_belt_horizontal
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].belt_vertical = green_belt_vertical
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].ending_top = green_belt_ending_top
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].ending_bottom = green_belt_ending_bottom
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].ending_side = green_belt_ending_side
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].starting_top = green_belt_starting_top
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].starting_bottom = green_belt_starting_bottom
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].starting_side = green_belt_starting_side
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"]["structure"]["direction_in"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-transport-belt-to-ground-structure.png"
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"]["structure"]["direction_out"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-transport-belt-to-ground-structure.png"


	data.raw["splitter"]["green-splitter"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/purple-splitter.png"
	data.raw["splitter"]["green-splitter"].belt_horizontal = purple_belt_horizontal
	data.raw["splitter"]["green-splitter"].belt_vertical = purple_belt_vertical
	data.raw["splitter"]["green-splitter"].ending_top = purple_belt_ending_top
	data.raw["splitter"]["green-splitter"].ending_bottom = purple_belt_ending_bottom
	data.raw["splitter"]["green-splitter"].ending_side = purple_belt_ending_side
	data.raw["splitter"]["green-splitter"].starting_top = purple_belt_starting_top
	data.raw["splitter"]["green-splitter"].starting_bottom = purple_belt_starting_bottom
	data.raw["splitter"]["green-splitter"].starting_side = purple_belt_starting_side
	data.raw["splitter"]["green-splitter"]["structure"]["north"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-splitter-north.png"
	data.raw["splitter"]["green-splitter"]["structure"]["east"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-splitter-east.png"
	data.raw["splitter"]["green-splitter"]["structure"]["south"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-splitter-south.png"
	data.raw["splitter"]["green-splitter"]["structure"]["west"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-splitter-west.png"

	data.raw["splitter"]["purple-splitter"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/green-splitter.png"
	data.raw["splitter"]["purple-splitter"].belt_horizontal = green_belt_horizontal
	data.raw["splitter"]["purple-splitter"].belt_vertical = green_belt_vertical
	data.raw["splitter"]["purple-splitter"].ending_top = green_belt_ending_top
	data.raw["splitter"]["purple-splitter"].ending_bottom = green_belt_ending_bottom
	data.raw["splitter"]["purple-splitter"].ending_side = green_belt_ending_side
	data.raw["splitter"]["purple-splitter"].starting_top = green_belt_starting_top
	data.raw["splitter"]["purple-splitter"].starting_bottom = green_belt_starting_bottom
	data.raw["splitter"]["purple-splitter"].starting_side = green_belt_starting_side
	data.raw["splitter"]["purple-splitter"]["structure"]["north"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-splitter-north.png"
	data.raw["splitter"]["purple-splitter"]["structure"]["east"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-splitter-east.png"
	data.raw["splitter"]["purple-splitter"]["structure"]["south"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-splitter-south.png"
	data.raw["splitter"]["purple-splitter"]["structure"]["west"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-splitter-west.png"



	data.raw.item["green-transport-belt"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/purple-transport-belt.png"
	data.raw.item["purple-transport-belt"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/green-transport-belt.png"

	data.raw.item["green-transport-belt-to-ground"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/purple-transport-belt-to-ground.png"
	data.raw.item["purple-transport-belt-to-ground"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/green-transport-belt-to-ground.png"

	data.raw.item["green-splitter"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/purple-splitter.png"
	data.raw.item["purple-splitter"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/green-splitter.png"
end

--------------- CHEMICAL PLANTS graphics -------------------

if chemicalplant_graphics then

	data.raw["assembling-machine"]["chemical-plant"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant.png"
	data.raw["assembling-machine"]["chemical-plant-2"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant-2.png"
	data.raw["assembling-machine"]["chemical-plant-3"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant-3.png"
	data.raw["assembling-machine"]["chemical-plant-4"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant-4.png"


	--data.raw["assembling-machine"]["chemical-plant"]["animation"] = bob_chemical_plant_animation({r = 0.5, g = 0.1, b = 0.7})
	data.raw["assembling-machine"]["chemical-plant-2"]["animation"] = bob_chemical_plant_animation({r = 0.7, g = 0.2, b = 0.1})
	data.raw["assembling-machine"]["chemical-plant-3"]["animation"] = bob_chemical_plant_animation({r = 0.2, g = 0.0, b = 0.7})
	data.raw["assembling-machine"]["chemical-plant-4"]["animation"] = bob_chemical_plant_animation({r = 0.5, g = 0.1, b = 0.7})

	data.raw["item"]["chemical-plant"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant.png"
	data.raw["item"]["chemical-plant-2"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant-2.png"
	data.raw["item"]["chemical-plant-3"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant-3.png"
	data.raw["item"]["chemical-plant-4"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant-4.png"

end


--------------- ELECTROLISERS graphics -------------------

if electroliser_graphics then

	data.raw["assembling-machine"]["electrolyser"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser.png"
	data.raw["assembling-machine"]["electrolyser-2"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser-2.png"
	data.raw["assembling-machine"]["electrolyser-3"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser-3.png"
	data.raw["assembling-machine"]["electrolyser-4"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser-4.png"

	data.raw["assembling-machine"]["electrolyser"]["animation"]["north"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt1u.png"
	data.raw["assembling-machine"]["electrolyser"]["animation"]["west"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t1l.png"
	data.raw["assembling-machine"]["electrolyser"]["animation"]["south"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt1d.png"
	data.raw["assembling-machine"]["electrolyser"]["animation"]["east"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t1r.png"

	data.raw["assembling-machine"]["electrolyser-2"]["animation"]["north"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt2u.png"
	data.raw["assembling-machine"]["electrolyser-2"]["animation"]["west"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t2l.png"
	data.raw["assembling-machine"]["electrolyser-2"]["animation"]["south"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt2d.png"
	data.raw["assembling-machine"]["electrolyser-2"]["animation"]["east"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t2r.png"

	data.raw["assembling-machine"]["electrolyser-3"]["animation"]["north"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt3u.png"
	data.raw["assembling-machine"]["electrolyser-3"]["animation"]["west"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t3l.png"
	data.raw["assembling-machine"]["electrolyser-3"]["animation"]["south"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt3d.png"
	data.raw["assembling-machine"]["electrolyser-3"]["animation"]["east"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t3r.png"

	data.raw["assembling-machine"]["electrolyser-4"]["animation"]["north"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt4u.png"
	data.raw["assembling-machine"]["electrolyser-4"]["animation"]["west"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t4l.png"
	data.raw["assembling-machine"]["electrolyser-4"]["animation"]["south"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt4d.png"
	data.raw["assembling-machine"]["electrolyser-4"]["animation"]["east"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t4r.png"


	data.raw["item"]["electrolyser"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser.png"
	data.raw["item"]["electrolyser-2"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser-2.png"
	data.raw["item"]["electrolyser-3"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser-3.png"
	data.raw["item"]["electrolyser-4"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser-4.png"

end


--------------- ELECTRIC FURNACE graphics -------------------

if electricfurnace_graphics then
								     
	data.raw["furnace"]["steel-furnace"].icon = "__ExtraChests__/graphics/entity/steel-furnace/icon/steel-furnace.png"
	data.raw["furnace"]["electric-furnace"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/yellow-electric-furnace.png"
	data.raw["furnace"]["electric-furnace"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/electric-furnaces/yellow-electric-furnace.png"


	data.raw["assembling-machine"]["electric-mixing-furnace"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/blue-electric-furnace.png"
	data.raw["assembling-machine"]["electric-mixing-furnace"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/electric-furnaces/blue-electric-furnace.png"

	data.raw["assembling-machine"]["chemical-furnace"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/red-electric-furnace.png"
	data.raw["assembling-machine"]["chemical-furnace"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/electric-furnaces/red-electric-furnace.png"

	data.raw["assembling-machine"]["electric-chemical-mixing-furnace"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/purple-electric-furnace.png"
	data.raw["assembling-machine"]["electric-chemical-mixing-furnace"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/electric-furnaces/purple-electric-furnace.png"

	data.raw["assembling-machine"]["electric-chemical-mixing-furnace-2"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/green-electric-furnace.png"
	data.raw["assembling-machine"]["electric-chemical-mixing-furnace-2"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/electric-furnaces/green-electric-furnace.png"



	data.raw["item"]["steel-furnace"].icon = "__ExtraChests__/graphics/entity/steel-furnace/icon/steel-furnace.png"
	data.raw["item"]["electric-furnace"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/yellow-electric-furnace.png"
	data.raw["item"]["electric-mixing-furnace"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/blue-electric-furnace.png"
	data.raw["item"]["chemical-furnace"].icon ="__ExtraChests__/graphics/entity/electric-furnaces/icon/red-electric-furnace.png"
	data.raw["item"]["electric-chemical-mixing-furnace"].icon =  "__ExtraChests__/graphics/entity/electric-furnaces/icon/purple-electric-furnace.png"
	data.raw["item"]["electric-chemical-mixing-furnace-2"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/green-electric-furnace.png"
end


--------------- LIQUIDS graphics -------------------

if liquid_graphics then

	data.raw.recipe["basic-oil-processing"].icon = "__ExtraChests__/graphics/icons/fluids/basic-oil-processing.png"
	data.raw.recipe["advanced-oil-processing"].icon = "__ExtraChests__/graphics/icons/fluids/advanced-oil-processing.png"
	data.raw.recipe["bob-oil-processing"].icon = "__ExtraChests__/graphics/icons/fluids/bob-oil-processing.png"


	data.raw.recipe["salt-water-electrolysis"].icon = "__ExtraChests__/graphics/icons/fluids/salt-water-electrolysis.png"
	data.raw.recipe["lithium-water-electrolysis"].icon = "__ExtraChests__/graphics/icons/fluids/lithium-water-electrolysis.png"
	data.raw.recipe["tungstic-acid"].icon = "__ExtraChests__/graphics/icons/fluids/tungstic-acid-recipe.png"

	data.raw.recipe["nitrogen"].icon = "__ExtraChests__/graphics/icons/fluids/nitrogen-recipe.png"

	data.raw.recipe["lead-oxide"].icon = "__ExtraChests__/graphics/icons/fluids/sulfur-lead-oxide-recipe.png"

	data.raw.recipe["bob-nickel-plate"].icon = "__ExtraChests__/graphics/icons/fluids/nickel-sulfur-recipe.png"


	data.raw.item["liquid-fuel-canister"].icon = "__ExtraChests__/graphics/icons/fluids/liquid-fuel-canister.png"
	data.raw.item["ferric-chloride-canister"].icon = "__ExtraChests__/graphics/icons/fluids/ferric-chloride-canister.png"


end

--------------- BOBS MATERIALS graphics -------------------


--------------- CIRCUITS graphics -------------------

if circuit_graphics then

	data.raw.item["wooden-board"].icon = "__ExtraChests__/graphics/icons/circuits/wooden-board.png"
	data.raw.item["phenolic-board"].icon = "__ExtraChests__/graphics/icons/circuits/phenolic-board.png"
	data.raw.item["fibreglass-board"].icon = "__ExtraChests__/graphics/icons/circuits/fibreglass-board.png"
	data.raw.item["basic-circuit-board"].icon = "__ExtraChests__/graphics/icons/circuits/basic-circuit-board.png"
	data.raw.item["circuit-board"].icon = "__ExtraChests__/graphics/icons/circuits/circuit-board.png"

	data.raw.item["superior-circuit-board"].icon = "__ExtraChests__/graphics/icons/circuits/superior-circuit-board.png"
	data.raw.item["multi-layer-circuit-board"].icon = "__ExtraChests__/graphics/icons/circuits/multi-layer-circuit-board.png"
	data.raw.item["electronic-circuit"].icon = "__ExtraChests__/graphics/icons/circuits/basic-electronic-circuit-board.png"
	data.raw.item["advanced-circuit"].icon = "__ExtraChests__/graphics/icons/circuits/electronic-circuit-board.png"
	data.raw.item["processing-unit"].icon = "__ExtraChests__/graphics/icons/circuits/electronic-logic-board.png"

	data.raw.item["advanced-processing-unit"].icon = "__ExtraChests__/graphics/icons/circuits/electronic-processing-board.png"

end



--     ============== ICONS graphics ===============

if menu_graphics then
	data.raw["item-group"]["logistics"].icon = "__ExtraChests__/graphics/icons/technology/logistics.png"
	data.raw["item-group"]["bob-logistics"].icon = "__ExtraChests__/graphics/icons/technology/bobslogistics.png"

	data.raw["item-group"]["bob-intermediate-products"].icon = "__ExtraChests__/graphics/icons/technology/bobintermediates.png"
	data.raw["item-group"]["production"].icon = "__ExtraChests__/graphics/icons/technology/production.png"
	data.raw["item-group"]["intermediate-products"].icon = "__ExtraChests__/graphics/icons/technology/intermediate-products.png"

end

if techonologies_graphics then

	data.raw.technology["lead-processing"].icon = "__ExtraChests__/graphics/icons/technology/lead-processing.png"
	data.raw.technology["aluminium-processing"].icon = "__ExtraChests__/graphics/icons/technology/aluminium-processing.png"
	data.raw.technology["nitinol-processing"].icon = "__ExtraChests__/graphics/icons/technology/nitinol-processing.png"
	data.raw.technology["barrels"].icon = "__ExtraChests__/graphics/icons/technology/barrels.png"

	data.raw.technology["bob-pumpjacks-1"].icon = "__base__/graphics/technology/oil-gathering.png"
	data.raw.technology["bob-pumpjacks-2"].icon = "__base__/graphics/technology/oil-gathering.png"
	data.raw.technology["bob-pumpjacks-3"].icon = "__base__/graphics/technology/oil-gathering.png"
	data.raw.technology["bob-pumpjacks-4"].icon = "__base__/graphics/technology/oil-gathering.png"

	data.raw.technology["energy-shield-equipment"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-equipment.png"
	data.raw.technology["energy-shield-mk2-equipment"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-mk2-equipment.png"	    
	data.raw.technology["energy-shield-equipment-3"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-mk3-equipment.png"
	data.raw.technology["energy-shield-equipment-4"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-mk4-equipment.png"
	data.raw.technology["energy-shield-equipment-5"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-mk5-equipment.png"
	data.raw.technology["energy-shield-equipment-6"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-mk6-equipment.png"

	data.raw.technology["energy-shield-equipment"].icon_size = 128
	data.raw.technology["energy-shield-mk2-equipment"].icon_size = 128
	data.raw.technology["energy-shield-equipment-3"].icon_size = 128
	data.raw.technology["energy-shield-equipment-4"].icon_size = 128
	data.raw.technology["energy-shield-equipment-5"].icon_size = 128
	data.raw.technology["energy-shield-equipment-6"].icon_size = 128

	data.raw.technology["energy-shield-equipment"].upgrade = true
	data.raw.technology["energy-shield-mk2-equipment"].upgrade = true

	data.raw.technology["bob-drills-1"].icon = "__ExtraChests__/graphics/icons/technology/mining-drill.png"
	data.raw.technology["bob-drills-2"].icon = "__ExtraChests__/graphics/icons/technology/mining-drill.png"
	data.raw.technology["bob-drills-3"].icon = "__ExtraChests__/graphics/icons/technology/mining-drill.png"
	data.raw.technology["bob-drills-4"].icon = "__ExtraChests__/graphics/icons/technology/mining-drill.png"

	data.raw.technology["bob-area-drills-1"].icon = "__ExtraChests__/graphics/icons/technology/large-mining-drill.png"
	data.raw.technology["bob-area-drills-2"].icon = "__ExtraChests__/graphics/icons/technology/large-mining-drill.png"
	data.raw.technology["bob-area-drills-3"].icon = "__ExtraChests__/graphics/icons/technology/large-mining-drill.png"
	data.raw.technology["bob-area-drills-4"].icon = "__ExtraChests__/graphics/icons/technology/large-mining-drill.png"
	
end

--------------------------------------------
-------- GROUPS update ---------------------
--------------------------------------------


--       ========== LOGISTIC ===========


       
data.raw.item["purple-inserter"].subgroup = "addon-purple-inserter"
data.raw.item["purple-near-inserter"].subgroup = "addon-purple-inserter"
data.raw.item["purple-far-inserter"].subgroup  = "addon-purple-inserter"
data.raw.item["purple-short-far-inserter"].subgroup  = "addon-purple-inserter"
data.raw.item["purple-short-long-inserter"].subgroup  = "addon-purple-inserter"
data.raw.item["purple-long-near-inserter"].subgroup   = "addon-purple-inserter"
data.raw.item["purple-long-short-inserter"].subgroup  = "addon-purple-inserter"
data.raw.item["purple-long-inserter"].subgroup	  = "addon-purple-inserter"



data.raw.item["green-transport-belt"].subgroup = "belt"
data.raw.item["green-transport-belt"].order = "a[transport-belt]-d[green-transport-belt]"
data.raw.item["purple-transport-belt"].subgroup = "belt"
data.raw.item["purple-transport-belt"].order = "a[transport-belt]-e[purple-transport-belt]"


data.raw.item["basic-transport-belt-to-ground"].subgroup = "addon-underground-belts"
data.raw.item["fast-transport-belt-to-ground"].subgroup = "addon-underground-belts"
data.raw.item["express-transport-belt-to-ground"].subgroup = "addon-underground-belts"


data.raw.item["green-transport-belt-to-ground"].subgroup = "addon-underground-belts"
data.raw.item["green-transport-belt-to-ground"].order = "b[transport-belt-to-ground]-d[green-transport-belt-to-ground]"
data.raw.item["purple-transport-belt-to-ground"].subgroup = "addon-underground-belts"
data.raw.item["purple-transport-belt-to-ground"].order = "b[transport-belt-to-ground]-e[purple-transport-belt-to-ground]"

data.raw.item["basic-splitter"].subgroup = "addon-splitters"
data.raw.item["fast-splitter"].subgroup = "addon-splitters"
data.raw.item["express-splitter"].subgroup = "addon-splitters"

data.raw.item["green-splitter"].subgroup = "addon-splitters"
data.raw.item["green-splitter"].order = "c[splitter]-d[green-splitter]"
data.raw.item["purple-splitter"].subgroup = "addon-splitters"
data.raw.item["purple-splitter"].order = "c[splitter]-e[purple-splitter]"


data.raw.item["substation"].subgroup = "addon-energy-substation"
data.raw.item["substation-2"].subgroup = "addon-energy-substation"
data.raw.item["substation-3"].subgroup = "addon-energy-substation"
data.raw.item["substation-4"].subgroup = "addon-energy-substation"


--data.raw.item["straight-rail"].subgroup = "addon-energy-substation"
--data.raw.item["curved-rail"].subgroup = "addon-energy-substation"
--data.raw.item["train-stop"].subgroup = "addon-energy-substation"
--data.raw.item["rail-signal"].subgroup = "addon-energy-substation"
--data.raw.item["rail-chain-signal"].subgroup = "addon-energy-substation"
data.raw.item["rail-chain-signal"].order = "a[train-system]-e[arail-signal-chain]"


data.raw.item["diesel-locomotive"].subgroup = "addon-trains"
data.raw.item["diesel-locomotive"].order = "a[train-system]-e[diesel-locomotive-1]"
data.raw.item["diesel-locomotive-2"].subgroup = "addon-trains"
data.raw.item["diesel-locomotive-3"].subgroup = "addon-trains"
data.raw.item["armoured-diesel-locomotive"].subgroup = "addon-trains"
data.raw.item["cargo-wagon"].subgroup = "addon-trains"
data.raw.item["cargo-wagon"].order = "a[train-system]-f[cargo-wagon-1]"
data.raw.item["cargo-wagon-2"].subgroup = "addon-trains"
data.raw.item["cargo-wagon-3"].subgroup = "addon-trains"
data.raw.item["armoured-cargo-wagon"].subgroup = "addon-trains"


data.raw.item["car"].subgroup = "addon-cars-tanks"
data.raw.item["tank"].subgroup = "addon-cars-tanks"
data.raw.item["tank-2"].subgroup = "addon-cars-tanks"
data.raw.item["tank-3"].subgroup = "addon-cars-tanks"
data.raw.item["bob-robot-tank"].subgroup = "addon-cars-tanks"

if data.raw.item["landfill2by2"] then
	data.raw.item["landfill2by2"].subgroup = "addon-energy-substation"
	data.raw.item["landfill4by4"].subgroup = "addon-energy-substation"
	data.raw.item["water-be-gone"].subgroup = "addon-energy-substation"
	data.raw.item["water-bomb"].subgroup = "addon-energy-substation"
	data.raw.item["water-bomb"].order = "cd[landfill]"
end


data.raw.item["copper-cable"].subgroup = "bob-electronic-components"
data.raw.item["copper-cable"].order = "0-a0[tinned-copper-cable]"

data.raw.item["red-wire"].subgroup = "bob-electronic-components"
data.raw.item["red-wire"].order = "0-a3a[red-wire]"

data.raw.item["green-wire"].subgroup = "bob-electronic-components"
data.raw.item["green-wire"].order = "0-a3b[green-wire]"



--       ========== BOBS LOGISTIC ===========


data.raw.item["small-pump"].subgroup = "bob-pump"
data.raw.item["small-pump"].order = "a[small-pump]"


data.raw.item["storage-tank"].subgroup = "bob-storage"
data.raw.item["storage-tank"].order = "b[fluid]-a[storage-tank-1]"


if upgrade_tank_capacity then
	data.raw["storage-tank"]["storage-tank-2"]["fluid_box"]["base_area"] = 500
	data.raw["storage-tank"]["storage-tank-3"]["fluid_box"]["base_area"] = 1000
	data.raw["storage-tank"]["storage-tank-4"]["fluid_box"]["base_area"] = 2500
end


data.raw.item["flying-robot-frame"].subgroup = "addon-robots-frame"
data.raw.item["flying-robot-frame-2"].subgroup = "addon-robots-frame"
data.raw.item["flying-robot-frame-3"].subgroup = "addon-robots-frame"
data.raw.item["flying-robot-frame-4"].subgroup = "addon-robots-frame"

data.raw.item["logistic-robot"].subgroup = "addon-logistic-robots"
data.raw.item["bob-logistic-robot-2"].subgroup = "addon-logistic-robots"
data.raw.item["bob-logistic-robot-3"].subgroup = "addon-logistic-robots"
data.raw.item["bob-logistic-robot-4"].subgroup = "addon-logistic-robots"

data.raw.item["construction-robot"].subgroup = "addon-construction-robots"
data.raw.item["bob-construction-robot-2"].subgroup = "addon-construction-robots"
data.raw.item["bob-construction-robot-3"].subgroup = "addon-construction-robots"
data.raw.item["bob-construction-robot-4"].subgroup = "addon-construction-robots"


data.raw.item["roboport"].subgroup = "addon-roboports"
data.raw.item["bob-roboport-2"].subgroup = "addon-roboports"
data.raw.item["bob-roboport-3"].subgroup = "addon-roboports"
data.raw.item["bob-roboport-4"].subgroup = "addon-roboports"

data.raw.item["bob-robo-charge-port"].subgroup = "addon-roboports"
data.raw.item["bob-robo-charge-port-2"].subgroup = "addon-roboports"
data.raw.item["bob-robo-charge-port-3"].subgroup = "addon-roboports"
data.raw.item["bob-robo-charge-port-4"].subgroup = "addon-roboports"

data.raw.item["bob-robo-charge-port"].order = "c[signal]-b[robo-charge-port-a-1]"
data.raw.item["bob-robo-charge-port-2"].order = "c[signal]-b[robo-charge-port-a-1]"
data.raw.item["bob-robo-charge-port-3"].order = "c[signal]-b[robo-charge-port-a-1]"
data.raw.item["bob-robo-charge-port-4"].order = "c[signal]-b[robo-charge-port-a-1]"

data.raw.item["bob-logistic-zone-expander"].subgroup = "addon-expander"
data.raw.item["bob-logistic-zone-expander-2"].subgroup = "addon-expander"
data.raw.item["bob-logistic-zone-expander-3"].subgroup = "addon-expander"
data.raw.item["bob-logistic-zone-expander-4"].subgroup = "addon-expander"

data.raw.item["bob-robo-charge-port-large"].subgroup = "addon-expander"
data.raw.item["bob-robo-charge-port-large-2"].subgroup = "addon-expander"
data.raw.item["bob-robo-charge-port-large-3"].subgroup = "addon-expander"
data.raw.item["bob-robo-charge-port-large-4"].subgroup = "addon-expander"


data.raw.item["bob-robochest"].subgroup = "addon-robochests"
data.raw.item["bob-robochest-2"].subgroup = "addon-robochests"
data.raw.item["bob-robochest-3"].subgroup = "addon-robochests"
data.raw.item["bob-robochest-4"].subgroup = "addon-robochests"


data.raw.item["offshore-pump"].subgroup = "addon-pump-jacks"
data.raw.item["pumpjack"].subgroup = "addon-pump-jacks"
data.raw.item["bob-pumpjack-1"].subgroup = "addon-pump-jacks"
data.raw.item["bob-pumpjack-2"].subgroup = "addon-pump-jacks"
data.raw.item["bob-pumpjack-3"].subgroup = "addon-pump-jacks"
data.raw.item["bob-pumpjack-4"].subgroup = "addon-pump-jacks"


--       ========== PRODUCTION ===========

data.raw["repair-tool"]["repair-pack"].order = "0[repair]-a[repair-pack]"


data.raw.item["small-lamp"].order = "a[light]-a[small-lamp]"

if data.raw["deconstruction-item"]["upgrade-planner"] then
	data.raw["deconstruction-item"]["upgrade-planner"].subgroup = "energy"
end
if data.raw["deconstruction-item"]["deconstruction-planner"]  then
	data.raw["deconstruction-item"]["deconstruction-planner"].subgroup = "energy"
end
data.raw["blueprint"]["blueprint"].subgroup = "energy"


data.raw.item["chemical-furnace"].subgroup = "addon-chemical-machine"
data.raw.item["chemical-boiler"].subgroup = "addon-chemical-machine"
data.raw.item["electric-chemical-mixing-furnace"].subgroup = "addon-chemical-machine"
data.raw.item["electric-chemical-mixing-furnace-2"].subgroup = "addon-chemical-machine"

data.raw.item["oil-refinery"].subgroup = "addon-pump-jacks"
data.raw.item["oil-refinery"].order = "z[oil-refinery]"


data.raw.item["lab"].order = "g[lab-1]"

if data.raw.item["lab-2"] then
   data.raw.item["lab-2"].order = "g[lab-2]"
end

if data.raw.item["lab-module"] then
   data.raw.item["lab-module"].order = "g[lab-3]"
end

if data.raw.item["lab-alien"] then
   data.raw.item["lab-alien"].order = "g[lab-4]"
end


if data.raw.item["turret-probe"] then
	data.raw.item["turret-probe"].subgroup = "energy"
	data.raw.item["turret-probe"].order = "a[turret-probe]"
end

if data.raw.item["resource-monitor"] then
	data.raw.item["resource-monitor"].subgroup = "energy"
	data.raw.item["resource-monitor"].order = "b[resource-monitor]"
end


if data.raw.item["pipe-cleaner"] then
	data.raw.item["pipe-cleaner"].subgroup = "energy"
	data.raw.item["pipe-cleaner"].order = "c[pipe-cleaner]"
end

if data.raw.item["burner-generator"] then
	data.raw.item["burner-generator"].subgroup = "energy"
	data.raw.item["burner-generator"].order = "d[burner-generator]"
end

if data.raw.item["OilSteamBoiler"] then
	data.raw.item["OilSteamBoiler"].subgroup = "energy"
	data.raw.item["OilSteamBoiler"].order = "e[OilSteamBoiler]"
end

if data.raw.item["reverse-factory"] then
	data.raw.item["reverse-factory"].subgroup = "energy"
	data.raw.item["reverse-factory"].order = "f[reverse-factory]"
end






--       ========== MODULES ===========

--data.raw.tool["module-case"].subgroup = "addon-modules2"
--data.raw.item["module-contact"].subgroup = "addon-modules2"
--data.raw.tool["module-circuit-board"].subgroup = "addon-modules2"


data.raw.item["module-processor-board"].subgroup = "addon-modules1"
data.raw.item["module-processor-board-2"].subgroup = "addon-modules1"
data.raw.item["module-processor-board-3"].subgroup = "addon-modules1"

data.raw.tool["speed-processor"].subgroup = "addon-modules1"
data.raw.item["speed-processor-2"].subgroup = "addon-modules1"
data.raw.item["speed-processor-3"].subgroup = "addon-modules1"

data.raw.tool["effectivity-processor"].subgroup = "addon-modules1"
data.raw.item["effectivity-processor-2"].subgroup = "addon-modules1"
data.raw.item["effectivity-processor-3"].subgroup = "addon-modules1"



data.raw.tool["productivity-processor"].subgroup = "addon-modules2"
data.raw.item["productivity-processor-2"].subgroup = "addon-modules2"
data.raw.item["productivity-processor-3"].subgroup = "addon-modules2"

data.raw.tool["pollution-clean-processor"].subgroup = "addon-modules2"
data.raw.item["pollution-clean-processor-2"].subgroup = "addon-modules2"
data.raw.item["pollution-clean-processor-3"].subgroup = "addon-modules2"

data.raw.tool["pollution-create-processor"].subgroup = "addon-modules2"
data.raw.item["pollution-create-processor-2"].subgroup = "addon-modules2"
data.raw.item["pollution-create-processor-3"].subgroup = "addon-modules2"


--       ========== INTERMEDIATES ===========


data.raw.recipe["iron-stick"].subgroup = "addon-engines"
data.raw.recipe["engine-unit"].subgroup = "addon-engines"
data.raw.recipe["electric-engine-unit"].subgroup = "addon-engines"

data.raw.recipe["iron-stick"].order = "a"
data.raw.recipe["engine-unit"].order = "b"
data.raw.recipe["electric-engine-unit"].order = "c"

data.raw.item["iron-stick"].subgroup = "addon-engines"
data.raw.item["engine-unit"].subgroup = "addon-engines"
data.raw.item["electric-engine-unit"].subgroup = "addon-engines"

data.raw.item["iron-stick"].order = "a"
data.raw.item["engine-unit"].order = "b"
data.raw.item["electric-engine-unit"].order = "c"

data.raw.item["low-density-structure"].subgroup = "addon-rocket-parts"
data.raw.item["rocket-fuel"].subgroup = "addon-rocket-parts"
data.raw.item["rocket-control-unit"].subgroup = "addon-rocket-parts"
data.raw.item["rocket-part"].subgroup = "addon-rocket-parts"
data.raw.item["satellite"].subgroup = "addon-rocket-parts"

data.raw.item["low-density-structure"].order = "z-a[low-density-structure]"
data.raw.item["rocket-fuel"].order = "z-b[rocket-fuel]"
data.raw.item["rocket-control-unit"].order = "z-c[rocket-control-unit]"
data.raw.item["rocket-part"].order = "z-d[rocket-part]"
data.raw.item["satellite"].order = "z-e[satellite]"

--data.raw.recipe["low-density-structure"].order = "z-a[low-density-structure]"
--data.raw.recipe["rocket-fuel"].order = "z-b[rocket-fuel]"
--data.raw.recipe["rocket-control-unit"].order = "z-c[rocket-control-unit]"
--data.raw.recipe["rocket-part"].order = "z-d[rocket-part]"
--data.raw.recipe["satellite"].order = "z-e[satellite]"


--       ========== FLUIDS ===========

data.raw.recipe["basic-oil-processing"].subgroup = "addon-petrol-fluids"
data.raw.recipe["advanced-oil-processing"].subgroup = "addon-petrol-fluids"
data.raw.recipe["bob-oil-processing"].subgroup = "addon-petrol-fluids"

data.raw.recipe["heavy-oil-cracking"].subgroup = "addon-petrol-fluids"
data.raw.recipe["light-oil-cracking"].subgroup = "addon-petrol-fluids"
data.raw.recipe["coal-cracking"].subgroup = "addon-petrol-fluids"
data.raw.recipe["petroleum-gas-cracking"].subgroup = "addon-petrol-fluids"

data.raw.recipe["coal-cracking"].order = "b[fluid-chemistry]-a[cracking1]"
data.raw.recipe["heavy-oil-cracking"].order = "b[fluid-chemistry]-a[cracking2]"
data.raw.recipe["light-oil-cracking"].order = "b[fluid-chemistry]-a[cracking3]"
data.raw.recipe["petroleum-gas-cracking"].order = "b[fluid-chemistry]-a[cracking4]"

data.raw.recipe["lubricant"].subgroup = "addon-petrol-fluids"
data.raw.recipe["liquid-fuel"].subgroup = "addon-petrol-fluids"

data.raw.recipe["lubricant"].order = "c[fluid-chemistry]-b1[lubricant]"
data.raw.recipe["liquid-fuel"].order = "c[fluid-chemistry]-b2[liquid-fuel]"

if data.raw.recipe["burn-crude-oil"] then
	data.raw.recipe["burn-crude-oil"].subgroup = "addon-fuels-fluids"
	data.raw.recipe["burn-heavy-oil"].subgroup = "addon-fuels-fluids"
	data.raw.recipe["burn-light-oil"].subgroup = "addon-fuels-fluids"
	data.raw.item["crude-oil-barrel"].subgroup = "bob-barrel"
end





data.raw.recipe["sulfuric-acid"].subgroup = "addon-sulfur-fluids"
data.raw.recipe["sulfuric-acid-2"].subgroup = "addon-sulfur-fluids"
data.raw.recipe["sulfuric-acid"].order = "a[sulfur2]"
data.raw.recipe["sulfuric-acid-2"].order = "a[sulfur3]"


data.raw.recipe["salt-water-electrolysis"].subgroup = "addon-chloride-fluids"
data.raw.recipe["hydrogen-chloride"].subgroup = "addon-chloride-fluids"
data.raw.recipe["tungstic-acid"].subgroup = "addon-chloride-fluids"
data.raw.recipe["ferric-chloride-solution"].subgroup = "addon-chloride-fluids"

data.raw.recipe["salt-water-electrolysis"].order = "a[chlorine1]"
data.raw.recipe["hydrogen-chloride"].order = "a[chlorine2]"
data.raw.recipe["tungstic-acid"].order = "a[chlorine3]"
data.raw.recipe["ferric-chloride-solution"].order = "a[chlorine4]"



data.raw.recipe["nitrogen"].subgroup = "addon-nitrogen-fluids"
data.raw.recipe["nitrogen-dioxide"].subgroup = "addon-nitrogen-fluids"
data.raw.recipe["nitric-acid"].subgroup = "addon-nitrogen-fluids"
data.raw.recipe["sulfuric-nitric-acid"].subgroup = "addon-nitrogen-fluids"
data.raw.recipe["nitroglycerin"].subgroup = "addon-nitrogen-fluids"
data.raw.recipe["glycerol"].subgroup = "addon-nitrogen-fluids"

data.raw.recipe["nitrogen"].order = "a[nitrogen1]"
data.raw.recipe["nitrogen-dioxide"].order = "a[nitrogen2]"
data.raw.recipe["nitric-acid"].order = "a[nitrogen3]"
data.raw.recipe["sulfuric-nitric-acid"].order = "a[nitrogen4]"
data.raw.recipe["nitroglycerin"].order = "a[nitrogen5]"
data.raw.recipe["glycerol"].order = "a[nitrogen6]"



data.raw.recipe["solid-fuel-from-light-oil"].subgroup = "addon-fuels-fluids"
data.raw.recipe["solid-fuel-from-petroleum-gas"].subgroup = "addon-fuels-fluids"
data.raw.recipe["solid-fuel-from-heavy-oil"].subgroup = "addon-fuels-fluids"
data.raw.recipe["solid-fuel-from-hydrogen"].subgroup = "addon-fuels-fluids"

data.raw.recipe["solid-fuel-from-heavy-oil"].order = "a[solid1]"
data.raw.recipe["solid-fuel-from-light-oil"].order = "a[solid2]"
data.raw.recipe["solid-fuel-from-petroleum-gas"].order = "a[solid3]"
data.raw.recipe["solid-fuel-from-hydrogen"].order = "a[solid4]"




data.raw.recipe["hydrogen-canister"].subgroup = "addon-loading-bottles"
data.raw.recipe["oxygen-canister"].subgroup = "addon-loading-bottles"
data.raw.recipe["nitrogen-canister"].subgroup = "addon-loading-bottles"
data.raw.recipe["chlorine-canister"].subgroup = "addon-loading-bottles"
data.raw.recipe["hydrogen-chloride-canister"].subgroup = "addon-loading-bottles"
data.raw.recipe["petroleum-gas-canister"].subgroup = "addon-loading-bottles"


data.raw.recipe["empty-hydrogen-canister"].subgroup = "addon-empty-bottles"
data.raw.recipe["empty-oxygen-canister"].subgroup = "addon-empty-bottles"
data.raw.recipe["empty-nitrogen-canister"].subgroup = "addon-empty-bottles"
data.raw.recipe["empty-chlorine-canister"].subgroup = "addon-empty-bottles"
data.raw.recipe["empty-hydrogen-chloride-canister"].subgroup = "addon-empty-bottles"
data.raw.recipe["empty-petroleum-gas-canister"].subgroup = "addon-empty-bottles"


data.raw.recipe["fill-crude-oil-barrel"].subgroup = "addon-loading-barrels"
data.raw.recipe["fill-crude-oil-barrel"].order = "a[crude-oil-barrel]"
data.raw.recipe["bob-fill-crude-oil-barrel"].subgroup = "addon-loading-barrels"
data.raw.recipe["fill-heavy-oil-barrel"].subgroup = "addon-loading-barrels"
data.raw.recipe["fill-light-oil-barrel"].subgroup = "addon-loading-barrels"
data.raw.recipe["fill-lubricant-barrel"].subgroup = "addon-loading-barrels"
data.raw.recipe["fill-sulfuric-acid-barrel"].subgroup = "addon-loading-barrels"

data.raw.recipe["liquid-fuel-canister"].subgroup = "addon-loading-barrels"
data.raw.recipe["liquid-fuel-canister"].order = "d[liquid-fuel-canister]"
data.raw.recipe["ferric-chloride-canister"].subgroup = "addon-loading-barrels"
data.raw.recipe["ferric-chloride-canister"].order = "d[ferric-chloride-canister]"


data.raw.recipe["empty-crude-oil-barrel"].subgroup = "addon-empty-barrels"
data.raw.recipe["empty-crude-oil-barrel"].order = "a[empty-crude-oil-barrel]"
data.raw.recipe["bob-empty-crude-oil-barrel"].subgroup = "addon-empty-barrels"
data.raw.recipe["empty-heavy-oil-barrel"].subgroup = "addon-empty-barrels"
data.raw.recipe["empty-light-oil-barrel"].subgroup = "addon-empty-barrels"
data.raw.recipe["empty-lubricant-barrel"].subgroup = "addon-empty-barrels"
data.raw.recipe["empty-sulfuric-acid-barrel"].subgroup = "addon-empty-barrels"

data.raw.recipe["empty-liquid-fuel-canister"].subgroup = "addon-empty-barrels"
data.raw.recipe["empty-liquid-fuel-canister"].order = "d[empty-liquid-fuel-canister]"
data.raw.recipe["empty-ferric-chloride-canister"].subgroup = "addon-empty-barrels"
data.raw.recipe["empty-ferric-chloride-canister"].order = "d[empty-ferric-chloride-canister]"

data.raw.item["ferric-chloride-canister"].order = "z[ferric-chloride-canister]"
data.raw.item["liquid-fuel-canister"].order = "z[liquid-fuel-canister]"



--       ========== BOBS MATERIALS ===========


data.raw.item["raw-wood"].subgroup = "bob-ores"
data.raw.item["coal"].subgroup = "bob-ores"
data.raw.item["stone"].subgroup = "bob-ores"
data.raw.item["iron-ore"].subgroup = "bob-ores"
data.raw.item["copper-ore"].subgroup = "bob-ores"

 
data.raw.item["raw-wood"].order = "a[base-ore1]"
data.raw.item["stone"].order = "a[base-ore2]"
data.raw.item["copper-ore"].order = "a[base-ore3]"
data.raw.item["iron-ore"].order = "a[base-ore4]"
data.raw.item["coal"].order = "a[base-ore5]"
 
 
 
data.raw.item["wood"].subgroup = "bob-resource"
--data.raw.item["resin"].subgroup = "bob-resource"
data.raw.item["iron-plate"].subgroup = "bob-material"
data.raw.item["copper-plate"].subgroup = "bob-material"
data.raw.item["steel-plate"].subgroup = "bob-material"

data.raw.item["stone-brick"].subgroup = "bob-material"
data.raw.item["concrete"].subgroup = "bob-material"


data.raw.item["wood"].order = "a[a-wood]"
data.raw.item["resin"].order = "a[b-resin]"
--data.raw.recipe["bob-resin-wood"].order = "a[b-resin]"
data.raw.recipe["bob-resin-oil"].order = "a[synthetic-wooda]"
data.raw.item["copper-plate"].order = "a-a-a[copper-plate]"
data.raw.item["iron-plate"].order = "a-a-b[iron-plate]"
data.raw.item["steel-plate"].order = "a-a-c[steel-plate]"

data.raw.item["stone-brick"].order = "a-a-d[iron-plate]"
data.raw.item["concrete"].order = "a-a-e[steel-plate]"


--data.raw.item["polishing-compound"].subgroup = "bob-resource"
--data.raw.item["petroleum-jelly"].subgroup = "bob-resource"

data.raw.item["polishing-compound"].order = "z-a[polishing-compound]"
data.raw.item["petroleum-jelly"].order = "z-b[polishing-compound]"



data.raw.item["sulfur"].subgroup = "bob-resource-chemical"
data.raw.item["plastic-bar"].subgroup = "bob-resource-chemical"

data.raw.item["sulfur"].order = "f[sulfur]"


data.raw.item["silver-nitrate"].subgroup = "bob-resource-chemical"
data.raw.item["silver-oxide"].subgroup = "bob-resource-chemical"
data.raw.recipe["silver-nitrate"].subgroup = "bob-resource-chemical"
data.raw.recipe["silver-oxide"].subgroup = "bob-resource-chemical"



data.raw.item["tin-plate"].order = "a[a-a-tin-plate]"
data.raw.item["lead-plate"].order = "a[a-b-lead-plate]"

data.raw.recipe["cobalt-oxide-from-copper"].order = "a[a-a-cobalt-oxide-from-copper]"
data.raw.recipe["bob-lead-plate"].order = "a[a-b-bob-lead-plate]"
data.raw.recipe["silver-from-lead"].order = "a[a-c-silver-from-lead]"

data.raw.item["aluminium-plate"].order = "a[a-a-aluminium-plate]"
data.raw.item["zinc-plate"].order = "a[a-b-zinc-plate]"
data.raw.item["titanium-plate"].order = "a[a-d-titanium-plate]"


data.raw.item["bronze-alloy"].order = "a[a-a-bronze-alloy]"
data.raw.item["brass-alloy"].order = "a[a-b-brass-alloy]"
data.raw.item["tungsten-plate"].order = "a[a-c-tungsten-plate]"
data.raw.item["copper-tungsten-alloy"].order = "a[a-d-copper-tungsten-alloy]"
data.raw.item["tungsten-carbide"].order = "a[a-e-tungsten-carbide]"
data.raw.recipe["tungsten-carbide-2"].order = "a[a-f-tungsten-carbide]"
data.raw.item["gunmetal-alloy"].order = "a[a-h-gunmetal-alloy]"



--       ========== BOBS INTERMEDIATES ===========


data.raw.item["battery"].subgroup = "bob-intermediates"
data.raw.item["battery"].order = "a[battery1]"
data.raw.item["lithium-ion-battery"].order = "a[battery2]"
data.raw.item["silver-zinc-battery"].order = "a[battery3]"


data.raw.item["explosives"].subgroup = "bob-intermediates"
data.raw.item["explosives"].order = "z[explosives]"
	
data.raw.item["iron-gear-wheel"].subgroup = "bob-gears"
data.raw.item["iron-gear-wheel"].order = "z[iron-gear-wheel]"

data.raw.item["gas-canister"].subgroup = "barrel"
data.raw.item["empty-canister"].subgroup = "barrel"
data.raw.recipe["gas-canister"].subgroup = "barrel"
data.raw.recipe["empty-canister"].subgroup = "barrel"


data.raw.item["solder"].subgroup = "addon-electronics"
data.raw.item["basic-electronic-components"].subgroup = "addon-electronics"
data.raw.item["electronic-components"].subgroup = "addon-electronics"
data.raw.item["intergrated-electronics"].subgroup = "addon-electronics"
data.raw.item["processing-electronics"].subgroup = "addon-electronics"



data.raw.item["electronic-circuit"].subgroup = "addon-circuits"
data.raw.item["advanced-circuit"].subgroup = "addon-circuits"
data.raw.item["processing-unit"].subgroup = "addon-circuits"
data.raw.item["advanced-processing-unit"].subgroup = "addon-circuits"




data.raw.item["steel-bearing-ball"].subgroup = "addon-bearing-ball"
data.raw.item["titanium-bearing-ball"].subgroup = "addon-bearing-ball"
data.raw.item["nitinol-bearing-ball"].subgroup = "addon-bearing-ball"
data.raw.item["ceramic-bearing-ball"].subgroup = "addon-bearing-ball"


data.raw.item["bullet"].subgroup = "addon-bullets"
data.raw.item["acid-bullet"].subgroup = "addon-bullets"
data.raw.item["ap-bullet"].subgroup = "addon-bullets"
data.raw.item["flame-bullet"].subgroup = "addon-bullets"
data.raw.item["he-bullet"].subgroup = "addon-bullets"
data.raw.item["impact-bullet"].subgroup = "addon-bullets"
data.raw.item["poison-bullet"].subgroup = "addon-bullets"

data.raw.item["bullet"].order = "a"

data.raw.item["bullet-projectile"].subgroup = "addon-projectile"
data.raw.item["acid-bullet-projectile"].subgroup = "addon-projectile"
data.raw.item["ap-bullet-projectile"].subgroup = "addon-projectile"
data.raw.item["flame-bullet-projectile"].subgroup = "addon-projectile"
data.raw.item["he-bullet-projectile"].subgroup = "addon-projectile"
data.raw.item["impact-bullet-projectile"].subgroup = "addon-projectile"
data.raw.item["poison-bullet-projectile"].subgroup = "addon-projectile"

data.raw.item["bullet-projectile"].order = "a"

data.raw.item["rocket-warhead"].subgroup = "addon-missile"
data.raw.item["acid-rocket-warhead"].subgroup = "addon-missile"
data.raw.item["explosive-rocket-warhead"].subgroup = "addon-missile"
data.raw.item["flame-rocket-warhead"].subgroup = "addon-missile"
data.raw.item["impact-rocket-warhead"].subgroup = "addon-missile"
data.raw.item["piercing-rocket-warhead"].subgroup = "addon-missile"
data.raw.item["poison-rocket-warhead"].subgroup = "addon-missile"

data.raw.item["rocket-warhead"].order = "a"
data.raw.item["acid-rocket-warhead"].order = "b"
data.raw.item["explosive-rocket-warhead"].order = "c"
data.raw.item["flame-rocket-warhead"].order = "d"
data.raw.item["impact-rocket-warhead"].order = "e"
data.raw.item["piercing-rocket-warhead"].order = "f"
data.raw.item["poison-rocket-warhead"].order = "g"



data.raw.recipe["bullet"].subgroup = "addon-bullets"
data.raw.recipe["acid-bullet"].subgroup = "addon-bullets"
data.raw.recipe["ap-bullet"].subgroup = "addon-bullets"
data.raw.recipe["flame-bullet"].subgroup = "addon-bullets"
data.raw.recipe["he-bullet"].subgroup = "addon-bullets"
data.raw.recipe["impact-bullet"].subgroup = "addon-bullets"
data.raw.recipe["poison-bullet"].subgroup = "addon-bullets"

data.raw.recipe["bullet"].order = "a"

data.raw.recipe["bullet-projectile"].subgroup = "addon-projectile"
data.raw.recipe["acid-bullet-projectile"].subgroup = "addon-projectile"
data.raw.recipe["ap-bullet-projectile"].subgroup = "addon-projectile"
data.raw.recipe["flame-bullet-projectile"].subgroup = "addon-projectile"
data.raw.recipe["he-bullet-projectile"].subgroup = "addon-projectile"
data.raw.recipe["impact-bullet-projectile"].subgroup = "addon-projectile"
data.raw.recipe["poison-bullet-projectile"].subgroup = "addon-projectile"

data.raw.recipe["bullet-projectile"].order = "a"

data.raw.recipe["rocket-warhead"].subgroup = "addon-missile"
data.raw.recipe["acid-rocket-warhead"].subgroup = "addon-missile"
data.raw.recipe["explosive-rocket-warhead"].subgroup = "addon-missile"
data.raw.recipe["flame-rocket-warhead"].subgroup = "addon-missile"
data.raw.recipe["impact-rocket-warhead"].subgroup = "addon-missile"
data.raw.recipe["piercing-rocket-warhead"].subgroup = "addon-missile"
data.raw.recipe["poison-rocket-warhead"].subgroup = "addon-missile"

data.raw.recipe["rocket-warhead"].order = "a"
data.raw.recipe["acid-rocket-warhead"].order = "b"
data.raw.recipe["explosive-rocket-warhead"].order = "c"
data.raw.recipe["flame-rocket-warhead"].order = "d"
data.raw.recipe["impact-rocket-warhead"].order = "e"
data.raw.recipe["piercing-rocket-warhead"].order = "f"
data.raw.recipe["poison-rocket-warhead"].order = "g"






data.raw.item["roboport-door-1"].subgroup = "addon-roboport-parts"
data.raw.item["roboport-door-2"].subgroup = "addon-roboport-parts"
data.raw.item["roboport-door-3"].subgroup = "addon-roboport-parts"
data.raw.item["roboport-door-4"].subgroup = "addon-roboport-parts"


--       ========== ARMS ===========

data.raw.item["land-mine"].subgroup = "addon-mines"
data.raw.item["poison-mine"].subgroup = "addon-mines"
data.raw.item["distractor-mine"].subgroup = "addon-mines"
data.raw.item["slowdown-mine"].subgroup = "addon-mines"

data.raw.ammo["explosive-artillery-shell"].subgroup = "addon-mines"
data.raw.capsule["basic-grenade"].subgroup = "addon-mines"
data.raw.ammo["flame-thrower-ammo"].subgroup = "addon-mines"

data.raw.ammo["poison-artillery-shell"].subgroup = "capsule"
data.raw.ammo["poison-artillery-shell"].order = "a[poison-artillery-shell]"




data.raw.ammo["bullet-magazine"].subgroup = "addon-magazine"
data.raw.ammo["acid-bullet-magazine"].subgroup = "addon-magazine"
data.raw.ammo["ap-bullet-magazine"].subgroup = "addon-magazine"
data.raw.ammo["flame-bullet-magazine"].subgroup = "addon-magazine"
data.raw.ammo["he-bullet-magazine"].subgroup = "addon-magazine"
data.raw.ammo["impact-bullet-magazine"].subgroup = "addon-magazine"
data.raw.ammo["poison-bullet-magazine"].subgroup = "addon-magazine"

data.raw.ammo["better-shotgun-shell"].subgroup = "addon-shotgun"
data.raw.ammo["shotgun-acid-shell"].subgroup = "addon-shotgun"
data.raw.ammo["shotgun-ap-shell"].subgroup = "addon-shotgun"
data.raw.ammo["shotgun-flame-shell"].subgroup = "addon-shotgun"
data.raw.ammo["shotgun-explosive-shell"].subgroup = "addon-shotgun"
data.raw.ammo["shotgun-impact-shell"].subgroup = "addon-shotgun"
data.raw.ammo["shotgun-poison-shell"].subgroup = "addon-shotgun"

data.raw.ammo["bob-rocket"].subgroup = "addon-rocket"
data.raw.ammo["bob-acid-rocket"].subgroup = "addon-rocket"
data.raw.ammo["bob-piercing-rocket"].subgroup = "addon-rocket"
data.raw.ammo["bob-flame-rocket"].subgroup = "addon-rocket"
data.raw.ammo["bob-explosive-rocket"].subgroup = "addon-rocket"
data.raw.ammo["bob-impact-rocket"].subgroup = "addon-rocket"
data.raw.ammo["bob-poison-rocket"].subgroup = "addon-rocket"

data.raw.ammo["laser-rifle-battery"].subgroup = "addon-laser-rifle"
data.raw.ammo["laser-rifle-battery-ruby"].subgroup = "addon-laser-rifle"
data.raw.ammo["laser-rifle-battery-sapphire"].subgroup = "addon-laser-rifle"
data.raw.ammo["laser-rifle-battery-emerald"].subgroup = "addon-laser-rifle"
data.raw.ammo["laser-rifle-battery-amethyst"].subgroup = "addon-laser-rifle"
data.raw.ammo["laser-rifle-battery-topaz"].subgroup = "addon-laser-rifle"
data.raw.ammo["laser-rifle-battery-diamond"].subgroup = "addon-laser-rifle"


data.raw.ammo["better-shotgun-shell"].order = "a"
data.raw.ammo["shotgun-explosive-shell"].order = "f[shotgun-he-shell]"

data.raw.ammo["bob-rocket"].order = "a"
data.raw.ammo["bob-acid-rocket"].order = "b"
data.raw.ammo["bob-piercing-rocket"].order = "c"
data.raw.ammo["bob-flame-rocket"].order = "d"
data.raw.ammo["bob-explosive-rocket"].order = "e"
data.raw.ammo["bob-impact-rocket"].order = "f"
data.raw.ammo["bob-poison-rocket"].order = "g"



data.raw.recipe["bullet-magazine"].subgroup = "addon-magazine"
data.raw.recipe["acid-bullet-magazine"].subgroup = "addon-magazine"
data.raw.recipe["ap-bullet-magazine"].subgroup = "addon-magazine"
data.raw.recipe["flame-bullet-magazine"].subgroup = "addon-magazine"
data.raw.recipe["he-bullet-magazine"].subgroup = "addon-magazine"
data.raw.recipe["impact-bullet-magazine"].subgroup = "addon-magazine"
data.raw.recipe["poison-bullet-magazine"].subgroup = "addon-magazine"

data.raw.recipe["better-shotgun-shell"].subgroup = "addon-shotgun"
data.raw.recipe["shotgun-ap-shell"].subgroup = "addon-shotgun"
data.raw.recipe["shotgun-impact-shell"].subgroup = "addon-shotgun"
data.raw.recipe["shotgun-explosive-shell"].subgroup = "addon-shotgun"
data.raw.recipe["shotgun-flame-shell"].subgroup = "addon-shotgun"
data.raw.recipe["shotgun-acid-shell"].subgroup = "addon-shotgun"
data.raw.recipe["shotgun-poison-shell"].subgroup = "addon-shotgun"

data.raw.recipe["laser-rifle-battery"].subgroup = "addon-laser-rifle"
data.raw.recipe["laser-rifle-battery-ruby"].subgroup = "addon-laser-rifle"
data.raw.recipe["laser-rifle-battery-sapphire"].subgroup = "addon-laser-rifle"
data.raw.recipe["laser-rifle-battery-emerald"].subgroup = "addon-laser-rifle"
data.raw.recipe["laser-rifle-battery-amethyst"].subgroup = "addon-laser-rifle"
data.raw.recipe["laser-rifle-battery-topaz"].subgroup = "addon-laser-rifle"
data.raw.recipe["laser-rifle-battery-diamond"].subgroup = "addon-laser-rifle"

data.raw.recipe["bob-rocket"].subgroup = "addon-rocket"
data.raw.recipe["bob-acid-rocket"].subgroup = "addon-rocket"
data.raw.recipe["bob-piercing-rocket"].subgroup = "addon-rocket"
data.raw.recipe["bob-flame-rocket"].subgroup = "addon-rocket"
data.raw.recipe["bob-explosive-rocket"].subgroup = "addon-rocket"
data.raw.recipe["bob-impact-rocket"].subgroup = "addon-rocket"
data.raw.recipe["bob-poison-rocket"].subgroup = "addon-rocket"


data.raw.recipe["better-shotgun-shell"].order = "a"
data.raw.recipe["shotgun-explosive-shell"].order = "f[shotgun-he-shell]"


data.raw.recipe["bob-rocket"].order = "a"
data.raw.recipe["bob-acid-rocket"].order = "b"
data.raw.recipe["bob-piercing-rocket"].order = "c"
data.raw.recipe["bob-flame-rocket"].order = "d"
data.raw.recipe["bob-explosive-rocket"].order = "e"
data.raw.recipe["bob-impact-rocket"].order = "f"
data.raw.recipe["bob-poison-rocket"].order = "g"


--data.raw.item["laser-bubble"].subgroup = "capsule"
--data.raw.item["laser-bubble"].order = "z[laser-bubble]"
data.raw.item["basic-electric-discharge-defense-equipment"].subgroup = "capsule"
data.raw.item["basic-electric-discharge-defense-equipment"].order = "z[basic-electric-discharge-defense-equipment]"



data.raw.item["fusion-reactor-equipment"].subgroup = "addon-equipment"
data.raw.item["fusion-reactor-equipment-2"].subgroup = "addon-equipment"
data.raw.item["fusion-reactor-equipment-3"].subgroup = "addon-equipment"
data.raw.item["fusion-reactor-equipment-4"].subgroup = "addon-equipment"

data.raw.item["energy-shield-equipment"].subgroup = "addon-equipment"
data.raw.item["energy-shield-mk2-equipment"].subgroup = "addon-equipment"
data.raw.item["energy-shield-mk3-equipment"].subgroup = "addon-equipment"
data.raw.item["energy-shield-mk4-equipment"].subgroup = "addon-equipment"
data.raw.item["energy-shield-mk5-equipment"].subgroup = "addon-equipment"
data.raw.item["energy-shield-mk6-equipment"].subgroup = "addon-equipment"


data.raw.item["basic-laser-defense-equipment"].subgroup = "addon-equipment2"
data.raw.item["basic-laser-defense-equipment-2"].subgroup = "addon-equipment2"
data.raw.item["basic-laser-defense-equipment-3"].subgroup = "addon-equipment2"
data.raw.item["basic-laser-defense-equipment-4"].subgroup = "addon-equipment2"
data.raw.item["basic-laser-defense-equipment-5"].subgroup = "addon-equipment2"
data.raw.item["basic-laser-defense-equipment-6"].subgroup = "addon-equipment2"

data.raw.item["combat-robot-dispenser-equipment"].subgroup = "addon-equipment2"
data.raw.item["personal-roboport-equipment"].subgroup = "addon-equipment2"

if data.raw.item["repair-module"] then
	data.raw.item["repair-module"].subgroup = "addon-equipment2"
	data.raw.item["repair-module"].order = "z[repair-module]"
end
if data.raw.item["personal-roboport-equipment-off"] then
	data.raw.item["personal-roboport-equipment-off"].subgroup = "addon-equipment2"
	data.raw.item["personal-roboport-equipment-off"].order = "z[personal-roboport-equipment-off]"
end



data.raw.item["stone-wall"].subgroup = "addon-walls"
data.raw.item["gate"].subgroup = "addon-walls"
data.raw.item["reinforced-wall"].subgroup = "addon-walls"
data.raw.item["reinforced-gate"].subgroup = "addon-walls"

data.raw.item["basic-exoskeleton-equipment"].subgroup = "addon-walls"
data.raw.item["basic-exoskeleton-equipment-2"].subgroup = "addon-walls"
data.raw.item["basic-exoskeleton-equipment-3"].subgroup = "addon-walls"

data.raw.item["night-vision-equipment"].subgroup = "addon-walls"
data.raw.item["night-vision-equipment-2"].subgroup = "addon-walls"
data.raw.item["night-vision-equipment-3"].subgroup = "addon-walls"



--data.raw[""][""].icon = ""
--data.raw[""][""][""]["filename"] = ""

--data.raw["item"][""].icon = ""

