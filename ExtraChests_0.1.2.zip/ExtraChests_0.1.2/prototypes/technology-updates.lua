bobmods.lib.add_technology_recipe("electrolysis-2", "addon-sodium-hydroxide")
bobmods.lib.add_technology_recipe("lead-processing", "addon-sulfur-dioxide")
bobmods.lib.add_technology_recipe("nickel-processing", "addon-sulfur-nickel")
bobmods.lib.add_technology_recipe("chemical-processing-2", "addon-calcium-chloride")


bobmods.lib.add_technology_recipe("void-fluid", "void-petroleum-gas")
bobmods.lib.add_technology_recipe("void-fluid", "void-hydrogen-chloride")
bobmods.lib.add_technology_recipe("void-fluid", "void-crude-oil")
bobmods.lib.add_technology_recipe("void-fluid", "void-ferric-chloride-solution")
bobmods.lib.add_technology_recipe("void-fluid", "void-heavy-oil")
bobmods.lib.add_technology_recipe("void-fluid", "void-light-oil")
bobmods.lib.add_technology_recipe("void-fluid", "void-liquid-fuel")
bobmods.lib.add_technology_recipe("void-fluid", "void-lubricant")
bobmods.lib.add_technology_recipe("void-fluid", "void-water")
bobmods.lib.add_technology_recipe("void-fluid", "void-nitric-acid")
bobmods.lib.add_technology_recipe("void-fluid", "void-nitrogen-dioxide")
bobmods.lib.add_technology_recipe("void-fluid", "void-sulfur-dioxide")
bobmods.lib.add_technology_recipe("void-fluid", "void-sulfuric-acid")
bobmods.lib.add_technology_recipe("void-fluid", "void-tungstic-acid")
bobmods.lib.add_technology_recipe("void-fluid", "void-sulfuric-nitric-acid")
bobmods.lib.add_technology_recipe("void-fluid", "void-glycerol")
bobmods.lib.add_technology_recipe("void-fluid", "void-nitroglycerin")
















