data:extend(
{
---- LOGISTICS
  {
    type = "item-subgroup",
    name = "addon-energy-substation",
    group = "logistics",
    order = "d-a"
  }, 
  {
    type = "item-subgroup",
    name = "addon-underground-belts",
    group = "logistics",
    order = "b-1",
  },        
  {
    type = "item-subgroup",
    name = "addon-splitters",
    group = "logistics",
    order = "b-2",
  },        
  {
    type = "item-subgroup",
    name = "addon-purple-inserter",
    group = "logistics",
    order = "c-c",
  },
  {
    type = "item-subgroup",
    name = "addon-trains",
    group = "logistics",
    order = "e-1",
  },
  {
    type = "item-subgroup",
    name = "addon-cars-tanks",
    group = "logistics",
    order = "e-2",
  }, 
---- BOB-LOGISTICS
  {
    type = "item-subgroup",
    name = "addon-robots-frame",
    group = "bob-logistics",
    order = "f-a"
  },
  {
    type = "item-subgroup",
    name = "addon-logistic-robots",
    group = "bob-logistics",
    order = "f-b",
  },    
  {
    type = "item-subgroup",
    name = "addon-construction-robots",
    group = "bob-logistics",
    order = "f-c",
  },  
  {
    type = "item-subgroup",
    name = "addon-roboports",
    group = "bob-logistics",
    order = "g-a",
  },  
  {
    type = "item-subgroup",
    name = "addon-expander",
    group = "bob-logistics",
    order = "g-b",
  },  
  {
    type = "item-subgroup",
    name = "addon-robochests",
    group = "bob-logistics",
    order = "g-c",
  },  
---- PRODUCTION
  {
    type = "item-subgroup",
    name = "addon-pump-jacks",
    group = "production",
    order = "c-aa",
  },  
  {
    type = "item-subgroup",
    name = "addon-planners-extras",
    group = "production",
    order = "a-1",
  },      
  {
    type = "item-subgroup",
    name = "addon-chemical-machine",
    group = "production",
    order = "d-0",
  }, 
---- BOB-MODULES
  {
    type = "item-subgroup",
    name = "addon-modules1",
    group = "bobmodules",
    order = "f-0a",
  }, 
  {
    type = "item-subgroup",
    name = "addon-modules2",
    group = "bobmodules",
    order = "f-0b",
  }, 
---- INTERMEDIATES
  {
    type = "item-subgroup",
    name = "addon-engines",
    group = "intermediate-products",
    order = "e-0",
  }, 
  {
    type = "item-subgroup",
    name = "addon-rocket-parts",
    group = "intermediate-products",
    order = "e-1",
  }, 

---- BOBS FLUIDS
  {
    type = "item-subgroup",
    name = "addon-petrol-fluids",
    group = "bob-fluid-products",
    order = "a-0"
  },
  {
    type = "item-subgroup",
    name = "addon-fuels-fluids",
    group = "bob-fluid-products",
    order = "a-0a"
  },
  {
    type = "item-subgroup",
    name = "addon-oil-boiler",
    group = "bob-fluid-products",
    order = "a-0b"
  },
  {
    type = "item-subgroup",
    name = "addon-sulfur-fluids",
    group = "bob-fluid-products",
    order = "a-1"
  },
  {
    type = "item-subgroup",
    name = "addon-chloride-fluids",
    group = "bob-fluid-products",
    order = "a-2"
  },
  {
    type = "item-subgroup",
    name = "addon-nitrogen-fluids",
    group = "bob-fluid-products",
    order = "a-3"
  },
  
  {
    type = "item-subgroup",
    name = "addon-loading-bottles",
    group = "bob-fluid-products",
    order = "z-5a"
  },
  {
    type = "item-subgroup",
    name = "addon-empty-bottles",
    group = "bob-fluid-products",
    order = "z-5b"
  },
  {
    type = "item-subgroup",
    name = "addon-loading-barrels",
    group = "bob-fluid-products",
    order = "z-6a"
  },
  {
    type = "item-subgroup",
    name = "addon-empty-barrels",
    group = "bob-fluid-products",
    order = "z-6b"
  },
---- BOBS MATERIALES


---- BOBS INTERMEDIATES
  {
    type = "item-subgroup",
    name = "addon-bullets",
    group = "bob-intermediate-products",
    order = "d-b"
  },

  {
    type = "item-subgroup",
    name = "addon-projectile",
    group = "bob-intermediate-products",
    order = "d-c"
  },


  {
    type = "item-subgroup",
    name = "addon-missile",
    group = "bob-intermediate-products",
    order = "d-d"
  },
  {
    type = "item-subgroup",
    name = "addon-electronics",
    group = "bob-intermediate-products",
    order = "e-a1-a"
  },
  {
    type = "item-subgroup",
    name = "addon-circuits",
    group = "bob-intermediate-products",
    order = "e-a3-b"
  },

  {
    type = "item-subgroup",
    name = "addon-bearing-ball",
    group = "bob-intermediate-products",
    order = "e-b-a"
  },
  {
    type = "item-subgroup",
    name = "addon-roboport-parts",
    group = "bob-intermediate-products",
    order = "e-e"
  },

---- BOBS COMBAT

  {
    type = "item-subgroup",
    name = "addon-magazine",
    group = "combat",
    order = "b-b"
  },
  {
    type = "item-subgroup",
    name = "addon-shotgun",
    group = "combat",
    order = "b-c"
  },
  {
    type = "item-subgroup",
    name = "addon-rocket",
    group = "combat",
    order = "b-d"
  },
  {
    type = "item-subgroup",
    name = "addon-laser-rifle",
    group = "combat",
    order = "b-e"
  },
  {
    type = "item-subgroup",
    name = "addon-mines",
    group = "combat",
    order = "b-0"
  },
  {
    type = "item-subgroup",
    name = "addon-equipment",
    group = "combat",
    order = "e-b"
  },
  {
    type = "item-subgroup",
    name = "addon-equipment2",
    group = "combat",
    order = "e-c"
  },
  {
    type = "item-subgroup",
    name = "addon-walls",
    group = "combat",
    order = "e-z"
  },

}
)
