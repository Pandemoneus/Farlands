
data:extend(
{
  {
    type = "recipe",
    name = "alumina",
    category = "chemical-furnace",
    subgroup = "bob-material-chemical",
    energy_required = 2,
    enabled = false,
    ingredients =
    {
      {"sodium-hydroxide", 4},
      {"bauxite-ore", 1},
    },
    result="alumina",
  },
  {
    type = "recipe",
    name = "addon-sodium-hydroxide-compact",
    category = "smelting",
    subgroup = "bob-material-smelting",
    energy_required = 5,
    enabled = "false",
    ingredients = {{"sodium-hydroxide", 20}},
    icon = "__ExtraChests__/graphics/icons/fluids/sodium-hydroxide-compact.png",
    result = "sodium-hydroxide",
  },  
  {
    type = "recipe",
    name = "addon-sulfur-dioxide",
    category = "chemistry",
    subgroup = "addon-sulfur-fluids",
    energy_required = 2,
    enabled = false,
    ingredients =
    {
      {type="item", name="lead-ore", amount=1},
      {type="fluid", name="oxygen", amount=1.5},
    },
    results=
    {
      {type="item", name="lead-oxide", amount=1},
      {type="fluid", name="sulfur-dioxide", amount=1},
    },
    main_product= "sulfur-dioxide",
    icon = "__ExtraChests__/graphics/icons/fluids/sulfur-dioxide.png",
    order = "a[sulfur1]",
  },
  {
    type = "recipe",
    name = "addon-sulfur-nickel",
    category = "electrolysis",
    subgroup = "addon-sulfur-fluids",
    energy_required = 3.5,
    enabled = false,
    ingredients =
    {
      {type="item", name="nickel-ore", amount=1},
      {type="fluid", name="water", amount=1},
      {type="fluid", name="oxygen", amount=1.5}
    },
    results=
    {
      {type="fluid", name="sulfuric-acid", amount=1},
      {type="item", name="nickel-plate", amount=1}
    },
    main_product= "sulfuric-acid",
    icon = "__ExtraChests__/graphics/icons/fluids/sulfuric-nickel-recipe.png",
    order = "a[sulfur4]",
  },
  {
    type = "recipe",
    name = "addon-calcium-chloride",
    category = "chemistry",
    enabled = "false",
    energy_required = 2,
    ingredients =
    {
      {type="item", name="tungsten-ore", amount=2},
      {type="fluid", name="hydrogen-chloride", amount=4}
    },
    results=
    {
      {type="fluid", name="tungstic-acid", amount=2},
      {type="item", name="calcium-chloride", amount=1}
    },
    main_product= "calcium-chloride",
    subgroup = "bob-resource-chemical",
    icon = "__ExtraChests__/graphics/icons/fluids/tungstic-acid-calcium-chloride.png",
    order = "f[calcium-chloride]"
  },
  {
    type = "recipe",
    name = "addon-salt-water-electrolysis",
    category = "electrolysis",
    enabled = "false",
    energy_required = 1,
    ingredients =
    {
      {type="item", name="salt", amount=2},
      {type="fluid", name="water", amount=2}
    },
    results=
    {
      {type="item", name="sodium-hydroxide", amount=1},
      {type="fluid", name="chlorine", amount=1},
      {type="fluid", name="hydrogen", amount=1},
    },
    icon = "__ExtraChests__/graphics/icons/fluids/sodium-hydroxide-recipe.png",
    subgroup = "bob-material-electrolysis",
    order = "z[fluid-chemistry]-b[salt-water-electrolysis]"
  },
  {
    type = "recipe",
    name = "addon-lithium-water-electrolysis",
    category = "electrolysis",
    enabled = "false",
    energy_required = 1,
    ingredients =
    {
      {type="item", name="lithium-chloride", amount=1},
      {type="fluid", name="water", amount=2}
    },
    results=
    {
      {type="item", name="lithium-perchlorate", amount=1},
      {type="fluid", name="hydrogen", amount=1},
    },
    icon = "__ExtraChests__/graphics/icons/fluids/lithium-perchlorate-recipe.png",
    subgroup = "bob-material-electrolysis",
    order = "z[fluid-chemistry]-c[lithium-water-electrolysis]"
  },
  
 }
)



