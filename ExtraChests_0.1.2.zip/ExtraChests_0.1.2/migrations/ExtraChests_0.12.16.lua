game.reload_script()

for index, force in pairs(game.forces) do
  force.reset_recipes()
  force.reset_technologies()

  if force.technologies["electrolysis-2"].researched then
    force.recipes["addon-sodium-hydroxide"].enabled = true
    force.recipes["addon-salt-water-electrolysis"].enabled = true
  end

  if force.technologies["lead-processing"].researched then
    force.recipes["addon-sulfur-dioxide"].enabled = true
  end

  if force.technologies["nickel-processing"].researched then
    force.recipes["addon-sulfur-nickel"].enabled = true
  end

  if force.technologies["chemical-processing-2"].researched then
    force.recipes["addon-calcium-chloride"].enabled = true
  end

  if force.technologies["lithium-processing"].researched then
    force.recipes["addon-lithium-water-electrolysis"].enabled = true
  end

  if force.technologies["void-fluid"].researched then
    force.recipes["void-petroleum-gas"].enabled = true
    force.recipes["void-hydrogen-chloride"].enabled = true
    force.recipes["void-crude-oil"].enabled = true
    force.recipes["void-ferric-chloride-solution"].enabled = true
    force.recipes["void-heavy-oil"].enabled = true
    force.recipes["void-light-oil"].enabled = true
    force.recipes["void-liquid-fuel"].enabled = true
    force.recipes["void-lubricant"].enabled = true
    force.recipes["void-water"].enabled = true
    force.recipes["void-nitric-acid"].enabled = true
    force.recipes["void-nitrogen-dioxide"].enabled = true
    force.recipes["void-sulfur-dioxide"].enabled = true
    force.recipes["void-sulfuric-acid"].enabled = true
    force.recipes["void-tungstic-acid"].enabled = true
    force.recipes["void-sulfur-dioxide"].enabled = true
    force.recipes["void-sulfuric-acid"].enabled = true
    force.recipes["void-tungstic-acid"].enabled = true
    force.recipes["void-sulfuric-nitric-acid"].enabled = true
    force.recipes["void-glycerol"].enabled = true
    force.recipes["void-nitroglycerin"].enabled = true
  end

end