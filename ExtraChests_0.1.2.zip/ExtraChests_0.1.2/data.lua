require "config"
require("prototypes.category")


--[[ Radars Check ]]--
require("prototypes.radars")

--[[ Large Chests Check ]]--
require("prototypes.chests")

--[[ Large Logistic Chests Check ]]--
require("prototypes.logistic-chests")

--[[ Express Smart Inserters ]]--
require("prototypes.fast-smart-inserters")

--[[ New recipes ]]--
require("prototypes.recipe-updates")

--[[ Fancy grafics for boilers ]]--
require("prototypes.boilers")


--[[ New recipes for voids ]]--
require("prototypes.void-recipe")
