Config = {} -- DONT TOCUH THIS LINE!

RadarMk2ScanDistance = 30 --Default=20
RadarMk3ScanDistance = 40 --Default=30
RadarMk4ScanDistance = 50 --Default=40
RadarMk5ScanDistance = 60 --Default=50

upgrade_tank_capacity = false        -- Bob's standard values if false

-- as long as the main option is true, icons will be changed too no matter if their option is true or false
-- if main option is false and _icons is true, then only icons in menus will be changed
-- For low resolution animation to be on is to have the main _graphics = true

drill_graphics = true
	drill_lowres = false          
	drill_graphics_icons = true	

steam_graphics = true
	steam_lowres = false
	steam_graphics_icons = true
		
accumlator_graphics = true
	accumlator_lowres = false
	accumlator_graphics_icons = true
	
solar_graphics = true
	solar_graphics_icons = true

poles_graphics = true
	poles_graphics_icons = true

boiler_graphics = true
	boiler_graphics_icons = true
	
tank_graphics = true
	factorio_style = true
	
	
assembling_graphics = true
robochest_graphics = true
radar_graphics = true
pumpjack_graphics = true
belts_graphics = true
chemicalplant_graphics = true
electroliser_graphics = true
electricfurnace_graphics = true
liquid_graphics = true
circuit_graphics = false
menu_graphics = true
techonologies_graphics = true
