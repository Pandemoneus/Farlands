data:extend({
  {
    type = "custom-input",
    name = "QuickUGEnableDisable",
    key_sequence = "CONTROL + u",
  },
  {
    type = "custom-input",
    name = "QuickUGEnableVerbose",
    key_sequence = "CONTROL + SHIFT + u",
  }
})