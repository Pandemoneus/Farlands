function init()
	if global.mode == nil then
		global.mode = {}
	end 
end

function initplayer (player_index)
	if global.mode == nil then
		init()
	end
	if global.mode[player_index] == nil then
		global.mode[player_index] = {}
	end
	if global.mode[player_index]["mode"] == nil then
		global.mode[player_index]["mode"] = "enable"
	end
	if global.mode[player_index]["verbose"] == nil then
		global.mode[player_index]["verbose"] = false
	end
end

function EnableDisableQuickUG(event)
	local player = game.players[event.player_index]
	if global.mode == nil or global.mode[event.player_index] == nil or global.mode[event.player_index]["mode"] == nil then
		initplayer(event.player_index)
	elseif global.mode[event.player_index]["mode"] == "enable" then
		global.mode[event.player_index]["mode"]  = "safe"
		player.print("Quick UG Belt: Safe")
	elseif global.mode[event.player_index]["mode"] == "safe" then
		global.mode[event.player_index]["mode"]  = "disable"
		player.print("Quick UG Belt: Disabled")
	elseif global.mode[event.player_index]["mode"] == "disable" then
		global.mode[event.player_index]["mode"]  = "enable"
		player.print("Quick UG Belt: Enabled")
	end
end

function EnableDisableVerbose(event)
	local player = game.players[event.player_index]
	if global.mode == nil or global.mode[event.player_index] == nil or global.mode[event.player_index]["verbose"] == nil then
		initplayer(event.player_index)
	elseif global.mode[event.player_index]["verbose"] == false then
		global.mode[event.player_index]["verbose"]  = true
		player.print("Quick UG Belt: Verbose Enabled")
	elseif global.mode[event.player_index]["verbose"] == true then
		global.mode[event.player_index]["verbose"]  = false
		player.print("Quick UG Belt: Verbose Disabled")
	end
end

script.on_init(init)
script.on_event('QuickUGEnableDisable', function(event) EnableDisableQuickUG(event) end)
script.on_event('QuickUGEnableVerbose', function(event) EnableDisableVerbose(event) end)
script.on_event(defines.events.on_player_joined_game, function(event) initplayer(event.player_index) end)

script.on_event(defines.events.on_built_entity, function(event)

	if global.mode == nil then
		initplayer(event.player_index)
	end
	if global.mode[event.player_index] == nil or global.mode[event.player_index]["mode"] == nil or global.mode[event.player_index]["mode"] == "disable" then
		return
	end
   
	local entity = event.created_entity
	local player = game.players[event.player_index]

	if entity.type ~= "underground-belt" then
		return
	end
	local belt_type = "transport-belt"
	if entity.neighbours[1] == nil then
		return
	else 
		nb = entity.neighbours[1]
		local belts = nil
		if entity.direction == defines.direction.north or entity.direction == defines.direction.west then
			belts = entity.surface.find_entities_filtered{type = belt_type, area = {{entity.position.x, entity.position.y}, {nb.position.x, nb.position.y}}}
		else
			belts = entity.surface.find_entities_filtered{type = belt_type, area = {{nb.position.x, nb.position.y}, {entity.position.x, entity.position.y}}}
		end
		if belts ~= nil then 
			if global.mode[event.player_index]["mode"] == "safe" then
				for i,belt in ipairs(belts) do
					if belt.direction ~= entity.direction then
						return
					end
				end
			end
			num_belt = 0
			for i,belt in ipairs(belts) do
				if belt.direction == entity.direction then
					num_belt = num_belt + 1
					for name,count in pairs(belt.get_transport_line(1).get_contents()) do
						player.get_inventory(defines.inventory.player_main).insert({name = name, count = count})
					end
					belt.get_transport_line(1).clear()
					for name,count in pairs(belt.get_transport_line(2).get_contents()) do
						player.get_inventory(defines.inventory.player_main).insert({name = name, count = count})
					end
					belt.get_transport_line(2).clear()
					player.get_inventory(defines.inventory.player_main).insert({name = belt.name, count = 1})
					belt.destroy()
				end
			end
			if global.mode[event.player_index]["verbose"] ~= nil and global.mode[event.player_index]["verbose"] == true  and num_belt > 0 then
						player.print("Quick UG Belt: " .. num_belt .. " belts removed.")
			end
		end
	end
end)
 