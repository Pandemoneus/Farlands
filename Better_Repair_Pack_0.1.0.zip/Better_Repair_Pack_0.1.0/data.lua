require("prototypes.item.betterrepairpack")

require("prototypes.recipe.betterrepairpack")

require("prototypes.technology.betterrepairpack")