data:extend({

{
    type = "recipe",
    name = "better-repair-pack",
	energy_required = 1,
	enabled = false,
    ingredients =
    {
      {"advanced-circuit", 2},
      {"iron-gear-wheel", 15},
	  {"steel-plate", 10},
	  {"repair-pack", 1}
    },
    result = "better-repair-pack",
    requester_paste_multiplier = 10
  }
  
  })