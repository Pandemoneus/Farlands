data:extend({

{
    type = "technology",
    name = "better-repair-pack",
    icon = "__base__/graphics/technology/automobilism.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "better-repair-pack"
      },
    },
    prerequisites = {"automobilism"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1}
      },
      time = 25
    },
    order = "e-c"
  }
  
  })