data:extend({

{
    type = "repair-tool",
    name = "better-repair-pack",
    icon = "__base__/graphics/icons/repair-pack.png",
    flags = {"goes-to-quickbar"},
    subgroup = "tool",
    order = "b[repair]-b[repair-pack]",
    speed = 2,
    durability = 350,
    stack_size = 100
  }
 
  })