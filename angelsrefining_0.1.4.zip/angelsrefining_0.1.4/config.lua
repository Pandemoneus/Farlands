--Enables the ore refining
angelsmods.refining.enableorerefining = true
--Enables the water treatment
angelsmods.refining.enablewatertreatment  = true