data:extend(
{
--ORE CRUSHER
	{
    type = "recipe",
    name = "burner-ore-crusher",
    energy_required = 10,
	enabled = "true",
    ingredients ={
	{"stone", 5},
	},
    result= "burner-ore-crusher",
    icon = "__angelsrefining__/graphics/icons/ore-crusher-burner.png",
    },
	{
    type = "recipe",
    name = "ore-crusher",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"iron-plate", 10},
	{"stone-brick", 10},
	{"iron-gear-wheel", 5},
	},
    result= "ore-crusher",
    icon = "__angelsrefining__/graphics/icons/ore-crusher.png",
	},
	{
    type = "recipe",
    name = "ore-crusher-2",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"ore-crusher", 1},
	{"steel-plate", 10},
	{"stone-brick", 10},
	{"advanced-circuit", 5},
	},
    result= "ore-crusher-2",
    icon = "__angelsrefining__/graphics/icons/ore-crusher-2.png",
	},
--ORE FLOATATION CELL
	{
    type = "recipe",
    name = "ore-floatation-cell",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"iron-plate", 10},
	{"stone-brick", 10},
	{"electronic-circuit", 5},
	},
    result= "ore-floatation-cell",
    icon = "__angelsrefining__/graphics/icons/ore-floatation-cell.png",
    },
	{
    type = "recipe",
    name = "ore-floatation-cell-2",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"ore-floatation-cell", 1},
	{"steel-plate", 10},
	{"stone-brick", 10},
	{"advanced-circuit", 5},
	},
    result= "ore-floatation-cell-2",
    icon = "__angelsrefining__/graphics/icons/ore-floatation-cell-2.png",
    },
--ORE LEACHING PLANT
	{
    type = "recipe",
    name = "ore-leaching-plant",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"iron-plate", 10},
	{"stone-brick", 10},
	{"electronic-circuit", 5},
	},
    result= "ore-leaching-plant",
    icon = "__angelsrefining__/graphics/icons/ore-leaching-plant.png",
    },
	{
    type = "recipe",
    name = "ore-leaching-plant-2",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"ore-leaching-plant", 1},
	{"steel-plate", 10},
	{"stone-brick", 10},
	{"advanced-circuit", 5},
	},
    result= "ore-leaching-plant-2",
    icon = "__angelsrefining__/graphics/icons/ore-leaching-plant-2.png",
    },
 --ORE REFINERY
 	{
    type = "recipe",
    name = "ore-refinery",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"iron-plate", 10},
	{"stone-brick", 20},
	{"advanced-circuit", 5},
	},
    result= "ore-refinery",
    icon = "__angelsrefining__/graphics/icons/ore-refinery.png",
    },
	{
    type = "recipe",
    name = "ore-refinery-2",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"ore-refinery", 1},
	{"steel-plate", 10},
	{"stone-brick", 20},
	{"advanced-circuit", 5},
	},
    result= "ore-refinery-2",
    icon = "__angelsrefining__/graphics/icons/ore-refinery-2.png",
    },
--ORE SORTING FACILITY
	{
    type = "recipe",
    name = "ore-sorting-facility",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"iron-plate", 10},
	{"stone-brick", 30},
	{"electronic-circuit", 5},
	},
    result= "ore-sorting-facility",
    icon = "__angelsrefining__/graphics/icons/ore-sorting-facility.png",
    },
	{
    type = "recipe",
    name = "ore-sorting-facility-2",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"ore-sorting-facility", 1},
	{"steel-plate", 10},
	{"stone-brick", 30},
	{"advanced-circuit", 5},
	},
    result= "ore-sorting-facility-2",
    icon = "__angelsrefining__/graphics/icons/ore-sorting-facility-2.png",
    },
	{
    type = "recipe",
    name = "ore-sorting-facility-3",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"ore-sorting-facility-2", 1},
	{"steel-plate", 10},
	{"stone-brick", 30},
	{"advanced-circuit", 5},
	},
    result= "ore-sorting-facility-3",
    icon = "__angelsrefining__/graphics/icons/ore-sorting-facility-3.png",
    },
--FILTRATION UNIT
    {
    type = "recipe",
    name = "filtration-unit",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"steel-plate", 10},
	{"stone-brick", 20},
	{"electronic-circuit", 5},
	{"pipe", 5},
	},
    result="filtration-unit",
    icon = "__angelsrefining__/graphics/icons/filtration-unit.png",
    },
 --CRYSTALLIZER
    {
    type = "recipe",
    name = "crystallizer",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{"steel-plate", 10},
	{"stone-brick", 20},
	{"electronic-circuit", 5},
	{"pipe", 5},
	},
    result="crystallizer",
    icon = "__angelsrefining__/graphics/icons/crystallizer.png",
    },
  }
  )