data:extend(
{
--TIER 1
	{
    type = "recipe",
    name = "iron-ore-crushed",
    category = "ore-sorting-t1",
	subgroup = "ore-processing-a",
    energy_required = 1,
	enabled = "false",
    ingredients ={{"raw-iron-ore", 2}},
    results=
    {
		{type="item", name="iron-ore-crushed", amount=2},
		{type="item", name="stone-crushed", amount=1}
    },
    icon = "__angelsrefining__/graphics/icons/iron-ore-crushed.png",
    order = "c-a-a[iron-ore-crushed]",
	},
	{
    type = "recipe",
    name = "iron-ore-crushed-hand",
	category = "crafting",
	subgroup = "ore-processing-a",
    energy_required = 4,
	enabled = "true",
    ingredients ={{"raw-iron-ore", 2}},
    results=
    {
      {type="item", name="iron-ore-crushed", amount=2},
      {type="item", name="stone-crushed", amount=1}
    },
    icon = "__angelsrefining__/graphics/icons/iron-ore-crushed.png",
    order = "c[iron-ore-crushed-hand]",
	},
	{
    type = "recipe",
    name = "copper-ore-crushed",
    category = "ore-sorting-t1",
	subgroup = "ore-processing-a",
    energy_required = 1,
	enabled = "false",
    ingredients ={{"raw-copper-ore", 2}},
    results=
    {
		{type="item", name="copper-ore-crushed", amount=2},
		{type="item", name="stone-crushed", amount=1}
    },
    icon = "__angelsrefining__/graphics/icons/copper-ore-crushed.png",
    order = "c-a-b[copper-ore-crushed]",
	},
	{
    type = "recipe",
    name = "copper-ore-crushed-hand",
	category = "crafting",
	subgroup = "ore-processing-a",
    energy_required = 4,
	enabled = "true",
    ingredients ={{"raw-copper-ore", 2}},
    results=
    {
      {type="item", name="copper-ore-crushed", amount=2},
      {type="item", name="stone-crushed", amount=1}
    },
    icon = "__angelsrefining__/graphics/icons/copper-ore-crushed.png",
    order = "d[copper-ore-crushed-hand]",
	},
--TIER 2
	{
    type = "recipe",
    name = "iron-ore-chunk",
    category = "ore-sorting-t2",
	subgroup = "ore-processing-b",
    energy_required = 2,
	enabled = "false",
    ingredients ={
		{type="item", name="iron-ore-crushed", amount=2},
		{type="fluid", name="water", amount=2},
	},
    results=
    {
		{type="item", name="iron-ore-chunk", amount=2},
		{type="item", name="sulfur", amount=1, probability=0.75}
    },
    icon = "__angelsrefining__/graphics/icons/iron-ore-chunk.png",
    order = "c-b-a[iron-ore-chunk]",
	},
	{
    type = "recipe",
    name = "copper-ore-chunk",
    category = "ore-sorting-t2",
	subgroup = "ore-processing-b",
    energy_required = 2,
	enabled = "false",
    ingredients ={
		{type="item", name="copper-ore-crushed", amount=2},
		{type="fluid", name="water", amount=2},
	},
    results=
    {
		{type="item", name="copper-ore-chunk", amount=2},
		{type="item", name="sulfur", amount=1, probability=0.75}
    },
    icon = "__angelsrefining__/graphics/icons/copper-ore-chunk.png",
    order = "c-b-b[copper-ore-chunk]",
	},
--TIER 3
	{
    type = "recipe",
    name = "iron-ore-crystal",
    category = "ore-sorting-t3",
	subgroup = "ore-processing-c",
    energy_required = 2,
	enabled = "false",
    ingredients ={
		{type="item", name="iron-ore-chunk", amount=2},
		{type="fluid", name="sulfuric-acid", amount=0.5}
	},
    results=
    {
		{type="item", name="iron-ore-crystal", amount=2},
    },
    icon = "__angelsrefining__/graphics/icons/iron-ore-crystal.png",
    order = "c-c-a[iron-ore-crystal]",
	},
	{
    type = "recipe",
    name = "copper-ore-crystal",
    category = "ore-sorting-t3",
	subgroup = "ore-processing-c",
    energy_required = 2,
	enabled = "false",
    ingredients ={
		{type="item", name="copper-ore-chunk", amount=2},
		{type="fluid", name="sulfuric-acid", amount=0.5}
	},
    results=
    {
		{type="item", name="copper-ore-crystal", amount=2},
    },
    icon = "__angelsrefining__/graphics/icons/copper-ore-crystal.png",
    order = "c-c-b[copper-ore-crystal]",
	},
--TIER 4
	{
    type = "recipe",
    name = "iron-ore-pure",
    category = "ore-sorting-t4",
	subgroup = "ore-processing-d",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"iron-ore-crystal", 2}},
    results=
    {
		{type="item", name="iron-ore-pure", amount=2},
    },
    icon = "__angelsrefining__/graphics/icons/iron-ore-pure.png",
    order = "c-d-a[iron-ore-pure]",
	},
	{
    type = "recipe",
    name = "copper-ore-pure",
    category = "ore-sorting-t4",
	subgroup = "ore-processing-d",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"copper-ore-crystal", 2}},
    results=
    {
		{type="item", name="copper-ore-pure", amount=2},
    },
    icon = "__angelsrefining__/graphics/icons/copper-ore-pure.png",
    order = "c-d-b[copper-ore-pure]",
	},
}
)