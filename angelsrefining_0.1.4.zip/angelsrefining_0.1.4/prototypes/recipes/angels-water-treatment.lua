data:extend(
{
	{
    type = "recipe",
    name = "water-purification",
    category = "water-treatment",
	subgroup = "water-treatment",
    energy_required = 1,
	enabled = "false",
    ingredients ={
	{type="fluid", name="water", amount=15}
	},
    results=
    {
      {type="fluid", name="water-saline", amount=2},
      {type="fluid", name="water-purified", amount=10},
    },
    icon = "__angelsrefining__/graphics/icons/water-purification.png",
    order = "a[water-purification]",
	},
	{
    type = "recipe",
    name = "thermal-water-purification",
    category = "water-treatment",
	subgroup = "water-treatment",
    energy_required = 1,
	enabled = "false",
    ingredients ={
	{type="fluid", name="thermal-water", amount=5}
	},
    results=
    {
      {type="fluid", name="mineral-sludge", amount=2},
      {type="fluid", name="water-purified", amount=3},
    },
    icon = "__angelsrefining__/graphics/icons/water-thermal-purification.png",
    order = "a[thermal-water-purification]",
	},
	{
    type = "recipe",
    name = "floatation-waste-water-purification",
    category = "water-treatment",
	subgroup = "water-treatment",
    energy_required = 1,
	enabled = "false",
    ingredients ={
	{type="fluid", name="water-floatation-waste", amount=10}
	},
    results=
    {
      {type="fluid", name="water-mineralized", amount=2},
      {type="fluid", name="water-purified", amount=7},
	  {type="item", name="sulfur", amount=1},
    },
    icon = "__angelsrefining__/graphics/icons/water-floatation-waste-purification.png",
    order = "a[floatation-waste-water-purification]",
	},
}
)

if angelsmods.refining then
data.raw["recipe"]["angelsore1-chunk"].ingredients[2]={type="fluid", name="water-purified", amount=5}
data.raw["recipe"]["angelsore2-chunk"].ingredients[2]={type="fluid", name="water-purified", amount=5}
data.raw["recipe"]["angelsore3-chunk"].ingredients[2]={type="fluid", name="water-purified", amount=5}
data.raw["recipe"]["angelsore4-chunk"].ingredients[2]={type="fluid", name="water-purified", amount=5}
data.raw["recipe"]["angelsore5-chunk"].ingredients[2]={type="fluid", name="water-purified", amount=5}
data.raw["recipe"]["angelsore6-chunk"].ingredients[2]={type="fluid", name="water-purified", amount=5}

data.raw["recipe"]["angelsore1-chunk"].results[2]={type = "fluid", name = "water-floatation-waste", amount=5}
data.raw["recipe"]["angelsore2-chunk"].results[2]={type = "fluid", name = "water-floatation-waste", amount=5}
data.raw["recipe"]["angelsore3-chunk"].results[2]={type = "fluid", name = "water-floatation-waste", amount=5}
data.raw["recipe"]["angelsore4-chunk"].results[2]={type = "fluid", name = "water-floatation-waste", amount=5}
data.raw["recipe"]["angelsore5-chunk"].results[2]={type = "fluid", name = "water-floatation-waste", amount=5}
data.raw["recipe"]["angelsore6-chunk"].results[2]={type = "fluid", name = "water-floatation-waste", amount=5}
end
if bobmods then
data:extend(
{
  {
    type = "recipe",
    name = "salt-water-electrolysis-2",
    category = "electrolysis",
    enabled = "false",
    energy_required = 1,
    ingredients =
    {
      {type="fluid", name="water-saline", amount=4}
    },
    results=
    {
      {type="item", name="sodium-hydroxide", amount=1},
      {type="fluid", name="chlorine", amount=1},
      {type="fluid", name="hydrogen", amount=1},
    },
    icon = "__bobplates__/graphics/icons/salt-water-electrolysis.png",
    subgroup = "bob-fluid-electrolysis",
    order = "b[fluid-chemistry]-b[salt-water-electrolysis]"
  },
}
)
end
--OVERRIDE FOR YUOKI
if data.raw.item["y-res1"] then
	data:extend({
		{
		type = "recipe",
		name = "floatation-waste-water-purification-yi",
		category = "water-treatment",
		subgroup = "water-treatment",
		energy_required = 1,
		enabled = "false",
		ingredients ={
		{type="fluid", name="water-floatation-waste", amount=10}
		},
		results=
		{
		  {type="fluid", name="y-con_water", amount=2},
		  {type="fluid", name="water-purified", amount=7},
		  {type="item", name="sulfur", amount=1},
		},
		icon = "__angelsrefining__/graphics/icons/water-floatation-waste-purification-yi.png",
		order = "a[floatation-waste-water-purification-yi]",
		},
	})
end