data:extend(
{
--SMELTING
	{
    type = "recipe",
    name = "iron-ore-crushed-smelting",
    category = "smelting",
	subgroup = "raw-material",
    energy_required = 7,
	enabled = "true",
    ingredients ={{"iron-ore-crushed", 3}},
    results=
    {
      {type="item", name="iron-plate", amount=2},
    },
    main_product= "iron-plate",
    icon = "__angelsrefining__/graphics/icons/iron-plate-crushed-v.png",
    order = "a-a [iron-ore-crushed-smelting]",
	},
	{
    type = "recipe",
    name = "copper-ore-crushed-smelting",
    category = "smelting",
	subgroup = "raw-material",
    energy_required = 7,
	enabled = "true",
    ingredients ={{"copper-ore-crushed", 3}},
    results=
    {
      {type="item", name="copper-plate", amount=2},
    },
    main_product= "copper-plate",
    icon = "__angelsrefining__/graphics/icons/copper-plate-crushed-v.png",
    order = "a-a [copper-ore-crushed-smelting]",
	},
--STONE & SLAG
	{
    type = "recipe",
    name = "filter-frame",
    category = "crafting",
	subgroup = "processing-crafting",
    energy_required = 1,
	enabled = "false",
    ingredients ={
    {type="item", name="steel-plate", amount=1},
    {type="item", name="iron-plate", amount=1},
	},
    results=
    {
      {type="item", name="filter-frame", amount=1},
    },
    icon = "__angelsrefining__/graphics/icons/filter-frame.png",
    order = "a-a [filter-frame]",
	},
	{
    type = "recipe",
    name = "filter-coal",
    category = "crafting",
	subgroup = "processing-crafting",
    energy_required = 1,
	enabled = "false",
    ingredients ={
    {type="item", name="coal", amount=1},
    {type="item", name="filter-frame", amount=5},
	},
    results=
    {
      {type="item", name="filter-coal", amount=5},
    },
    icon = "__angelsrefining__/graphics/icons/filter-coal.png",
    order = "a-a [filter-coal]",
	},
	{
    type = "recipe",
    name = "slag-processing-dissolution",
    category = "chemistry",
	subgroup = "slag-processing",
    energy_required = 3,
	enabled = "false",
    ingredients ={{"slag", 5}},
    results=
    {
      {type="fluid", name="slag-slurry", amount=1},
    },
    icon = "__angelsrefining__/graphics/icons/slag-slurry.png",
    order = "a-a [slag-processing-dissolution]",
	},
	{
    type = "recipe",
    name = "slag-processing-filtering-1",
    category = "filtering",
	subgroup = "slag-processing",
    energy_required = 3,
	enabled = "false",
    ingredients ={
    {type="fluid", name="slag-slurry", amount=1},
    {type="item", name="filter-coal", amount=1},
	},
    results=
    {
      {type="fluid", name="mineral-sludge", amount=1},
      {type="item", name="filter-frame", amount=1},
    },
    icon = "__angelsrefining__/graphics/icons/slag-filtering-1.png",
    order = "a-a [slag-processing-filtering-1]",
	},
	{
    type = "recipe",
    name = "slag-processing-1",
    category = "crystallizing",
	subgroup = "slag-processing",
    energy_required = 8,
	enabled = "false",
    ingredients ={
	{type="fluid", name="mineral-sludge", amount=1},
	},
    results=
    {
      {type="item", name="copper-ore", amount=1, probability=0.4},
      {type="item", name="iron-ore", amount=1, probability=0.4},
    },
    icon = "__angelsrefining__/graphics/icons/slag.png",
    order = "a-a [slag-processing-1]",
	},
	{
    type = "recipe",
    name = "slag-processing-5",
    category = "ore-sorting-t1",
	subgroup = "slag-processing",
    energy_required = 1,
	enabled = "false",
    ingredients ={{"slag", 1}},
    results=
    {
      {type="item", name="stone-crushed", amount=2},
    },
	main_product = "stone-crushed",
    icon = "__angelsrefining__/graphics/icons/stone-crushed.png",
    order = "a-a [slag-processing-5]",
	},
	{
    type = "recipe",
    name = "stone-crushed",
    category = "crafting",
	subgroup = "processing-crafting",
    energy_required = 0.5,
	enabled = "true",
    ingredients ={{"stone-crushed", 2}},
    results=
    {
      {type="item", name="stone", amount=1},
    },
	main_product = "stone",
    icon = "__base__/graphics/icons/stone.png",
    order = "c-a-i[stone-crushed]",
	},
--CATALYSTS
  	{
    type = "recipe",
    name = "catalysator-brown",
    category = "crafting-with-fluid",
	subgroup = "processing-crafting",
    energy_required = 10,
	enabled = "false",
    ingredients ={
    {type="fluid", name="mineral-sludge", amount=1},
	{type="item", name="alien-artifact", amount=1},
    },
    results=
    {
      {type="item", name="catalysator-brown", amount=100},
    },
    icon = "__angelsrefining__/graphics/icons/catalysator-brown.png",
    order = "a-a [catalysator-brown]",
	},
--Tier 1
	{
    type = "recipe",
    name = "iron-ore-crushed-processing",
    category = "ore-sorting",
	subgroup = "ore-sorting-t1",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"iron-ore-crushed", 4}},
    results=
    {
      {type="item", name="iron-ore", amount=3},
	  {type="item", name="slag", amount=1},
    },
    icon = "__angelsrefining__/graphics/icons/iron-ore-crushed-sorting.png",
    order = "c-f-a[iron-ore-crushed-processing]",
	},
	{
    type = "recipe",
    name = "copper-ore-crushed-processing",
    category = "ore-sorting",
	subgroup = "ore-sorting-t1",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"copper-ore-crushed", 4}},
    results=
    {
      {type="item", name="copper-ore", amount=3},
	  {type="item", name="slag", amount=1},
    },
    icon = "__angelsrefining__/graphics/icons/copper-ore-crushed-sorting.png",
    order = "c-f-b[copper-ore-crushed-processing]",
	},
--TIER 2
	{
    type = "recipe",
    name = "iron-ore-chunk-processing",
    category = "ore-sorting",
	subgroup = "ore-sorting-t2",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"iron-ore-chunk", 6}},
    results=
    {
      {type="item", name="iron-ore", amount=5},
	  {type="item", name="slag", amount=1},
    },
    icon = "__angelsrefining__/graphics/icons/iron-ore-chunk-sorting.png",
    order = "c-g-a[iron-ore-chunk-processing]",
	},
	{
    type = "recipe",
    name = "copper-ore-chunk-processing",
    category = "ore-sorting",
	subgroup = "ore-sorting-t2",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"copper-ore-chunk", 6}},
    results=
    {
      {type="item", name="copper-ore", amount=5},
	  {type="item", name="slag", amount=1},
    },
    icon = "__angelsrefining__/graphics/icons/copper-ore-chunk-sorting.png",
    order = "c-g-b[copper-ore-chunk-processing]",
	},
--TIER 3
	{
    type = "recipe",
    name = "iron-ore-crystal-processing",
    category = "ore-sorting",
	subgroup = "ore-sorting-t3",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"iron-ore-crystal", 8}},
    results=
    {
      {type="item", name="iron-ore", amount=7},
	  {type="item", name="slag", amount=1},
    },
    icon = "__angelsrefining__/graphics/icons/iron-ore-crystal-sorting.png",
    order = "c-i-a[iron-ore-crystal-processing]",
	},
	{
    type = "recipe",
    name = "copper-ore-crystal-processing",
    category = "ore-sorting",
	subgroup = "ore-sorting-t3",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"copper-ore-crystal", 8}},
    results=
    {
      {type="item", name="copper-ore", amount=7},
	  {type="item", name="slag", amount=1},
    },
    icon = "__angelsrefining__/graphics/icons/copper-ore-crystal-sorting.png",
    order = "c-i-b[copper-ore-crystal-processing]",
	},
--TIER 4
	{
    type = "recipe",
    name = "iron-ore-pure-processing",
    category = "ore-sorting",
	subgroup = "ore-sorting-t4",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="iron-ore-pure", amount=10},
	{type="item", name="catalysator-brown", amount=1},
	},
    results=
    {
      {type="item", name="iron-ore", amount=10},
    },
    icon = "__angelsrefining__/graphics/icons/iron-ore-pure-sorting.png",
    order = "c-j-a[iron-ore-pure-processing]",
	},
	{
    type = "recipe",
    name = "copper-ore-pure-processing",
    category = "ore-sorting",
	subgroup = "ore-sorting-t4",
    energy_required = 2,
	enabled = "false",
    ingredients ={
	{type="item", name="copper-ore-pure", amount=10},
	{type="item", name="catalysator-brown", amount=1},
	},
    results=
    {
      {type="item", name="copper-ore", amount=10},
    },
    icon = "__angelsrefining__/graphics/icons/copper-ore-pure-sorting.png",
    order = "c-j-b[copper-ore-pure-processing]",
	},
}
)