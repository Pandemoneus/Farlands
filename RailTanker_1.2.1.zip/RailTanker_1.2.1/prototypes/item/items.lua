data:extend(
{
  	{
		type = "item",
		name = "rail-tanker",
		icon = "__RailTanker__/graphics/rail-tanker.png",
		flags = {"goes-to-quickbar"},
		subgroup = "transport",
		order = "a[train-system]-f[rail-tanker]-z",
		place_result = "rail-tanker",
		stack_size = 5
	},
})