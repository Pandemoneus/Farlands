if data.raw["pump"]["small-pump"] then
  data.raw["pump"]["small-pump"].collision_box = {{-0.29, -0.29}, {0.29, 0.29}}
end