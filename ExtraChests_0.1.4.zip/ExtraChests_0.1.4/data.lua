require "config"
require("prototypes.category")


--[[ Radars Check ]]--

if extra_radars then
	require("prototypes.radars")
end


--[[ Large Chests Check ]]----[[ Large Logistic Chests Check ]]--

if extra_chests_titanium_tungsten and data.raw.item["titanium-plate"] then

	require("prototypes.chests") 
	require("prototypes.logistic-chests") 
end


--[[ Express Smart Inserters ]]--

if extra_express_smart_inserters and data.raw.item["smart-long-inserter"] then
	require("prototypes.fast-smart-inserters")
end


--[[ New recipes ]]--

if extra_recipes then 
	require("prototypes.recipe-updates")
end


--[[ Fancy grafics for boilers ]]--

require("prototypes.boilers")


--[[ New recipes for voids ]]--

if extra_recipes and data.raw.item["void-pump"] then
	require("prototypes.void-recipe")
end






--[[  PLEASE LEAVE THIS OFF AS IT IS NOT WORKING

if change_techonology_tree then
	require("prototypes.technology-add")
end
]]--