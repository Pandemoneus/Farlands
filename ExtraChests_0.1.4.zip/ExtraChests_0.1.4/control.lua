require "defines"
require "config"