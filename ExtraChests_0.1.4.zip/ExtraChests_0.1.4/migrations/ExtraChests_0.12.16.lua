game.reload_script()

for index, force in pairs(game.forces) do
  force.reset_recipes()
  force.reset_technologies()

  if force.technologies["electrolysis-2"].researched then
    force.recipes["addon-sodium-hydroxide"].enabled = true
    force.recipes["addon-salt-water-electrolysis"].enabled = true
  end

  if force.technologies["lead-processing"].researched then
    force.recipes["addon-sulfur-dioxide"].enabled = true
  end

  if force.technologies["nickel-processing"].researched then
    force.recipes["addon-sulfur-nickel"].enabled = true
  end

  if force.technologies["chemical-processing-2"].researched then
    force.recipes["addon-calcium-chloride"].enabled = true
  end

  if force.technologies["lithium-processing"].researched then
    force.recipes["addon-lithium-water-electrolysis"].enabled = true
  end

  if force.technologies["void-fluid"].researched then
    if data.raw.fluid["petroleum-gas"] then force.recipes["void-petroleum-gas"].enabled = true end 
    if data.raw.fluid["hydrogen-chloride"] then force.recipes["void-hydrogen-chloride"].enabled = true end 
    if data.raw.fluid["crude-oil"] then force.recipes["void-crude-oil"].enabled = true end 
    if data.raw.fluid["ferric-chloride-solution"] then force.recipes["void-ferric-chloride-solution"].enabled = true end 
    if data.raw.fluid["heavy-oil"] then force.recipes["void-heavy-oil"].enabled = true end 
    if data.raw.fluid["light-oil"] then force.recipes["void-light-oil"].enabled = true end 
    if data.raw.fluid["liquid-fuel"] then force.recipes["void-liquid-fuel"].enabled = true end 
    if data.raw.fluid["lubricant"] then force.recipes["void-lubricant"].enabled = true end 
    if data.raw.fluid["water"] then force.recipes["void-water"].enabled = true end 
    if data.raw.fluid["nitric-acid"] then force.recipes["void-nitric-acid"].enabled = true end 
    if data.raw.fluid["nitrogen-dioxide"] then force.recipes["void-nitrogen-dioxide"].enabled = true end 
    if data.raw.fluid["sulfur-dioxide"] then force.recipes["void-sulfur-dioxide"].enabled = true end 
    if data.raw.fluid["sulfuric-acid"] then force.recipes["void-sulfuric-acid"].enabled = true end 
    if data.raw.fluid["tungstic-acid"] then force.recipes["void-tungstic-acid"].enabled = true end 
    if data.raw.fluid["sulfuric-nitric-acid"] then force.recipes["void-sulfuric-nitric-acid"].enabled = true end 
    if data.raw.fluid["glycerol"] then force.recipes["void-glycerol"].enabled = true end 
    if data.raw.fluid["nitroglycerin"] then force.recipes["void-nitroglycerin"].enabled = true end 
  end

end