if data.raw.player.player.build_distance <12 then data.raw.player.player.build_distance = 12 end
if data.raw.player.player.reach_distance < 10 then data.raw.player.player.reach_distance = 10 end
