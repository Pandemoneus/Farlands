addon_gray = {r=0.64, g=0.64, b=0.64}
addon_yellow = {r=0.64, g=0.65, b=0.02}
addon_red = {r=0.69, g=0.09, b=0.08}
addon_blue = {r=0.1, g=0.46, b=0.66}
addon_purple = {r=0.59, g=0.16, b=0.55}
addon_green = {r=1, g=0, b=0}


Config = {} -- DONT TOCUH THIS LINE!


--[[ Notice that if you don't load some of Bob's mod, some of my extras won't be available, if there isn't tungsten, no chests_tungesten and so on, if no smart_inserters, 
there won't be any express_samrt_inserters and so on, even if the option is set up to true]]--


extra_chests_titanium_tungsten = true
extra_express_smart_inserters = true
extra_void_recipies = true
extra_recipes = true
extra_radars = true


RadarMk2ScanDistance = 20 --Default=20
RadarMk3ScanDistance = 30 --Default=30
RadarMk4ScanDistance = 40 --Default=40
RadarMk5ScanDistance = 50 --Default=50


upgrade_tank_capacity = true        -- Bob's standard values if false

-- as long as the main option is true, icons will be changed too no matter if their option is true or false
-- if main option is false and _icons is true, then only icons in menus will be changed
-- For low resolution animation to be on is to have the main _graphics = true

drill_graphics = true				--[[For large-drills only low-res is available for the moment]]--
	drill_lowres = false 
	drill_area_lowres = true		--[[There is only lowres updated images, the others aren't really hi-res, I would leave this on all time]]--
	drill_tint = false
	drill_graphics_icons = true
	drill_newicons = true

steam_graphics = true
	steam_lowres = false
	steam_graphics_icons = true
		
accumlator_graphics = true
	accumlator_lowres = false
	accumlator_graphics_icons = true
	
pumpjack_graphics = true
	pumpjack_lowres = false
	pumpjack_tint = false
	pumpjack_graphics_icons = true
	
solar_graphics = true
	solar_graphics_icons = true

poles_graphics = true
	poles_graphics_icons = true

boiler_graphics = true
	boiler_graphics_icons = true
	
tank_graphics = true
	factorio_style = true
	

robots_graphics = true

	
assembling_graphics = true
robochest_graphics = true
radar_graphics = true
belts_graphics = true
chemicalplant_graphics = true
electroliser_graphics = true
electricfurnace_graphics = true
liquid_graphics = true

circuit_graphics = true
battery_graphics = true
warfare_graphics = true
equipment_graphics = true
labs_graphics = true
wall_graphics = true
inserters_graphics = true

menu_graphics = true
techonologies_graphics = true




-- DOES NOT WORK!!!! PLEASE DO NOT TURN ON, WILL CORRUPT SAVED GAMES
--change_techonology_tree = false	    -- Changes all recipies from base and bob's mod to join any tech that belong together together in one consecutive upgrade tech
				    -- all pumpjack tech will go from 1 to 5, instead of having the pumpjack base techonology on one side 
				    -- and then having from pumpjack techs 1 to 4 from bob's tech
