if data.raw.technology["titanium-processing"] then
  table.insert(data.raw.technology["titanium-processing"].effects,{type = "unlock-recipe", recipe = "titanium-chest"})
end

if data.raw.technology["tungsten-processing"] then
  table.insert(data.raw.technology["tungsten-processing"].effects,{type = "unlock-recipe", recipe = "tungsten-chest"})
end

if data.raw.technology["logistic-chests-bigger1"] then
  table.insert(data.raw.technology["logistic-chests-bigger1"].effects,{type = "unlock-recipe", recipe = "logistic-chest-titanium-storage"})
end


require("prototypes.inserter-recipe-updates")
require("prototypes.technology-updates")

--------------- ASSEMBLING MACHINES graphics -------------------

if assembling_graphics then

	data.raw["assembling-machine"]["assembling-machine-1"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-1.png"
	data.raw["assembling-machine"]["assembling-machine-2"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-2.png"
	data.raw["assembling-machine"]["assembling-machine-3"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-3.png"

	data.raw.item["assembling-machine-1"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-1.png"
	data.raw.item["assembling-machine-2"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-2.png"
	data.raw.item["assembling-machine-3"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-3.png"
	
	data.raw["assembling-machine"]["assembling-machine-2"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-2.png"

	data.raw["assembling-machine"]["assembling-machine-3"]["animation"] =
		{
		  filename = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-3.png",
		  priority = "high",
		  width = 142,
		  height = 113,
		  frame_count = 32,
		  line_length = 8,
		  shift = {0.84, -0.09},
		}

	
	if data.raw["assembling-machine"]["assembling-machine-4"] then
		data.raw["assembling-machine"]["assembling-machine-4"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-4.png"
		data.raw["assembling-machine"]["assembling-machine-5"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-5.png"
		data.raw["assembling-machine"]["assembling-machine-6"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-6.png"

		data.raw.item["assembling-machine-4"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-4.png"
		data.raw.item["assembling-machine-5"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-5.png"
		data.raw.item["assembling-machine-6"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/assembling-machine-6.png"

		data.raw["assembling-machine"]["assembling-machine-4"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-4.png"

		data.raw["assembling-machine"]["assembling-machine-5"]["fluid_boxes"][1]["pipe_picture"] = assembler2pipepictures()
		data.raw["assembling-machine"]["assembling-machine-5"]["fluid_boxes"][2]["pipe_picture"] = assembler2pipepictures()
		data.raw["assembling-machine"]["assembling-machine-5"]["animation"] = 
		    {
		      filename = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-5.png",
		      priority = "high",
		      width = 113,
		      height = 99,
		      frame_count = 32,
		      line_length = 8,
		      shift = {0.4, -0.06},
		    }

		data.raw["assembling-machine"]["assembling-machine-6"]["animation"] =
			{
			  filename =  "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-6.png",
			  priority = "high",
			  width = 142,
			  height = 113,
			  frame_count = 32,
			  line_length = 8,
			  shift = {0.84, -0.09},
			}
	end

	if data.raw["assembling-machine"]["electronics-machine-1"] then	
		data.raw["assembling-machine"]["electronics-machine-1"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/electronics-machine-1.png"
		data.raw["assembling-machine"]["electronics-machine-2"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/electronics-machine-2.png"
		data.raw["assembling-machine"]["electronics-machine-3"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/electronics-machine-3.png"

		data.raw.item["electronics-machine-1"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/electronics-machine-1.png"
		data.raw.item["electronics-machine-2"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/electronics-machine-2.png"
		data.raw.item["electronics-machine-3"].icon = "__ExtraChests__/graphics/entity/assembling-machines/icon/electronics-machine-3.png"

		data.raw["assembling-machine"]["electronics-machine-1"]["animation"] =
			{
			  filename = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-2.png",
			  priority = "high",
			  width = 113,
			  height = 99,
			  frame_count = 32,
			  line_length = 8,
			  shift = {0.4, -0.11},
			  scale = 0.66,
			}
		data.raw["assembling-machine"]["electronics-machine-2"]["animation"] =
			{
			  filename = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-4.png",
			  priority = "high",
			  width = 113,
			  height = 99,
			  frame_count = 32,
			  line_length = 8,
			  shift = {0.4, -0.08},
			  scale = 0.66,
			}
		data.raw["assembling-machine"]["electronics-machine-3"]["animation"] =
			{
			  filename = "__ExtraChests__/graphics/entity/assembling-machines/assembling-machine-6.png",
			  priority = "high",
			  width = 142,
			  height = 113,
			  frame_count = 32,
			  line_length = 8,
			  shift = {0.84, -0.15},
			  scale = 0.66,
			}
	end
	
end


-------- POLES graphics ---------------------
if poles_graphics_icons or poles_graphics then

	data.raw["electric-pole"]["medium-electric-pole"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole.png"
	data.raw["electric-pole"]["big-electric-pole"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole.png"
	data.raw["electric-pole"]["substation"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation.png"

	data.raw["item"]["medium-electric-pole"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole.png"
	data.raw["item"]["big-electric-pole"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole.png"
	data.raw["item"]["substation"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation.png"

	if data.raw["electric-pole"]["medium-electric-pole-2"] then
		data.raw["electric-pole"]["medium-electric-pole-2"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole-2.png"
		data.raw["electric-pole"]["medium-electric-pole-3"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole-3.png"
		data.raw["electric-pole"]["medium-electric-pole-4"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole-4.png"

		data.raw["electric-pole"]["big-electric-pole-2"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole-2.png"
		data.raw["electric-pole"]["big-electric-pole-3"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole-3.png"
		data.raw["electric-pole"]["big-electric-pole-4"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole-4.png"

		data.raw["electric-pole"]["substation-2"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation-2.png"
		data.raw["electric-pole"]["substation-3"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation-3.png"
		data.raw["electric-pole"]["substation-4"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation-4.png"


		data.raw["item"]["medium-electric-pole-2"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole-2.png"
		data.raw["item"]["medium-electric-pole-3"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole-3.png"
		data.raw["item"]["medium-electric-pole-4"].icon = "__ExtraChests__/graphics/entity/poles/icon/medium-electric-pole-4.png"

		data.raw["item"]["big-electric-pole-2"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole-2.png"
		data.raw["item"]["big-electric-pole-3"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole-3.png"
		data.raw["item"]["big-electric-pole-4"].icon = "__ExtraChests__/graphics/entity/poles/icon/big-electric-pole-4.png"

		data.raw["item"]["substation-2"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation-2.png"
		data.raw["item"]["substation-3"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation-3.png"
		data.raw["item"]["substation-4"].icon = "__ExtraChests__/graphics/entity/poles/icon/substation-4.png"
	end
end


if poles_graphics then
	data.raw["electric-pole"]["small-electric-pole"].fast_replaceable_group = "electric-pole-1x1"

	data.raw["electric-pole"]["medium-electric-pole"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/medium-electric-pole.png"
	data.raw["electric-pole"]["medium-electric-pole"].fast_replaceable_group = "electric-pole-1x1"

	data.raw["electric-pole"]["big-electric-pole"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/big-electric-pole.png"
	data.raw["electric-pole"]["big-electric-pole"].fast_replaceable_group = "electric-pole-2x2"

	data.raw["electric-pole"]["substation"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/substation.png"
	data.raw["electric-pole"]["substation"].fast_replaceable_group = "electric-pole-2x2"

	if data.raw["electric-pole"]["medium-electric-pole-2"] then
		data.raw["electric-pole"]["medium-electric-pole-2"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/medium-electric-pole-2.png"
		data.raw["electric-pole"]["medium-electric-pole-2"].fast_replaceable_group = "electric-pole-1x1"

		data.raw["electric-pole"]["medium-electric-pole-3"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/medium-electric-pole-3.png"
		data.raw["electric-pole"]["medium-electric-pole-3"].fast_replaceable_group = "electric-pole-1x1"

		data.raw["electric-pole"]["medium-electric-pole-4"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/medium-electric-pole-4.png"
		data.raw["electric-pole"]["medium-electric-pole-4"].fast_replaceable_group = "electric-pole-1x1"


		data.raw["electric-pole"]["big-electric-pole-2"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/big-electric-pole-2.png"
		data.raw["electric-pole"]["big-electric-pole-2"].fast_replaceable_group = "electric-pole-2x2"

		data.raw["electric-pole"]["big-electric-pole-3"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/big-electric-pole-3.png"
		data.raw["electric-pole"]["big-electric-pole-3"].fast_replaceable_group = "electric-pole-2x2"

		data.raw["electric-pole"]["big-electric-pole-4"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/big-electric-pole-4.png"
		data.raw["electric-pole"]["big-electric-pole-4"].fast_replaceable_group = "electric-pole-2x2"


		data.raw["electric-pole"]["substation-2"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/substation-2.png"
		data.raw["electric-pole"]["substation-2"].fast_replaceable_group = "electric-pole-2x2"

		data.raw["electric-pole"]["substation-3"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/substation-3.png"
		data.raw["electric-pole"]["substation-3"].fast_replaceable_group = "electric-pole-2x2"

		data.raw["electric-pole"]["substation-4"].pictures["filename"] = "__ExtraChests__/graphics/entity/poles/substation-4.png"
		data.raw["electric-pole"]["substation-4"].fast_replaceable_group = "electric-pole-2x2"
	end

end

-------- STORAGE TANK graphics ----------------------

if tank_graphics then

   if factorio_style then 
	data.raw["storage-tank"]["storage-tank"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-1-light.png"
	data.raw["storage-tank"]["storage-tank"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-1-light.png"
	data.raw["item"]["storage-tank"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-1-light.png"


	if data.raw["storage-tank"]["storage-tank-2"] then 
		data.raw["storage-tank"]["storage-tank-2"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-2-light.png"
		data.raw["storage-tank"]["storage-tank-3"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-3-light.png"
		data.raw["storage-tank"]["storage-tank-4"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-4-light.png"

		data.raw["storage-tank"]["storage-tank-2"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-2-light.png"
		data.raw["storage-tank"]["storage-tank-3"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-3-light.png"
		data.raw["storage-tank"]["storage-tank-4"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-4-light.png"

		data.raw["item"]["storage-tank-2"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-2-light.png"
		data.raw["item"]["storage-tank-3"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-3-light.png"
		data.raw["item"]["storage-tank-4"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-4-light.png"
	end
   else
	data.raw["storage-tank"]["storage-tank"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-1-full.png"
	data.raw["storage-tank"]["storage-tank"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-1-full.png"
	data.raw["item"]["storage-tank"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-1-full.png"

	if data.raw["storage-tank"]["storage-tank-2"] then 

		data.raw["storage-tank"]["storage-tank-2"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-2-full.png"

		data.raw["storage-tank"]["storage-tank-3"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-3-full.png"

		data.raw["storage-tank"]["storage-tank-4"]["pictures"]["picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/storage-tank/storage-tank-4-full.png"

		data.raw["storage-tank"]["storage-tank-2"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-2-full.png"
		data.raw["storage-tank"]["storage-tank-3"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-3-full.png"
		data.raw["storage-tank"]["storage-tank-4"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-4-full.png"

		data.raw["item"]["storage-tank-2"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-2-full.png"
		data.raw["item"]["storage-tank-3"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-3-full.png"
		data.raw["item"]["storage-tank-4"].icon = "__ExtraChests__/graphics/entity/storage-tank/icon/storage-tank-4-full.png"
	end
   end   	
	
end
------------ BOILERS graphics ---------------

if (boiler_graphics_icons or boiler_graphics) and data.raw["boiler"]["boiler-2"] then
	data.raw["boiler"]["boiler-2"].icon = "__ExtraChests__/graphics/entity/boilers/icon/boiler-2.png"
	data.raw["boiler"]["boiler-3"].icon = "__ExtraChests__/graphics/entity/boilers/icon/boiler-3.png"
	data.raw["boiler"]["boiler-4"].icon = "__ExtraChests__/graphics/entity/boilers/icon/boiler-4.png"

	data.raw["item"]["boiler-2"].icon = "__ExtraChests__/graphics/entity/boilers/icon/boiler-2.png"
	data.raw["item"]["boiler-3"].icon = "__ExtraChests__/graphics/entity/boilers/icon/boiler-3.png"
	data.raw["item"]["boiler-4"].icon = "__ExtraChests__/graphics/entity/boilers/icon/boiler-4.png"
	
end
if boiler_graphics and data.raw["boiler"]["boiler-2"] then
	data.raw["boiler"]["boiler-2"]["fire"] ={left=boilerfires2.down,down=boilerfires2.left,left_down=boilerfires2.right,right_down=boilerfires2.left,left_up=boilerfires2.down,right_up=boilerfires2.down,t_up=boilerfires2.down,}

	data.raw["boiler"]["boiler-3"]["fire"] ={left=boilerfires3.down,down=boilerfires3.left,left_down=boilerfires3.right,right_down=boilerfires3.left,left_up=boilerfires3.down,right_up=boilerfires3.down,t_up=boilerfires3.down,}

	data.raw["boiler"]["boiler-4"]["fire"] ={left=boilerfires4.down,down=boilerfires4.left,left_down=boilerfires4.right,right_down=boilerfires4.left,left_up=boilerfires4.down,right_up=boilerfires4.down,t_up=boilerfires4.down,}

end

---------- STEAM ENGINE graphics --------------------

if steam_graphics_icons or steam_graphics then
	data.raw["generator"]["steam-engine"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine-1-hd.png"
	data.raw["item"]["steam-engine"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine-1-hd.png"

	if data.raw["generator"]["steam-engine-2"] then 
		data.raw["generator"]["steam-engine-2"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine-2-hd.png"
		data.raw["generator"]["steam-engine-3"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine-3-hd.png"

		data.raw["item"]["steam-engine-2"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine-2-hd.png"
		data.raw["item"]["steam-engine-3"].icon = "__ExtraChests__/graphics/entity/steam-engines/icon/steam-engine-3-hd.png"
	end
end
if steam_graphics then

	if steam_lowres then
	
		data.raw["generator"]["steam-engine"]["horizontal_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines-lowres/steam-engine-horizontal.png"
		data.raw["generator"]["steam-engine"]["horizontal_animation"]["line_length"] =  2
		data.raw["generator"]["steam-engine"]["horizontal_animation"]["animation_speed"] = 0.25
		data.raw["generator"]["steam-engine"]["horizontal_animation"]["frame_count"] = 8
		data.raw["generator"]["steam-engine"]["vertical_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines-lowres/steam-engine-vertical.png"
		data.raw["generator"]["steam-engine"]["vertical_animation"]["line_length"] =  2						
		data.raw["generator"]["steam-engine"]["vertical_animation"]["animation_speed"] = 0.25
		data.raw["generator"]["steam-engine"]["vertical_animation"]["frame_count"] = 8
		
		if data.raw["generator"]["steam-engine-2"] then 
			data.raw["generator"]["steam-engine-2"]["horizontal_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines-lowres/steam-engine-horizontal-2.png"
			data.raw["generator"]["steam-engine-2"]["horizontal_animation"]["line_length"] =  2
			data.raw["generator"]["steam-engine-2"]["horizontal_animation"]["animation_speed"] = 0.25
			data.raw["generator"]["steam-engine-2"]["horizontal_animation"]["frame_count"] = 8
			data.raw["generator"]["steam-engine-2"]["vertical_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines-lowres/steam-engine-vertical-2.png"
			data.raw["generator"]["steam-engine-2"]["vertical_animation"]["line_length"] =  2
			data.raw["generator"]["steam-engine-2"]["vertical_animation"]["animation_speed"] = 0.25
			data.raw["generator"]["steam-engine-2"]["vertical_animation"]["frame_count"] = 8
		end	

		if data.raw["generator"]["steam-engine-3"] then 
			data.raw["generator"]["steam-engine-3"]["horizontal_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines-lowres/steam-engine-horizontal-3.png"
			data.raw["generator"]["steam-engine-3"]["horizontal_animation"]["line_length"] =  2
			data.raw["generator"]["steam-engine-3"]["horizontal_animation"]["animation_speed"] = 0.25
			data.raw["generator"]["steam-engine-3"]["horizontal_animation"]["frame_count"] = 8
			data.raw["generator"]["steam-engine-3"]["vertical_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines-lowres/steam-engine-vertical-3.png"
			data.raw["generator"]["steam-engine-3"]["vertical_animation"]["line_length"] =  2
			data.raw["generator"]["steam-engine-3"]["vertical_animation"]["animation_speed"] = 0.25
			data.raw["generator"]["steam-engine-3"]["vertical_animation"]["frame_count"] = 8
		end	
	else
		if data.raw["generator"]["steam-engine-2"] then 

			data.raw["generator"]["steam-engine-2"]["horizontal_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-horizontal-2.png"
			data.raw["generator"]["steam-engine-2"]["vertical_animation"]["filename"]   = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-vertical-2.png"
		end	

		if data.raw["generator"]["steam-engine-3"] then 

			data.raw["generator"]["steam-engine-3"]["horizontal_animation"]["filename"] = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-horizontal-3.png"
			data.raw["generator"]["steam-engine-3"]["vertical_animation"]["filename"]   = "__ExtraChests__/graphics/entity/steam-engines/steam-engine-vertical-3.png"

		end
	end 
end

---------- SOLAR PLANES graphics --------------------

if solar_graphics_icons or solar_graphics then

	if data.raw["solar-panel"]["solar-panel-small"] then  data.raw["solar-panel"]["solar-panel-small"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-s1.png"    end
	if data.raw["solar-panel"]["solar-panel-small-2"] then  data.raw["solar-panel"]["solar-panel-small-2"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-s2.png"  end
	if data.raw["solar-panel"]["solar-panel-small-3"] then  data.raw["solar-panel"]["solar-panel-small-3"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-s3.png"  end

	if data.raw["solar-panel"]["solar-panel"] then  data.raw["solar-panel"]["solar-panel"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-m1.png"	      end
	if data.raw["solar-panel"]["solar-panel-2"] then  data.raw["solar-panel"]["solar-panel-2"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-m2.png"	      end
	if data.raw["solar-panel"]["solar-panel-3"] then  data.raw["solar-panel"]["solar-panel-3"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-m3.png"	      end

	if data.raw["solar-panel"]["solar-panel-large"] then  data.raw["solar-panel"]["solar-panel-large"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-l1.png"    end
	if data.raw["solar-panel"]["solar-panel-large-3"] then  data.raw["solar-panel"]["solar-panel-large-3"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-l3.png"  end
	if data.raw["solar-panel"]["solar-panel-large-2"] then  data.raw["solar-panel"]["solar-panel-large-2"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-l2.png"  end

	if data.raw["item"]["solar-panel-small"] then  data.raw["item"]["solar-panel-small"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-s1.png"	      end
	if data.raw["item"]["solar-panel-small-2"] then  data.raw["item"]["solar-panel-small-2"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-s2.png"	      end
	if data.raw["item"]["solar-panel-small-3"] then  data.raw["item"]["solar-panel-small-3"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-s3.png"	      end

	if data.raw["item"]["solar-panel"] then  data.raw["item"]["solar-panel"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-m1.png"		      end
	if data.raw["item"]["solar-panel-2"] then  data.raw["item"]["solar-panel-2"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-m2.png"		      end
	if data.raw["item"]["solar-panel-3"] then  data.raw["item"]["solar-panel-3"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-m3.png"		      end

	if data.raw["item"]["solar-panel-large"] then  data.raw["item"]["solar-panel-large"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-l1.png"	      end
	if data.raw["item"]["solar-panel-large-2"] then  data.raw["item"]["solar-panel-large-2"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-l2.png"	      end
	if data.raw["item"]["solar-panel-large-3"] then  data.raw["item"]["solar-panel-large-3"].icon = "__ExtraChests__/graphics/entity/solar-panels/icon/solar-panel-l3.png"	      end


end
if solar_graphics then

	if data.raw["solar-panel"]["solar-panel-small"] then data.raw["solar-panel"]["solar-panel-small"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-s1.png"     end
	if data.raw["solar-panel"]["solar-panel-small-2"] then data.raw["solar-panel"]["solar-panel-small-2"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-s2.png"   end
	if data.raw["solar-panel"]["solar-panel-small-3"] then data.raw["solar-panel"]["solar-panel-small-3"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-s3.png"   end
 																	     
	if data.raw["solar-panel"]["solar-panel"] then data.raw["solar-panel"]["solar-panel"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-m1.png"	     end
	if data.raw["solar-panel"]["solar-panel-2"] then data.raw["solar-panel"]["solar-panel-2"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-m2.png"	     end
	if data.raw["solar-panel"]["solar-panel-3"] then data.raw["solar-panel"]["solar-panel-3"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-m3.png"	     end
 																	   
	if data.raw["solar-panel"]["solar-panel-large"] then data.raw["solar-panel"]["solar-panel-large"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-l1.png"     end
	if data.raw["solar-panel"]["solar-panel-large-2"] then data.raw["solar-panel"]["solar-panel-large-2"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-l2.png"   end
	if data.raw["solar-panel"]["solar-panel-large-3"] then data.raw["solar-panel"]["solar-panel-large-3"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/solar-panels/solar-panel-l3.png"   end

end

---------- ACCUMULATORS graphics --------------------

if (accumlator_graphics_icons or accumlator_graphics) and data.raw["accumulator"]["large-accumulator"] then
	data.raw["accumulator"]["large-accumulator"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk1h-icon.png"
	data.raw["accumulator"]["fast-accumulator"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk1f-icon.png"
	data.raw["accumulator"]["slow-accumulator"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk1s-icon.png"
	data.raw["accumulator"]["large-accumulator-2"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk2h-icon.png"
	data.raw["accumulator"]["fast-accumulator-2"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk2f-icon.png"
	data.raw["accumulator"]["slow-accumulator-2"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk2s-icon.png"
	data.raw["accumulator"]["large-accumulator-3"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk3h-icon.png"
	data.raw["accumulator"]["fast-accumulator-3"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk3f-icon.png"
	data.raw["accumulator"]["slow-accumulator-3"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk3s-icon.png"

	data.raw["item"]["large-accumulator"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk1h-icon.png"
	data.raw["item"]["fast-accumulator"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk1f-icon.png"
	data.raw["item"]["slow-accumulator"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk1s-icon.png"
	data.raw["item"]["large-accumulator-2"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk2h-icon.png"
	data.raw["item"]["fast-accumulator-2"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk2f-icon.png"
	data.raw["item"]["slow-accumulator-2"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk2s-icon.png"
	data.raw["item"]["large-accumulator-3"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk3h-icon.png"
	data.raw["item"]["fast-accumulator-3"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk3f-icon.png"
	data.raw["item"]["slow-accumulator-3"].icon = "__ExtraChests__/graphics/entity/accumulators/icon/accumulator-mk3s-icon.png"
end

if accumlator_graphics and data.raw["accumulator"]["large-accumulator"] then
	data.raw["accumulator"]["large-accumulator"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1h.png"
	data.raw["accumulator"]["fast-accumulator"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1f.png"
	data.raw["accumulator"]["slow-accumulator"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1s.png"
	data.raw["accumulator"]["large-accumulator-2"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2h.png"
	data.raw["accumulator"]["fast-accumulator-2"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2f.png"
	data.raw["accumulator"]["slow-accumulator-2"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2s.png"
	data.raw["accumulator"]["large-accumulator-3"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3h.png"
	data.raw["accumulator"]["fast-accumulator-3"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3f.png"
	data.raw["accumulator"]["slow-accumulator-3"]["picture"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3s.png"

	if accumlator_lowres then 										
		data.raw["accumulator"]["large-accumulator"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk1h-charge-animation.png"
		data.raw["accumulator"]["large-accumulator"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["large-accumulator"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["large-accumulator"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["large-accumulator"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk1h-discharge-animation.png"
		data.raw["accumulator"]["large-accumulator"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["large-accumulator"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["large-accumulator"]["discharge_animation"]["frame_count"] = 12
		
		data.raw["accumulator"]["fast-accumulator"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk1f-charge-animation.png"
		data.raw["accumulator"]["fast-accumulator"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["fast-accumulator"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["fast-accumulator"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["fast-accumulator"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk1f-discharge-animation.png"
		data.raw["accumulator"]["fast-accumulator"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["fast-accumulator"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["fast-accumulator"]["discharge_animation"]["frame_count"] = 12

		data.raw["accumulator"]["slow-accumulator"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk1s-charge-animation.png"
		data.raw["accumulator"]["slow-accumulator"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["slow-accumulator"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["slow-accumulator"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["slow-accumulator"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk1s-discharge-animation.png"
		data.raw["accumulator"]["slow-accumulator"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["slow-accumulator"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["slow-accumulator"]["discharge_animation"]["frame_count"] = 12


		data.raw["accumulator"]["large-accumulator-2"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk2h-charge-animation.png"
		data.raw["accumulator"]["large-accumulator-2"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["large-accumulator-2"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["large-accumulator-2"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["large-accumulator-2"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk2h-discharge-animation.png"
		data.raw["accumulator"]["large-accumulator-2"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["large-accumulator-2"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["large-accumulator-2"]["discharge_animation"]["frame_count"] = 12
		
		data.raw["accumulator"]["fast-accumulator-2"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk2f-charge-animation.png"
		data.raw["accumulator"]["fast-accumulator-2"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["fast-accumulator-2"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["fast-accumulator-2"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["fast-accumulator-2"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk2f-discharge-animation.png"
		data.raw["accumulator"]["fast-accumulator-2"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["fast-accumulator-2"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["fast-accumulator-2"]["discharge_animation"]["frame_count"] = 12
		
		data.raw["accumulator"]["slow-accumulator-2"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk2s-charge-animation.png"
		data.raw["accumulator"]["slow-accumulator-2"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["slow-accumulator-2"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["slow-accumulator-2"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["slow-accumulator-2"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk2s-discharge-animation.png"
		data.raw["accumulator"]["slow-accumulator-2"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["slow-accumulator-2"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["slow-accumulator-2"]["discharge_animation"]["frame_count"] = 12


		data.raw["accumulator"]["large-accumulator-3"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk3h-charge-animation.png"
		data.raw["accumulator"]["large-accumulator-3"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["large-accumulator-3"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["large-accumulator-3"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["large-accumulator-3"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk3h-discharge-animation.png"
		data.raw["accumulator"]["large-accumulator-3"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["large-accumulator-3"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["large-accumulator-3"]["discharge_animation"]["frame_count"] = 12
		
		data.raw["accumulator"]["fast-accumulator-3"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk3f-charge-animation.png"
		data.raw["accumulator"]["fast-accumulator-3"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["fast-accumulator-3"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["fast-accumulator-3"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["fast-accumulator-3"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk3f-discharge-animation.png"
		data.raw["accumulator"]["fast-accumulator-3"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["fast-accumulator-3"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["fast-accumulator-3"]["discharge_animation"]["frame_count"] = 12
		
		data.raw["accumulator"]["slow-accumulator-3"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk3s-charge-animation.png"
		data.raw["accumulator"]["slow-accumulator-3"]["charge_animation"]["line_length"] =  4
		data.raw["accumulator"]["slow-accumulator-3"]["charge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["slow-accumulator-3"]["charge_animation"]["frame_count"] = 12
		data.raw["accumulator"]["slow-accumulator-3"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators-lowres/accumulator-mk3s-discharge-animation.png"
		data.raw["accumulator"]["slow-accumulator-3"]["discharge_animation"]["line_length"] =  4
		data.raw["accumulator"]["slow-accumulator-3"]["discharge_animation"]["animation_speed"] = 0.25
		data.raw["accumulator"]["slow-accumulator-3"]["discharge_animation"]["frame_count"] = 12
		
	else
		data.raw["accumulator"]["large-accumulator"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1h-charge-animation.png"
		data.raw["accumulator"]["large-accumulator"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1h-discharge-animation.png"

		data.raw["accumulator"]["fast-accumulator"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1f-charge-animation.png"
		data.raw["accumulator"]["fast-accumulator"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1f-discharge-animation.png"

		data.raw["accumulator"]["slow-accumulator"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1s-charge-animation.png"
		data.raw["accumulator"]["slow-accumulator"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk1s-discharge-animation.png"


		data.raw["accumulator"]["large-accumulator-2"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2h-charge-animation.png"
		data.raw["accumulator"]["large-accumulator-2"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2h-discharge-animation.png"

		data.raw["accumulator"]["fast-accumulator-2"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2f-charge-animation.png"
		data.raw["accumulator"]["fast-accumulator-2"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2f-discharge-animation.png"

		data.raw["accumulator"]["slow-accumulator-2"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2s-charge-animation.png"
		data.raw["accumulator"]["slow-accumulator-2"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk2s-discharge-animation.png"


		data.raw["accumulator"]["large-accumulator-3"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3h-charge-animation.png"
		data.raw["accumulator"]["large-accumulator-3"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3h-discharge-animation.png"

		data.raw["accumulator"]["fast-accumulator-3"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3f-charge-animation.png"
		data.raw["accumulator"]["fast-accumulator-3"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3f-discharge-animation.png"

		data.raw["accumulator"]["slow-accumulator-3"]["charge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3s-charge-animation.png"
		data.raw["accumulator"]["slow-accumulator-3"]["discharge_animation"]["filename"] = "__ExtraChests__/graphics/entity/accumulators/accumulator-mk3s-discharge-animation.png"
	end
end

---------- ROBOCHESTS graphics --------------------

if robochest_graphics and data.raw["roboport"]["bob-robochest-2"] then

	if data.raw["roboport"]["bob-robochest"] then  data.raw["roboport"]["bob-robochest"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest.png"		       end
	if data.raw["roboport"]["bob-robochest-2"] then data.raw["roboport"]["bob-robochest-2"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest-2.png"		       end
	if data.raw["roboport"]["bob-robochest-3"] then data.raw["roboport"]["bob-robochest-3"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest-3.png"		       end
	if data.raw["roboport"]["bob-robochest-4"] then data.raw["roboport"]["bob-robochest-4"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest-4.png"		       end

	if data.raw["roboport"]["bob-robochest"] then  data.raw["roboport"]["bob-robochest"]["base"]["filename"] = "__ExtraChests__/graphics/entity/roboports/robochest.png"	       end
	if data.raw["roboport"]["bob-robochest-2"] then data.raw["roboport"]["bob-robochest-2"]["base"]["filename"] = "__ExtraChests__/graphics/entity/roboports/robochest-2.png"      end
	if data.raw["roboport"]["bob-robochest-3"] then data.raw["roboport"]["bob-robochest-3"]["base"]["filename"] = "__ExtraChests__/graphics/entity/roboports/robochest-3.png"      end
	if data.raw["roboport"]["bob-robochest-4"] then data.raw["roboport"]["bob-robochest-4"]["base"]["filename"] = "__ExtraChests__/graphics/entity/roboports/robochest-4.png"      end

	if data.raw["item"]["bob-robochest"] then  data.raw["item"]["bob-robochest"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest.png"			       end
	if data.raw["item"]["bob-robochest-2"]  then  data.raw["item"]["bob-robochest-2"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest-2.png"		       end
	if data.raw["item"]["bob-robochest-3"]  then  data.raw["item"]["bob-robochest-3"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest-3.png"		       end
	if data.raw["item"]["bob-robochest-4"]  then  data.raw["item"]["bob-robochest-4"].icon = "__ExtraChests__/graphics/entity/roboports/icon/robochest-4.png"		       end

end

---------- RADARS graphics -------------------

if radar_graphics then

	if radar_lowres then 
		if data.raw["radar"]["radar"] then  data.raw["radar"]["radar"].icon = "__ExtraChests__/graphics/entity/radars/icon/radar-1.png"    end
		if data.raw["radar"]["radar"] then  			
			data.raw["radar"]["radar"]["pictures"]["filename"] = "__ExtraChests__/graphics/entity/radars/radar-1.png" 
			data.raw["radar"]["radar"]["pictures"]["direction_count"] = 16
			data.raw["radar"]["radar"]["pictures"]["line_length"] = 8
		end
		if data.raw["radar"]["radar-mk2"] then  			
			data.raw["radar"]["radar-mk2"]["pictures"]["filename"] = "__ExtraChests__/graphics/entity/radars/radar-2.png" 
			data.raw["radar"]["radar-mk2"]["pictures"]["direction_count"] = 16
			data.raw["radar"]["radar-mk2"]["pictures"]["line_length"] = 8
		end
		if data.raw["radar"]["radar-mk3"] then  			
			data.raw["radar"]["radar-mk3"]["pictures"]["filename"] = "__ExtraChests__/graphics/entity/radars/radar-3.png" 
			data.raw["radar"]["radar-mk3"]["pictures"]["direction_count"] = 16
			data.raw["radar"]["radar-mk3"]["pictures"]["line_length"] = 8
		end
		if data.raw["radar"]["radar-mk4"] then  			
			data.raw["radar"]["radar-mk4"]["pictures"]["filename"] = "__ExtraChests__/graphics/entity/radars/radar-4.png" 
			data.raw["radar"]["radar-mk4"]["pictures"]["direction_count"] = 16
			data.raw["radar"]["radar-mk4"]["pictures"]["line_length"] = 8
		end
		if data.raw["radar"]["radar-mk5"] then  			
			data.raw["radar"]["radar-mk5"]["pictures"]["filename"] = "__ExtraChests__/graphics/entity/radars/radar-5.png" 
			data.raw["radar"]["radar-mk5"]["pictures"]["direction_count"] = 16
			data.raw["radar"]["radar-mk5"]["pictures"]["line_length"] = 8
		end

		if data.raw["item"]["radar"] then  data.raw["item"]["radar"].icon = "__ExtraChests__/graphics/entity/radars/icon/radar-1.png" end
	else
		if data.raw["radar"]["radar"] then  data.raw["radar"]["radar"].icon = "__ExtraChests__/graphics/entity/radars/icon/radar-1.png"    end
		if data.raw["radar"]["radar"] then  data.raw["radar"]["radar"]["pictures"]["filename"] = "__ExtraChests__/graphics/entity/radars/radar-1.png" end

		if data.raw["item"]["radar"] then  data.raw["item"]["radar"].icon = "__ExtraChests__/graphics/entity/radars/icon/radar-1.png" end
	end
end

---------- DRILLS graphics -------------------

if drill_graphics or drill_graphics_icons then

	if drill_newicons then
	
		data.raw["mining-drill"]["basic-mining-drill"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-0-new.png"
		data.raw["item"]["basic-mining-drill"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-0-new.png"
		
		if data.raw["mining-drill"]["bob-mining-drill-1"] then
			data.raw["mining-drill"]["bob-mining-drill-1"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-1-new.png"
			data.raw["mining-drill"]["bob-mining-drill-2"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-2-new.png"
			data.raw["mining-drill"]["bob-mining-drill-3"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-3-new.png"
			data.raw["mining-drill"]["bob-mining-drill-4"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-4-new.png"

			data.raw["item"]["bob-mining-drill-1"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-1-new.png"
			data.raw["item"]["bob-mining-drill-2"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-2-new.png"
			data.raw["item"]["bob-mining-drill-3"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-3-new.png"
			data.raw["item"]["bob-mining-drill-4"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-4-new.png"
		end
		if data.raw["mining-drill"]["bob-area-mining-drill-1"] then
			data.raw["mining-drill"]["bob-area-mining-drill-1"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-1-new.png"
			data.raw["mining-drill"]["bob-area-mining-drill-2"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-2-new.png"
			data.raw["mining-drill"]["bob-area-mining-drill-3"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-3-new.png"
			data.raw["mining-drill"]["bob-area-mining-drill-4"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-4-new.png"

			data.raw["item"]["bob-area-mining-drill-1"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-1-new.png"
			data.raw["item"]["bob-area-mining-drill-2"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-2-new.png"
			data.raw["item"]["bob-area-mining-drill-3"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-3-new.png"
			data.raw["item"]["bob-area-mining-drill-4"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-4-new.png"
		end
	else
		data.raw["mining-drill"]["basic-mining-drill"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-0.png"
		data.raw["item"]["basic-mining-drill"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-0.png"
		
		if data.raw["mining-drill"]["bob-mining-drill-1"] then
			data.raw["mining-drill"]["bob-mining-drill-1"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-1.png"
			data.raw["mining-drill"]["bob-mining-drill-2"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-2.png"
			data.raw["mining-drill"]["bob-mining-drill-3"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-3.png"
			data.raw["mining-drill"]["bob-mining-drill-4"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-4.png"

			data.raw["item"]["bob-mining-drill-1"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-1.png"
			data.raw["item"]["bob-mining-drill-2"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-2.png"
			data.raw["item"]["bob-mining-drill-3"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-3.png"
			data.raw["item"]["bob-mining-drill-4"].icon = "__ExtraChests__/graphics/entity/drills/icon/basic-mining-drill-4.png"
		end
		if data.raw["mining-drill"]["bob-area-mining-drill-1"] then
			data.raw["mining-drill"]["bob-area-mining-drill-1"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-1.png"
			data.raw["mining-drill"]["bob-area-mining-drill-2"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-2.png"
			data.raw["mining-drill"]["bob-area-mining-drill-3"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-3.png"
			data.raw["mining-drill"]["bob-area-mining-drill-4"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-4.png"

			data.raw["item"]["bob-area-mining-drill-1"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-1.png"
			data.raw["item"]["bob-area-mining-drill-2"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-2.png"
			data.raw["item"]["bob-area-mining-drill-3"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-3.png"
			data.raw["item"]["bob-area-mining-drill-4"].icon = "__ExtraChests__/graphics/entity/drills/icon/large-mining-drill-4.png"
		end
	end
end

if drill_graphics and data.raw["mining-drill"]["bob-area-mining-drill-1"] then

	if drill_lowres then

		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/north-0.png"
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/east-0.png"
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/south-0.png"
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/west-0.png"

		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/north-1.png"
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/east-1.png"
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/south-1.png"
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/west-1.png"

		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/north-2.png"
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/east-2.png"
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/south-2.png"
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/west-2.png"

		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/north-3.png"
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/east-3.png"
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/south-3.png"
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/west-3.png"

		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/north-4.png"
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/east-4.png"
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/south-4.png"
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/west-4.png"


		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["north"]["animation_speed"] = 0.18
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["north"]["frame_count"] = 16
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["north"]["shift"] = {0.2, -0.2}

		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["east"]["animation_speed"] = 0.18
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["east"]["frame_count"] = 16

		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["south"]["animation_speed"] = 0.18
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["south"]["frame_count"] = 16

		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["west"]["animation_speed"] = 0.18
		data.raw["mining-drill"]["basic-mining-drill"]["animations"]["west"]["frame_count"] = 16



		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["north"]["animation_speed"] = 0.25
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["north"]["frame_count"] = 16
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["north"]["shift"] = {0.2, -0.2}

		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["east"]["animation_speed"] = 0.25
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["east"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["south"]["animation_speed"] = 0.25
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["south"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["west"]["animation_speed"] = 0.25
		data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["west"]["frame_count"] = 16


		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["north"]["animation_speed"] = 0.5
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["north"]["frame_count"] = 16
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["north"]["shift"] = {0.2, -0.2}

		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["east"]["animation_speed"] = 0.5
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["east"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["south"]["animation_speed"] = 0.5
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["south"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["west"]["animation_speed"] = 0.5
		data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["west"]["frame_count"] = 16


		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["north"]["animation_speed"] = 0.75
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["north"]["frame_count"] = 16
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["north"]["shift"] = {0.2, -0.2}

		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["east"]["animation_speed"] = 0.75
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["east"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["south"]["animation_speed"] = 0.75
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["south"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["west"]["animation_speed"] = 0.75
		data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["west"]["frame_count"] = 16


		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["north"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["north"]["animation_speed"] = 1
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["north"]["frame_count"] = 16
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["north"]["shift"] = {0.2, -0.2}

		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["east"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["east"]["animation_speed"] = 1
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["east"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["south"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["south"]["animation_speed"] = 1
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["south"]["frame_count"] = 16

		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["west"]["line_length"] =  4
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["west"]["animation_speed"] = 1
		data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["west"]["frame_count"] = 16

	else
		if drill_tint then
	
			data.raw["mining-drill"]["basic-mining-drill"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/north-0.png"
			data.raw["mining-drill"]["basic-mining-drill"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/east-0.png"
			data.raw["mining-drill"]["basic-mining-drill"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/south-0.png"
			data.raw["mining-drill"]["basic-mining-drill"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/west-0.png"			


			data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["north"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 110,
						height = 114,
						line_length = 8,
						shift = {0.2, -0.2},
						filename = "__ExtraChests__/graphics/entity/drills/north-0.png",
						frame_count = 64,
						animation_speed = 1,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 110,
						height = 114,
						line_length = 8,
						shift = {0.2, -0.2},
						filename = "__ExtraChests__/graphics/entity/drills/north-tint.png",
						frame_count = 64,
						animation_speed = 1,
						run_mode = "forward-then-backward",
						tint = addon_yellow,
					      },
					} 
				}
			data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["east"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 129,
						height = 100,
						line_length = 8,
						shift = {0.45, 0},
						filename = "__ExtraChests__/graphics/entity/drills/east-0.png",
						frame_count = 64,
						animation_speed = 1,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 129,
						height = 100,
						line_length = 8,
						shift = {0.45, 0},
						filename = "__ExtraChests__/graphics/entity/drills/east-tint.png",
						frame_count = 64,
						animation_speed = 1,
						run_mode = "forward-then-backward",
						tint = addon_yellow,
					      },
					} 
				}
			data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["south"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 109,
						height = 111,
						line_length = 8,
						shift = {0.15, 0},
						filename = "__ExtraChests__/graphics/entity/drills/south-0.png",
						frame_count = 64,
						animation_speed = 1,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 109,
						height = 111,
						line_length = 8,
						shift = {0.15, 0},
						filename = "__ExtraChests__/graphics/entity/drills/south-tint.png",
						frame_count = 64,
						animation_speed = 1,
						run_mode = "forward-then-backward",
						tint = addon_yellow,
					      },
					} 
				}
			data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["west"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 128,
						height = 100,
						line_length = 8,
						shift = {0.25, 0},
						filename = "__ExtraChests__/graphics/entity/drills/west-0.png",
						frame_count = 64,
						animation_speed = 1,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 128,
						height = 100,
						line_length = 8,
						shift = {0.25, 0},
						filename = "__ExtraChests__/graphics/entity/drills/west-tint.png",
						frame_count = 64,
						animation_speed = 1,
						run_mode = "forward-then-backward",
						tint = addon_yellow,
					      },
					} 
				}




			data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["north"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 110,
						height = 114,
						line_length = 8,
						shift = {0.2, -0.2},
						filename = "__ExtraChests__/graphics/entity/drills/north-0.png",
						frame_count = 64,
						animation_speed = 2,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 110,
						height = 114,
						line_length = 8,
						shift = {0.2, -0.2},
						filename = "__ExtraChests__/graphics/entity/drills/north-tint.png",
						frame_count = 64,
						animation_speed = 2,
						run_mode = "forward-then-backward",
						tint = addon_red,
					      },
					} 
				}
			data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["east"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 129,
						height = 100,
						line_length = 8,
						shift = {0.45, 0},
						filename = "__ExtraChests__/graphics/entity/drills/east-0.png",
						frame_count = 64,
						animation_speed = 2,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 129,
						height = 100,
						line_length = 8,
						shift = {0.45, 0},
						filename = "__ExtraChests__/graphics/entity/drills/east-tint.png",
						frame_count = 64,
						animation_speed = 2,
						run_mode = "forward-then-backward",
						tint = addon_red,
					      },
					} 
				}
			data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["south"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 109,
						height = 111,
						line_length = 8,
						shift = {0.15, 0},
						filename = "__ExtraChests__/graphics/entity/drills/south-0.png",
						frame_count = 64,
						animation_speed = 2,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 109,
						height = 111,
						line_length = 8,
						shift = {0.15, 0},
						filename = "__ExtraChests__/graphics/entity/drills/south-tint.png",
						frame_count = 64,
						animation_speed = 2,
						run_mode = "forward-then-backward",
						tint = addon_red,
					      },
					} 
				}
			data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["west"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 128,
						height = 100,
						line_length = 8,
						shift = {0.25, 0},
						filename = "__ExtraChests__/graphics/entity/drills/west-0.png",
						frame_count = 64,
						animation_speed = 2,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 128,
						height = 100,
						line_length = 8,
						shift = {0.25, 0},
						filename = "__ExtraChests__/graphics/entity/drills/west-tint.png",
						frame_count = 64,
						animation_speed = 2,
						run_mode = "forward-then-backward",
						tint = addon_red,
					      },
					} 
				}



			data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["north"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 110,
						height = 114,
						line_length = 8,
						shift = {0.2, -0.2},
						filename = "__ExtraChests__/graphics/entity/drills/north-0.png",
						frame_count = 64,
						animation_speed = 3,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 110,
						height = 114,
						line_length = 8,
						shift = {0.2, -0.2},
						filename = "__ExtraChests__/graphics/entity/drills/north-tint.png",
						frame_count = 64,
						animation_speed = 3,
						run_mode = "forward-then-backward",
						tint = addon_blue,
					      },
					} 
				}
			data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["east"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 129,
						height = 100,
						line_length = 8,
						shift = {0.45, 0},
						filename = "__ExtraChests__/graphics/entity/drills/east-0.png",
						frame_count = 64,
						animation_speed = 3,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 129,
						height = 100,
						line_length = 8,
						shift = {0.45, 0},
						filename = "__ExtraChests__/graphics/entity/drills/east-tint.png",
						frame_count = 64,
						animation_speed = 3,
						run_mode = "forward-then-backward",
						tint = addon_blue,
					      },
					} 
				}
			data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["south"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 109,
						height = 111,
						line_length = 8,
						shift = {0.15, 0},
						filename = "__ExtraChests__/graphics/entity/drills/south-0.png",
						frame_count = 64,
						animation_speed = 3,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 109,
						height = 111,
						line_length = 8,
						shift = {0.15, 0},
						filename = "__ExtraChests__/graphics/entity/drills/south-tint.png",
						frame_count = 64,
						animation_speed = 3,
						run_mode = "forward-then-backward",
						tint = addon_blue,
					      },
					} 
				}
			data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["west"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 128,
						height = 100,
						line_length = 8,
						shift = {0.25, 0},
						filename = "__ExtraChests__/graphics/entity/drills/west-0.png",
						frame_count = 64,
						animation_speed = 3,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 128,
						height = 100,
						line_length = 8,
						shift = {0.25, 0},
						filename = "__ExtraChests__/graphics/entity/drills/west-tint.png",
						frame_count = 64,
						animation_speed = 3,
						run_mode = "forward-then-backward",
						tint = addon_blue,
					      },
					} 
				}


			data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["north"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 110,
						height = 114,
						line_length = 8,
						shift = {0.2, -0.2},
						filename = "__ExtraChests__/graphics/entity/drills/north-0.png",
						frame_count = 64,
						animation_speed = 4,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 110,
						height = 114,
						line_length = 8,
						shift = {0.2, -0.2},
						filename = "__ExtraChests__/graphics/entity/drills/north-tint.png",
						frame_count = 64,
						animation_speed = 4,
						run_mode = "forward-then-backward",
						tint = addon_purple,
					      },
					} 
				}
			data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["east"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 129,
						height = 100,
						line_length = 8,
						shift = {0.45, 0},
						filename = "__ExtraChests__/graphics/entity/drills/east-0.png",
						frame_count = 64,
						animation_speed = 4,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 129,
						height = 100,
						line_length = 8,
						shift = {0.45, 0},
						filename = "__ExtraChests__/graphics/entity/drills/east-tint.png",
						frame_count = 64,
						animation_speed = 4,
						run_mode = "forward-then-backward",
						tint = addon_purple,
					      },
					} 
				}
			data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["south"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 109,
						height = 111,
						line_length = 8,
						shift = {0.15, 0},
						filename = "__ExtraChests__/graphics/entity/drills/south-0.png",
						frame_count = 64,
						animation_speed = 4,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 109,
						height = 111,
						line_length = 8,
						shift = {0.15, 0},
						filename = "__ExtraChests__/graphics/entity/drills/south-tint.png",
						frame_count = 64,
						animation_speed = 4,
						run_mode = "forward-then-backward",
						tint = addon_purple,
					      },
					} 
				}
			data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["west"] = {
				layers = {
					      {
						priority = "extra-high",
						width = 128,
						height = 100,
						line_length = 8,
						shift = {0.25, 0},
						filename = "__ExtraChests__/graphics/entity/drills/west-0.png",
						frame_count = 64,
						animation_speed = 4,
						run_mode = "forward-then-backward",
					      },
					      {
						priority = "extra-high",
						width = 128,
						height = 100,
						line_length = 8,
						shift = {0.25, 0},
						filename = "__ExtraChests__/graphics/entity/drills/west-tint.png",
						frame_count = 64,
						animation_speed = 4,
						run_mode = "forward-then-backward",
						tint = addon_purple,
					      },
					} 
				}
		else
		
		
			data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/north-1.png"
			data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/east-1.png"
			data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/south-1.png"
			data.raw["mining-drill"]["bob-mining-drill-1"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/west-1.png"

			data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/north-2.png"
			data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/east-2.png"
			data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/south-2.png"
			data.raw["mining-drill"]["bob-mining-drill-2"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/west-2.png"

			data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/north-3.png"
			data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/east-3.png"
			data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/south-3.png"
			data.raw["mining-drill"]["bob-mining-drill-3"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/west-3.png"

			data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/north-4.png"
			data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/east-4.png"
			data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/south-4.png"
			data.raw["mining-drill"]["bob-mining-drill-4"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/west-4.png"
		
		end		
		
		
	end
	
      ------  LARGE DRILLS (only LOW RES AVAILABLE FOR NOW)

	if drill_tint then
	
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["north"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 110,
					height = 114,
					line_length = 4,
					shift = {0.2, -0.2},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-north-1.png",
					frame_count = 8,
					animation_speed = 0.2,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 110,
					height = 114,
					line_length = 4,
					shift = {0.2, -0.2},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-north-tint.png",
					frame_count = 8,
					animation_speed = 0.2,
					run_mode = "forward",
					tint = addon_yellow,
				      },
				} 
			}
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["east"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 129,
					height = 100,
					line_length = 4,
					shift = {0.45, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-east-1.png",
					frame_count = 8,
					animation_speed = 0.2,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 129,
					height = 100,
					line_length = 4,
					shift = {0.45, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-east-tint.png",
					frame_count = 8,
					animation_speed = 0.2,
					run_mode = "forward",
					tint = addon_yellow,
				      },
				} 
			}
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["south"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 109,
					height = 111,
					line_length = 4,
					shift = {0.15, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-south-1.png",
					frame_count = 8,
					animation_speed = 0.2,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 109,
					height = 111,
					line_length = 4,
					shift = {0.15, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-south-tint.png",
					frame_count = 8,
					animation_speed = 0.2,
					run_mode = "forward",
					tint = addon_yellow,
				      },
				} 
			}
		data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["west"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 128,
					height = 100,
					line_length = 4,
					shift = {0.25, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-west-1.png",
					frame_count = 8,
					animation_speed = 0.2,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 128,
					height = 100,
					line_length = 4,
					shift = {0.25, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-west-tint.png",
					frame_count = 8,
					animation_speed = 0.2,
					run_mode = "forward",
					tint = addon_yellow,
				      },
				} 
			}



		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["north"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 110,
					height = 114,
					line_length = 4 ,
					shift = {0.2, -0.2},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-north-1.png",
					frame_count = 8,
					animation_speed = 0.26,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 110,
					height = 114,
					line_length = 4 ,
					shift = {0.2, -0.2},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-north-tint.png",
					frame_count = 8,
					animation_speed = 0.26,
					run_mode = "forward",
					tint = addon_red,
				      },
				} 
			}
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["east"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 129,
					height = 100,
					line_length = 4 ,
					shift = {0.45, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-east-1.png",
					frame_count = 8,
					animation_speed = 0.26,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 129,
					height = 100,
					line_length = 4 ,
					shift = {0.45, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-east-tint.png",
					frame_count = 8,
					animation_speed = 0.26,
					run_mode = "forward",
					tint = addon_red,
				      },
				} 
			}
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["south"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 109,
					height = 111,
					line_length = 4 ,
					shift = {0.15, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-south-1.png",
					frame_count = 8,
					animation_speed = 0.26,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 109,
					height = 111,
					line_length = 4 ,
					shift = {0.15, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-south-tint.png",
					frame_count = 8,
					animation_speed = 0.26,
					run_mode = "forward",
					tint = addon_red,
				      },
				} 
			}
		data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["west"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 128,
					height = 100,
					line_length = 4 ,
					shift = {0.25, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-west-1.png",
					frame_count = 8,
					animation_speed = 0.26,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 128,
					height = 100,
					line_length = 4 ,
					shift = {0.25, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-west-tint.png",
					frame_count = 8,
					animation_speed = 0.26,
					run_mode = "forward",
					tint = addon_red,
				      },
				} 
			}



		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["north"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 110,
					height = 114,
					line_length = 4 ,
					shift = {0.2, -0.2},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-north-1.png",
					frame_count = 8,
					animation_speed = 0.32,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 110,
					height = 114,
					line_length = 4 ,
					shift = {0.2, -0.2},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-north-tint.png",
					frame_count = 8,
					animation_speed = 0.32,
					run_mode = "forward",
					tint = addon_blue,
				      },
				} 
			}
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["east"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 129,
					height = 100,
					line_length = 4 ,
					shift = {0.45, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-east-1.png",
					frame_count = 8,
					animation_speed = 0.32,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 129,
					height = 100,
					line_length = 4 ,
					shift = {0.45, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-east-tint.png",
					frame_count = 8,
					animation_speed = 0.32,
					run_mode = "forward",
					tint = addon_blue,
				      },
				} 
			}
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["south"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 109,
					height = 111,
					line_length = 4 ,
					shift = {0.15, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-south-1.png",
					frame_count = 8,
					animation_speed = 0.32,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 109,
					height = 111,
					line_length = 4 ,
					shift = {0.15, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-south-tint.png",
					frame_count = 8,
					animation_speed = 0.32,
					run_mode = "forward",
					tint = addon_blue,
				      },
				} 
			}
		data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["west"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 128,
					height = 100,
					line_length = 4 ,
					shift = {0.25, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-west-1.png",
					frame_count = 8,
					animation_speed = 0.32,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 128,
					height = 100,
					line_length = 4 ,
					shift = {0.25, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-west-tint.png",
					frame_count = 8,
					animation_speed = 0.32,
					run_mode = "forward",
					tint = addon_blue,
				      },
				} 
			}


		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["north"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 110,
					height = 114,
					line_length = 4 ,
					shift = {0.2, -0.2},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-north-1.png",
					frame_count = 8,
					animation_speed = 0.4,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 110,
					height = 114,
					line_length = 4 ,
					shift = {0.2, -0.2},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-north-tint.png",
					frame_count = 8,
					animation_speed = 0.4,
					run_mode = "forward",
					tint = addon_purple,
				      },
				} 
			}
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["east"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 129,
					height = 100,
					line_length = 4 ,
					shift = {0.45, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-east-1.png",
					frame_count = 8,
					animation_speed = 0.4,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 129,
					height = 100,
					line_length = 4 ,
					shift = {0.45, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-east-tint.png",
					frame_count = 8,
					animation_speed = 0.4,
					run_mode = "forward",
					tint = addon_purple,
				      },
				} 
			}
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["south"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 109,
					height = 111,
					line_length = 4 ,
					shift = {0.15, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-south-1.png",
					frame_count = 8,
					animation_speed = 0.4,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 109,
					height = 111,
					line_length = 4 ,
					shift = {0.15, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-south-tint.png",
					frame_count = 8,
					animation_speed = 0.4,
					run_mode = "forward",
					tint = addon_purple,
				      },
				} 
			}
		data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["west"] = {
			layers = {
				      {
					priority = "extra-high",
					width = 128,
					height = 100,
					line_length = 4 ,
					shift = {0.25, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-west-1.png",
					frame_count = 8,
					animation_speed = 0.4,
					run_mode = "forward",
				      },
				      {
					priority = "extra-high",
					width = 128,
					height = 100,
					line_length = 4 ,
					shift = {0.25, 0},
					filename = "__ExtraChests__/graphics/entity/drills-lowres/large-west-tint.png",
					frame_count = 8,
					animation_speed = 0.4,
					run_mode = "forward",
					tint = addon_purple,
				      },
				} 
			}
	else

		if drill_area_lowres then
		
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-north-1.png"
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-east-1.png"
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-south-1.png"
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-west-1.png"

			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-north-2.png"
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-east-2.png"
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-south-2.png"
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-west-2.png"

			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-north-3.png"
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-east-3.png"
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-south-3.png"
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-west-3.png"

			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-north-4.png"
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-east-4.png"
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-south-4.png"
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills-lowres/large-west-4.png"



			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["north"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["north"]["animation_speed"] = 0.2
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["north"]["frame_count"] = 8
--			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["north"]["shift"] = {0.2, -0.2}

			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["east"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["east"]["animation_speed"] = 0.2
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["east"]["frame_count"] = 8

			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["south"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["south"]["animation_speed"] = 0.2
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["south"]["frame_count"] = 8

			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["west"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["west"]["animation_speed"] = 0.2
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["west"]["frame_count"] = 8


			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["north"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["north"]["animation_speed"] = 0.26
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["north"]["frame_count"] = 8
--			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["north"]["shift"] = {0.2, -0.2}

			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["east"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["east"]["animation_speed"] = 0.26
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["east"]["frame_count"] = 8

			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["south"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["south"]["animation_speed"] = 0.26
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["south"]["frame_count"] = 8

			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["west"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["west"]["animation_speed"] = 0.26
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["west"]["frame_count"] = 8


			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["north"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["north"]["animation_speed"] = 0.32
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["north"]["frame_count"] = 8
--			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["north"]["shift"] = {0.2, -0.2}

			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["east"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["east"]["animation_speed"] = 0.32
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["east"]["frame_count"] = 8

			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["south"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["south"]["animation_speed"] = 0.32
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["south"]["frame_count"] = 8

			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["west"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["west"]["animation_speed"] = 0.32
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["west"]["frame_count"] = 8


			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["north"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["north"]["animation_speed"] = 0.4
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["north"]["frame_count"] = 8
--			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["north"]["shift"] = {0.2, -0.2}

			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["east"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["east"]["animation_speed"] = 0.4
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["east"]["frame_count"] = 8

			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["south"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["south"]["animation_speed"] = 0.4
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["south"]["frame_count"] = 8

			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["west"]["line_length"] =  4
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["west"]["animation_speed"] = 0.4
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["west"]["frame_count"] = 8

		else
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-north-1.png"
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-east-1.png"
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-south-1.png"
			data.raw["mining-drill"]["bob-area-mining-drill-1"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-west-1.png"

			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-north-2.png"
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-east-2.png"
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-south-2.png"
			data.raw["mining-drill"]["bob-area-mining-drill-2"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-west-2.png"

			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-north-3.png"
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-east-3.png"
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-south-3.png"
			data.raw["mining-drill"]["bob-area-mining-drill-3"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-west-3.png"

			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-north-4.png"
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["east"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-east-4.png"
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["south"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-south-4.png"
			data.raw["mining-drill"]["bob-area-mining-drill-4"]["animations"]["west"]["filename"] = "__ExtraChests__/graphics/entity/drills/large-west-4.png"
		end
	end

		
end



---------- PUMPJACKS graphics -------------------

if (pumpjack_graphics or pumpjack_graphics_icons) and data.raw.item["bob-pumpjack-1"] then

	data.raw["mining-drill"]["pumpjack"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack.png"
	data.raw["mining-drill"]["bob-pumpjack-1"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-1.png"
	data.raw["mining-drill"]["bob-pumpjack-2"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-2.png"
	data.raw["mining-drill"]["bob-pumpjack-3"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-3.png"
	data.raw["mining-drill"]["bob-pumpjack-4"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-4.png"

	data.raw["item"]["pumpjack"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack.png"
	data.raw["item"]["bob-pumpjack-1"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-1.png"
	data.raw["item"]["bob-pumpjack-2"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-2.png"
	data.raw["item"]["bob-pumpjack-3"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-3.png"
	data.raw["item"]["bob-pumpjack-4"].icon = "__ExtraChests__/graphics/entity/pumpjacks/icon/pumpjack-4.png"
end 

if pumpjack_graphics and data.raw.item["bob-pumpjack-1"] then
	if pumpjack_lowres then
	
		if pumpjack_tint then
			data.raw["mining-drill"]["pumpjack"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["pumpjack"]["animations"]["north"] = {
			      layers = {
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 2,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks-lowres/pumpjack-animation-4.png",
						frame_count = 8,
						animation_speed = 0.12
					   },
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 2,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks-lowres/pumpjack-animation-tint.png",
						frame_count = 8,
						animation_speed = 0.12,
						tint = addon_yellow,
					   },			   
			    }
			}

			data.raw["mining-drill"]["bob-pumpjack-1"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["bob-pumpjack-1"]["animations"]["north"] = {
			      layers = {
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 2,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks-lowres/pumpjack-animation-4.png",
						frame_count = 8,
						animation_speed = 0.25
					   },
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 2,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks-lowres/pumpjack-animation-tint.png",
						frame_count = 8,
						animation_speed = 0.25,
						tint = addon_red,
					   },			   
			    }
			}

			data.raw["mining-drill"]["bob-pumpjack-2"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["bob-pumpjack-2"]["animations"]["north"] = {
			      layers = {
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 2,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks-lowres/pumpjack-animation-4.png",
						frame_count = 8,
						animation_speed = 0.39
					   },
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 2,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks-lowres/pumpjack-animation-tint.png",
						frame_count = 8,
						animation_speed = 0.39,
						tint = addon_blue,
					   },			   
			    }
			}

			data.raw["mining-drill"]["bob-pumpjack-3"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["bob-pumpjack-3"]["animations"]["north"] = {
			      layers = {
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 2,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks-lowres/pumpjack-animation-4.png",
						frame_count = 8,
						animation_speed = 0.5
					   },
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 2,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks-lowres/pumpjack-animation-tint.png",
						frame_count = 8,
						animation_speed = 0.5,
						tint = addon_purple,
					   },			   
			    }
			}

		else
			data.raw["mining-drill"]["pumpjack"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["pumpjack"]["animations"]["north"] = {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 2,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks-lowres/pumpjack-animation-0.png",
						frame_count = 8,
						animation_speed = 0.12
			 }

			data.raw["mining-drill"]["bob-pumpjack-1"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["bob-pumpjack-1"]["animations"]["north"] = {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 2,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks-lowres/pumpjack-animation-1.png",
						frame_count = 8,
						animation_speed = 0.25
			 }

			data.raw["mining-drill"]["bob-pumpjack-2"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["bob-pumpjack-2"]["animations"]["north"] = {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 2,
						shift = {0.125, -0.71875},							
						filename = "__ExtraChests__/graphics/entity/pumpjacks-lowres/pumpjack-animation-2.png",
						frame_count = 8,
						animation_speed = 0.39
			 }

			data.raw["mining-drill"]["bob-pumpjack-3"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["bob-pumpjack-3"]["animations"]["north"] = {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 2,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks-lowres/pumpjack-animation-3.png",
						frame_count = 8,
						animation_speed = 0.5
			 }

		end			
		data.raw["mining-drill"]["bob-pumpjack-4"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
		data.raw["mining-drill"]["bob-pumpjack-4"]["animations"]["north"] = {
					priority = "extra-high",
					width = 116,
					height = 110,
					line_length = 2,
					shift = {0.125, -0.71875},
					filename = "__ExtraChests__/graphics/entity/pumpjacks-lowres/pumpjack-animation-4.png",
					frame_count = 8,
					animation_speed = 0.63
		 }
	
	else
		if pumpjack_tint then
			data.raw["mining-drill"]["pumpjack"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["pumpjack"]["animations"]["north"] = {
			      layers = {
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 10,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-4.png",
						frame_count = 40,
						animation_speed = 0.5
					   },
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 10,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-tint.png",
						frame_count = 40,
						animation_speed = 0.5,
						tint = addon_yellow,
					   },			   
			    }
			}

			data.raw["mining-drill"]["bob-pumpjack-1"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["bob-pumpjack-1"]["animations"]["north"] = {
			      layers = {
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 10,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-4.png",
						frame_count = 40,
						animation_speed = 1
					   },
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 10,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-tint.png",
						frame_count = 40,
						animation_speed = 1,
						tint = addon_red,
					   },			   
			    }
			}

			data.raw["mining-drill"]["bob-pumpjack-2"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["bob-pumpjack-2"]["animations"]["north"] = {
			      layers = {
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 10,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-4.png",
						frame_count = 40,
						animation_speed = 1.5
					   },
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 10,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-tint.png",
						frame_count = 40,
						animation_speed = 1.5,
						tint = addon_blue,
					   },			   
			    }
			}

			data.raw["mining-drill"]["bob-pumpjack-3"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["bob-pumpjack-3"]["animations"]["north"] = {
			      layers = {
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 10,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-4.png",
						frame_count = 40,
						animation_speed = 2
					   },
					   {
						priority = "extra-high",
						width = 116,
						height = 110,
						line_length = 10,
						shift = {0.125, -0.71875},
						filename = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-tint.png",
						frame_count = 40,
						animation_speed = 2,
						tint = addon_purple,
					   },			   
			    }
			}
			
			
		else
		
			data.raw["mining-drill"]["pumpjack"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["pumpjack"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation.png"

			data.raw["mining-drill"]["bob-pumpjack-1"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["bob-pumpjack-1"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-1.png"

			data.raw["mining-drill"]["bob-pumpjack-2"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["bob-pumpjack-2"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-2.png"

			data.raw["mining-drill"]["bob-pumpjack-3"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
			data.raw["mining-drill"]["bob-pumpjack-3"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-3.png"

		
		end

		data.raw["mining-drill"]["bob-pumpjack-4"]["base_picture"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-base.png"
		data.raw["mining-drill"]["bob-pumpjack-4"]["animations"]["north"]["filename"] = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-4.png"

	--      	data.raw["mining-drill"]["bob-pumpjack-4"]["animations"]["north"] = {
	--      	      layers = {
	--      			   {
	--      				priority = "extra-high",
	--      				width = 116,
	--      				height = 110,
	--      				line_length = 10,
	--      				shift = {0.125, -0.71875},
	--      				filename = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-4.png",
	--      				frame_count = 40,
	--      				animation_speed = 2.5
	--      			   },
	--      			   {
	--      				priority = "extra-high",
	--      				width = 116,
	--      				height = 110,
	--      				line_length = 10,
	--      				shift = {0.125, -0.71875},
	--      				filename = "__ExtraChests__/graphics/entity/pumpjacks/pumpjack-animation-tint.png",
	--      				frame_count = 40,
	--      				animation_speed = 2.5,
	--      				tint = addon_green,
	--      			   },			   
	--      	    }
	--       }


	end

end

--------------- TRANSPORT-BELTS graphics -------------------


if belts_graphics and data.raw["transport-belt"]["purple-transport-belt"] then

	data.raw["transport-belt"]["green-transport-belt"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/purple-transport-belt.png"
	data.raw["transport-belt"]["green-transport-belt"]["animations"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-transport-belt.png"
	data.raw["transport-belt"]["green-transport-belt"].belt_horizontal = purple_belt_horizontal
	data.raw["transport-belt"]["green-transport-belt"].belt_vertical = purple_belt_vertical
	data.raw["transport-belt"]["green-transport-belt"].ending_top = purple_belt_ending_top
	data.raw["transport-belt"]["green-transport-belt"].ending_bottom = purple_belt_ending_bottom
	data.raw["transport-belt"]["green-transport-belt"].ending_side = purple_belt_ending_side
	data.raw["transport-belt"]["green-transport-belt"].starting_top = purple_belt_starting_top
	data.raw["transport-belt"]["green-transport-belt"].starting_bottom = purple_belt_starting_bottom
	data.raw["transport-belt"]["green-transport-belt"].starting_side = purple_belt_starting_side



	data.raw["transport-belt"]["purple-transport-belt"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/green-transport-belt.png"
	data.raw["transport-belt"]["purple-transport-belt"]["animations"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-transport-belt.png"
	data.raw["transport-belt"]["purple-transport-belt"].belt_horizontal = green_belt_horizontal
	data.raw["transport-belt"]["purple-transport-belt"].belt_vertical = green_belt_vertical
	data.raw["transport-belt"]["purple-transport-belt"].ending_top = green_belt_ending_top
	data.raw["transport-belt"]["purple-transport-belt"].ending_bottom = green_belt_ending_bottom
	data.raw["transport-belt"]["purple-transport-belt"].ending_side = green_belt_ending_side
	data.raw["transport-belt"]["purple-transport-belt"].starting_top = green_belt_starting_top
	data.raw["transport-belt"]["purple-transport-belt"].starting_bottom = green_belt_starting_bottom
	data.raw["transport-belt"]["purple-transport-belt"].starting_side = green_belt_starting_side


	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/purple-transport-belt-to-ground.png"
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].belt_horizontal = purple_belt_horizontal
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].belt_vertical = purple_belt_vertical
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].ending_top = purple_belt_ending_top
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].ending_bottom = purple_belt_ending_bottom
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].ending_side = purple_belt_ending_side
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].starting_top = purple_belt_starting_top
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].starting_bottom = purple_belt_starting_bottom
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"].starting_side = purple_belt_starting_side
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"]["structure"]["direction_in"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-transport-belt-to-ground-structure.png"
	data.raw["transport-belt-to-ground"]["green-transport-belt-to-ground"]["structure"]["direction_out"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-transport-belt-to-ground-structure.png"



	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/green-transport-belt-to-ground.png"
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].belt_horizontal = green_belt_horizontal
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].belt_vertical = green_belt_vertical
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].ending_top = green_belt_ending_top
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].ending_bottom = green_belt_ending_bottom
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].ending_side = green_belt_ending_side
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].starting_top = green_belt_starting_top
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].starting_bottom = green_belt_starting_bottom
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"].starting_side = green_belt_starting_side
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"]["structure"]["direction_in"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-transport-belt-to-ground-structure.png"
	data.raw["transport-belt-to-ground"]["purple-transport-belt-to-ground"]["structure"]["direction_out"]["sheet"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-transport-belt-to-ground-structure.png"


	data.raw["splitter"]["green-splitter"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/purple-splitter.png"
	data.raw["splitter"]["green-splitter"].belt_horizontal = purple_belt_horizontal
	data.raw["splitter"]["green-splitter"].belt_vertical = purple_belt_vertical
	data.raw["splitter"]["green-splitter"].ending_top = purple_belt_ending_top
	data.raw["splitter"]["green-splitter"].ending_bottom = purple_belt_ending_bottom
	data.raw["splitter"]["green-splitter"].ending_side = purple_belt_ending_side
	data.raw["splitter"]["green-splitter"].starting_top = purple_belt_starting_top
	data.raw["splitter"]["green-splitter"].starting_bottom = purple_belt_starting_bottom
	data.raw["splitter"]["green-splitter"].starting_side = purple_belt_starting_side
	data.raw["splitter"]["green-splitter"]["structure"]["north"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-splitter-north.png"
	data.raw["splitter"]["green-splitter"]["structure"]["east"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-splitter-east.png"
	data.raw["splitter"]["green-splitter"]["structure"]["south"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-splitter-south.png"
	data.raw["splitter"]["green-splitter"]["structure"]["west"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/purple-splitter-west.png"

	data.raw["splitter"]["purple-splitter"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/green-splitter.png"
	data.raw["splitter"]["purple-splitter"].belt_horizontal = green_belt_horizontal
	data.raw["splitter"]["purple-splitter"].belt_vertical = green_belt_vertical
	data.raw["splitter"]["purple-splitter"].ending_top = green_belt_ending_top
	data.raw["splitter"]["purple-splitter"].ending_bottom = green_belt_ending_bottom
	data.raw["splitter"]["purple-splitter"].ending_side = green_belt_ending_side
	data.raw["splitter"]["purple-splitter"].starting_top = green_belt_starting_top
	data.raw["splitter"]["purple-splitter"].starting_bottom = green_belt_starting_bottom
	data.raw["splitter"]["purple-splitter"].starting_side = green_belt_starting_side
	data.raw["splitter"]["purple-splitter"]["structure"]["north"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-splitter-north.png"
	data.raw["splitter"]["purple-splitter"]["structure"]["east"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-splitter-east.png"
	data.raw["splitter"]["purple-splitter"]["structure"]["south"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-splitter-south.png"
	data.raw["splitter"]["purple-splitter"]["structure"]["west"]["filename"] = "__ExtraChests__/graphics/entity/transport-belts/green-splitter-west.png"



	data.raw.item["green-transport-belt"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/purple-transport-belt.png"
	data.raw.item["purple-transport-belt"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/green-transport-belt.png"

	data.raw.item["green-transport-belt-to-ground"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/purple-transport-belt-to-ground.png"
	data.raw.item["purple-transport-belt-to-ground"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/green-transport-belt-to-ground.png"

	data.raw.item["green-splitter"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/purple-splitter.png"
	data.raw.item["purple-splitter"].icon = "__ExtraChests__/graphics/entity/transport-belts/icon/green-splitter.png"
end

--------------- CHEMICAL PLANTS graphics -------------------

if chemicalplant_graphics and data.raw["assembling-machine"]["chemical-plant-2"] then

	data.raw["assembling-machine"]["chemical-plant"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant.png"
	data.raw["assembling-machine"]["chemical-plant-2"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant-2.png"
	data.raw["assembling-machine"]["chemical-plant-3"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant-3.png"
	data.raw["assembling-machine"]["chemical-plant-4"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant-4.png"


	--data.raw["assembling-machine"]["chemical-plant"]["animation"] = bob_chemical_plant_animation({r = 0.5, g = 0.1, b = 0.7})
	data.raw["assembling-machine"]["chemical-plant-2"]["animation"] = bob_chemical_plant_animation({r = 0.7, g = 0.2, b = 0.1})
	data.raw["assembling-machine"]["chemical-plant-3"]["animation"] = bob_chemical_plant_animation({r = 0.2, g = 0.0, b = 0.7})
	data.raw["assembling-machine"]["chemical-plant-4"]["animation"] = bob_chemical_plant_animation({r = 0.5, g = 0.1, b = 0.7})

	data.raw["item"]["chemical-plant"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant.png"
	data.raw["item"]["chemical-plant-2"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant-2.png"
	data.raw["item"]["chemical-plant-3"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant-3.png"
	data.raw["item"]["chemical-plant-4"].icon = "__ExtraChests__/graphics/entity/chemical-plants/icon/chemical-plant-4.png"

end


--------------- ELECTROLISERS graphics -------------------

if electroliser_graphics and data.raw["assembling-machine"]["electrolyser-2"] then

	data.raw["assembling-machine"]["electrolyser"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser.png"
	data.raw["assembling-machine"]["electrolyser-2"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser-2.png"
	data.raw["assembling-machine"]["electrolyser-3"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser-3.png"
	data.raw["assembling-machine"]["electrolyser-4"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser-4.png"

	data.raw["assembling-machine"]["electrolyser"]["animation"]["north"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt1u.png"
	data.raw["assembling-machine"]["electrolyser"]["animation"]["west"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t1l.png"
	data.raw["assembling-machine"]["electrolyser"]["animation"]["south"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt1d.png"
	data.raw["assembling-machine"]["electrolyser"]["animation"]["east"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t1r.png"

	data.raw["assembling-machine"]["electrolyser-2"]["animation"]["north"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt2u.png"
	data.raw["assembling-machine"]["electrolyser-2"]["animation"]["west"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t2l.png"
	data.raw["assembling-machine"]["electrolyser-2"]["animation"]["south"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt2d.png"
	data.raw["assembling-machine"]["electrolyser-2"]["animation"]["east"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t2r.png"

	data.raw["assembling-machine"]["electrolyser-3"]["animation"]["north"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt3u.png"
	data.raw["assembling-machine"]["electrolyser-3"]["animation"]["west"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t3l.png"
	data.raw["assembling-machine"]["electrolyser-3"]["animation"]["south"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt3d.png"
	data.raw["assembling-machine"]["electrolyser-3"]["animation"]["east"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t3r.png"

	data.raw["assembling-machine"]["electrolyser-4"]["animation"]["north"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt4u.png"
	data.raw["assembling-machine"]["electrolyser-4"]["animation"]["west"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t4l.png"
	data.raw["assembling-machine"]["electrolyser-4"]["animation"]["south"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-vt4d.png"
	data.raw["assembling-machine"]["electrolyser-4"]["animation"]["east"]["filename"] = "__ExtraChests__/graphics/entity/electrolysers/electro-h-t4r.png"


	data.raw["item"]["electrolyser"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser.png"
	data.raw["item"]["electrolyser-2"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser-2.png"
	data.raw["item"]["electrolyser-3"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser-3.png"
	data.raw["item"]["electrolyser-4"].icon = "__ExtraChests__/graphics/entity/electrolysers/icon/electrolyser-4.png"

end


--------------- ELECTRIC FURNACE graphics -------------------

if electricfurnace_graphics then
								     
	if data.raw["furnace"]["steel-furnace"] then data.raw["furnace"]["steel-furnace"].icon = "__ExtraChests__/graphics/entity/steel-furnace/icon/steel-furnace.png" end 
	if data.raw["furnace"]["electric-furnace"] then data.raw["furnace"]["electric-furnace"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/yellow-electric-furnace.png" end 
	if data.raw["furnace"]["electric-furnace"] then data.raw["furnace"]["electric-furnace"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/electric-furnaces/yellow-electric-furnace.png" end 
	 

	if data.raw["assembling-machine"]["electric-mixing-furnace"] then data.raw["assembling-machine"]["electric-mixing-furnace"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/blue-electric-furnace.png" end 
	if data.raw["assembling-machine"]["electric-mixing-furnace"] then data.raw["assembling-machine"]["electric-mixing-furnace"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/electric-furnaces/blue-electric-furnace.png" end 
	 
	if data.raw["assembling-machine"]["chemical-furnace"] then data.raw["assembling-machine"]["chemical-furnace"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/red-electric-furnace.png" end 
	if data.raw["assembling-machine"]["chemical-furnace"] then data.raw["assembling-machine"]["chemical-furnace"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/electric-furnaces/red-electric-furnace.png" end 
	 
	if data.raw["assembling-machine"]["electric-chemical-mixing-furnace"] then data.raw["assembling-machine"]["electric-chemical-mixing-furnace"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/purple-electric-furnace.png" end 
	if data.raw["assembling-machine"]["electric-chemical-mixing-furnace"] then data.raw["assembling-machine"]["electric-chemical-mixing-furnace"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/electric-furnaces/purple-electric-furnace.png" end 
	 
	if data.raw["assembling-machine"]["electric-chemical-mixing-furnace-2"] then data.raw["assembling-machine"]["electric-chemical-mixing-furnace-2"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/green-electric-furnace.png" end 
	if data.raw["assembling-machine"]["electric-chemical-mixing-furnace-2"] then data.raw["assembling-machine"]["electric-chemical-mixing-furnace-2"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/electric-furnaces/green-electric-furnace.png" end 



	if data.raw["item"]["steel-furnace"] then data.raw["item"]["steel-furnace"].icon = "__ExtraChests__/graphics/entity/steel-furnace/icon/steel-furnace.png" end 
	if data.raw["item"]["electric-furnace"] then data.raw["item"]["electric-furnace"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/yellow-electric-furnace.png" end 
	if data.raw["item"]["electric-mixing-furnace"] then data.raw["item"]["electric-mixing-furnace"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/blue-electric-furnace.png" end 
	if data.raw["item"]["chemical-furnace"] then data.raw["item"]["chemical-furnace"].icon ="__ExtraChests__/graphics/entity/electric-furnaces/icon/red-electric-furnace.png" end 
	if data.raw["item"]["electric-chemical-mixing-furnace"] then data.raw["item"]["electric-chemical-mixing-furnace"].icon =  "__ExtraChests__/graphics/entity/electric-furnaces/icon/purple-electric-furnace.png" end 
	if data.raw["item"]["electric-chemical-mixing-furnace-2"] then data.raw["item"]["electric-chemical-mixing-furnace-2"].icon = "__ExtraChests__/graphics/entity/electric-furnaces/icon/green-electric-furnace.png" end 
end


--------------- LIQUIDS graphics -------------------

if liquid_graphics  then

	if data.raw.recipe["basic-oil-processing"]  then data.raw.recipe["basic-oil-processing"].icon = "__ExtraChests__/graphics/icons/fluids/basic-oil-processing.png" end
	if data.raw.recipe["advanced-oil-processing"]  then data.raw.recipe["advanced-oil-processing"].icon = "__ExtraChests__/graphics/icons/fluids/advanced-oil-processing.png" end
	if data.raw.recipe["bob-oil-processing"]  then data.raw.recipe["bob-oil-processing"].icon = "__ExtraChests__/graphics/icons/fluids/bob-oil-processing.png" end


	if data.raw.recipe["salt-water-electrolysis"]  then data.raw.recipe["salt-water-electrolysis"].icon = "__ExtraChests__/graphics/icons/fluids/salt-water-electrolysis.png" end
	if data.raw.recipe["lithium-water-electrolysis"]  then data.raw.recipe["lithium-water-electrolysis"].icon = "__ExtraChests__/graphics/icons/fluids/lithium-water-electrolysis.png" end
	if data.raw.recipe["tungstic-acid"]  then data.raw.recipe["tungstic-acid"].icon = "__ExtraChests__/graphics/icons/fluids/tungstic-acid-recipe.png" end

	if data.raw.recipe["nitrogen"]  then data.raw.recipe["nitrogen"].icon = "__ExtraChests__/graphics/icons/fluids/nitrogen-recipe.png" end

	if data.raw.recipe["lead-oxide"]  then data.raw.recipe["lead-oxide"].icon = "__ExtraChests__/graphics/icons/fluids/sulfur-lead-oxide-recipe.png" end

	if data.raw.recipe["bob-nickel-plate"]  then data.raw.recipe["bob-nickel-plate"].icon = "__ExtraChests__/graphics/icons/fluids/nickel-sulfur-recipe.png" end


	if data.raw.recipe["liquid-fuel-canister"]  then data.raw.item["liquid-fuel-canister"].icon = "__ExtraChests__/graphics/icons/fluids/liquid-fuel-canister.png" end
	if data.raw.recipe["ferric-chloride-canister"]  then data.raw.item["ferric-chloride-canister"].icon = "__ExtraChests__/graphics/icons/fluids/ferric-chloride-canister.png" end


end

--------------- BOBS MATERIALS graphics -------------------

--------------- BOBS ROBOTS graphics -------------------


if robots_graphics then

	if data.raw["construction-robot"]["construction-robot"] then  data.raw["construction-robot"]["construction-robot"].icon = "__ExtraChests__/graphics/entity/robots/icon/construction-robot.png" 		   end
	if data.raw["construction-robot"]["bob-construction-robot-2"] then  data.raw["construction-robot"]["bob-construction-robot-2"].icon = "__ExtraChests__/graphics/entity/robots/icon/construction-robot-2.png" 	   end 
	if data.raw["construction-robot"]["bob-construction-robot-3"] then  data.raw["construction-robot"]["bob-construction-robot-3"].icon = "__ExtraChests__/graphics/entity/robots/icon/construction-robot-3.png" 	   end
	if data.raw["construction-robot"]["bob-construction-robot-4"] then  data.raw["construction-robot"]["bob-construction-robot-4"].icon = "__ExtraChests__/graphics/entity/robots/icon/construction-robot-4.png" 	   end
													 
	if data.raw["logistic-robot"]["logistic-robot"] then  data.raw["logistic-robot"]["logistic-robot"].icon = "__ExtraChests__/graphics/entity/robots/icon/logistic-robot.png" 		     end
	if data.raw["logistic-robot"]["bob-logistic-robot-2"] then  data.raw["logistic-robot"]["bob-logistic-robot-2"].icon = "__ExtraChests__/graphics/entity/robots/icon/logistic-robot-2.png"    end
	if data.raw["logistic-robot"]["bob-logistic-robot-3"] then  data.raw["logistic-robot"]["bob-logistic-robot-3"].icon = "__ExtraChests__/graphics/entity/robots/icon/logistic-robot-3.png"    end
	if data.raw["logistic-robot"]["bob-logistic-robot-4"] then  data.raw["logistic-robot"]["bob-logistic-robot-4"].icon = "__ExtraChests__/graphics/entity/robots/icon/logistic-robot-4.png"    end


	if data.raw.item["construction-robot"] then  data.raw.item["construction-robot"].icon = "__ExtraChests__/graphics/entity/robots/icon/construction-robot.png" 		     end
	if data.raw.item["bob-construction-robot-2"] then  data.raw.item["bob-construction-robot-2"].icon = "__ExtraChests__/graphics/entity/robots/icon/construction-robot-2.png"  end
	if data.raw.item["bob-construction-robot-3"] then  data.raw.item["bob-construction-robot-3"].icon = "__ExtraChests__/graphics/entity/robots/icon/construction-robot-3.png"  end
	if data.raw.item["bob-construction-robot-4"] then  data.raw.item["bob-construction-robot-4"].icon = "__ExtraChests__/graphics/entity/robots/icon/construction-robot-4.png"  end
													 
	if data.raw.item["logistic-robot"] then  data.raw.item["logistic-robot"].icon = "__ExtraChests__/graphics/entity/robots/icon/logistic-robot.png" 		 end
	if data.raw.item["bob-logistic-robot-2"] then  data.raw.item["bob-logistic-robot-2"].icon = "__ExtraChests__/graphics/entity/robots/icon/logistic-robot-2.png"  end
	if data.raw.item["bob-logistic-robot-3"] then  data.raw.item["bob-logistic-robot-3"].icon = "__ExtraChests__/graphics/entity/robots/icon/logistic-robot-3.png"  end
	if data.raw.item["bob-logistic-robot-4"] then  data.raw.item["bob-logistic-robot-4"].icon = "__ExtraChests__/graphics/entity/robots/icon/logistic-robot-4.png"  end

 
	if data.raw["logistic-robot"]["bob-logistic-robot-2"] then
	
		data.raw["logistic-robot"]["bob-logistic-robot-2"]["idle"] = {filename = "__ExtraChests__/graphics/entity/robots/logistic-robot-2.png", priority = "high", line_length = 16, width = 41, height = 42, frame_count = 1, shift = {0.015625, -0.09375}, direction_count = 16, y = 42    }
		data.raw["logistic-robot"]["bob-logistic-robot-3"]["idle"] = {filename = "__ExtraChests__/graphics/entity/robots/logistic-robot-3.png", priority = "high", line_length = 16, width = 41, height = 42, frame_count = 1, shift = {0.015625, -0.09375}, direction_count = 16, y = 42    }
		data.raw["logistic-robot"]["bob-logistic-robot-4"]["idle"] = {filename = "__ExtraChests__/graphics/entity/robots/logistic-robot-4.png", priority = "high", line_length = 16, width = 41, height = 42, frame_count = 1, shift = {0.015625, -0.09375}, direction_count = 16, y = 42    }
		
		data.raw["logistic-robot"]["bob-logistic-robot-2"]["idle_with_cargo"] = { filename="__ExtraChests__/graphics/entity/robots/logistic-robot-2.png", priority="high", line_length=16, width=41, height=42, frame_count=1, shift={0.015625,-0.09375}, direction_count=16 }
		data.raw["logistic-robot"]["bob-logistic-robot-3"]["idle_with_cargo"] = { filename="__ExtraChests__/graphics/entity/robots/logistic-robot-3.png", priority="high", line_length=16, width=41, height=42, frame_count=1, shift={0.015625,-0.09375}, direction_count=16 }
		data.raw["logistic-robot"]["bob-logistic-robot-4"]["idle_with_cargo"] = { filename="__ExtraChests__/graphics/entity/robots/logistic-robot-4.png", priority="high", line_length=16, width=41, height=42, frame_count=1, shift={0.015625,-0.09375}, direction_count=16 }
		
		data.raw["logistic-robot"]["bob-logistic-robot-2"]["in_motion"] = { filename="__ExtraChests__/graphics/entity/robots/logistic-robot-2.png", priority="high", line_length=16, width=41, height=42, frame_count=1, shift={0.015625,-0.09375}, direction_count=16, y=126 }
		data.raw["logistic-robot"]["bob-logistic-robot-3"]["in_motion"] = { filename="__ExtraChests__/graphics/entity/robots/logistic-robot-3.png", priority="high", line_length=16, width=41, height=42, frame_count=1, shift={0.015625,-0.09375}, direction_count=16, y=126 }
		data.raw["logistic-robot"]["bob-logistic-robot-4"]["in_motion"] = { filename="__ExtraChests__/graphics/entity/robots/logistic-robot-4.png", priority="high", line_length=16, width=41, height=42, frame_count=1, shift={0.015625,-0.09375}, direction_count=16, y=126 }
		
		data.raw["logistic-robot"]["bob-logistic-robot-2"]["in_motion_with_cargo"] = { filename="__ExtraChests__/graphics/entity/robots/logistic-robot-2.png", priority="high", line_length=16, width=41, height=42, frame_count=1, shift={0.015625,-0.09375}, direction_count=16, y=84 }
		data.raw["logistic-robot"]["bob-logistic-robot-3"]["in_motion_with_cargo"] = { filename="__ExtraChests__/graphics/entity/robots/logistic-robot-3.png", priority="high", line_length=16, width=41, height=42, frame_count=1, shift={0.015625,-0.09375}, direction_count=16, y=84 }
		data.raw["logistic-robot"]["bob-logistic-robot-4"]["in_motion_with_cargo"] = { filename="__ExtraChests__/graphics/entity/robots/logistic-robot-4.png", priority="high", line_length=16, width=41, height=42, frame_count=1, shift={0.015625,-0.09375}, direction_count=16, y=84 }
		
		data.raw["logistic-robot"]["bob-logistic-robot-2"]["shadow_idle"] = data.raw["logistic-robot"]["logistic-robot"]["shadow_idle"]
		data.raw["logistic-robot"]["bob-logistic-robot-3"]["shadow_idle"] = data.raw["logistic-robot"]["logistic-robot"]["shadow_idle"]
		data.raw["logistic-robot"]["bob-logistic-robot-4"]["shadow_idle"] = data.raw["logistic-robot"]["logistic-robot"]["shadow_idle"]
		
		data.raw["logistic-robot"]["bob-logistic-robot-2"]["shadow_idle_with_cargo"] = data.raw["logistic-robot"]["logistic-robot"]["shadow_idle_with_cargo"]
		data.raw["logistic-robot"]["bob-logistic-robot-3"]["shadow_idle_with_cargo"] = data.raw["logistic-robot"]["logistic-robot"]["shadow_idle_with_cargo"]
		data.raw["logistic-robot"]["bob-logistic-robot-4"]["shadow_idle_with_cargo"] = data.raw["logistic-robot"]["logistic-robot"]["shadow_idle_with_cargo"]
		
		data.raw["logistic-robot"]["bob-logistic-robot-2"]["shadow_in_motion"] = data.raw["logistic-robot"]["logistic-robot"]["shadow_in_motion"]
		data.raw["logistic-robot"]["bob-logistic-robot-3"]["shadow_in_motion"] = data.raw["logistic-robot"]["logistic-robot"]["shadow_in_motion"]
		data.raw["logistic-robot"]["bob-logistic-robot-4"]["shadow_in_motion"] = data.raw["logistic-robot"]["logistic-robot"]["shadow_in_motion"]
		
		data.raw["logistic-robot"]["bob-logistic-robot-2"]["shadow_in_motion_with_cargo"] = data.raw["logistic-robot"]["logistic-robot"]["shadow_in_motion_with_cargo"]
		data.raw["logistic-robot"]["bob-logistic-robot-3"]["shadow_in_motion_with_cargo"] = data.raw["logistic-robot"]["logistic-robot"]["shadow_in_motion_with_cargo"]
		data.raw["logistic-robot"]["bob-logistic-robot-4"]["shadow_in_motion_with_cargo"] = data.raw["logistic-robot"]["logistic-robot"]["shadow_in_motion_with_cargo"]

	end

	if data.raw["construction-robot"]["bob-construction-robot-2"] then
	
		data.raw["construction-robot"]["bob-construction-robot-2"]["idle"] = { filename="__ExtraChests__/graphics/entity/robots/construction-robot-2.png", priority="high", line_length=16, width=32, height=36, frame_count=1, shift={0,-0.15625}, direction_count=16 }
		data.raw["construction-robot"]["bob-construction-robot-3"]["idle"] = { filename="__ExtraChests__/graphics/entity/robots/construction-robot-3.png", priority="high", line_length=16, width=32, height=36, frame_count=1, shift={0,-0.15625}, direction_count=16 }
		data.raw["construction-robot"]["bob-construction-robot-4"]["idle"] = { filename="__ExtraChests__/graphics/entity/robots/construction-robot-4.png", priority="high", line_length=16, width=32, height=36, frame_count=1, shift={0,-0.15625}, direction_count=16 }
		
		data.raw["construction-robot"]["bob-construction-robot-2"]["in_motion"] = { filename="__ExtraChests__/graphics/entity/robots/construction-robot-2.png", priority="high", line_length=16, width=32, height=36, frame_count=1, shift={0,-0.15625}, direction_count=16, y=36 }
		data.raw["construction-robot"]["bob-construction-robot-3"]["in_motion"] = { filename="__ExtraChests__/graphics/entity/robots/construction-robot-3.png", priority="high", line_length=16, width=32, height=36, frame_count=1, shift={0,-0.15625}, direction_count=16, y=36 }
		data.raw["construction-robot"]["bob-construction-robot-4"]["in_motion"] = { filename="__ExtraChests__/graphics/entity/robots/construction-robot-4.png", priority="high", line_length=16, width=32, height=36, frame_count=1, shift={0,-0.15625}, direction_count=16, y=36 }
		
		data.raw["construction-robot"]["bob-construction-robot-2"]["working"] = { filename="__ExtraChests__/graphics/entity/robots/construction-robot-working-2.png", priority="high", line_length=2, width=28, height=36, frame_count=2, shift={0,-0.15625}, direction_count=16, animation_speed=0.3, }
		data.raw["construction-robot"]["bob-construction-robot-3"]["working"] = { filename="__ExtraChests__/graphics/entity/robots/construction-robot-working-3.png", priority="high", line_length=2, width=28, height=36, frame_count=2, shift={0,-0.15625}, direction_count=16, animation_speed=0.3, }
		data.raw["construction-robot"]["bob-construction-robot-4"]["working"] = { filename="__ExtraChests__/graphics/entity/robots/construction-robot-working-4.png", priority="high", line_length=2, width=28, height=36, frame_count=2, shift={0,-0.15625}, direction_count=16, animation_speed=0.3, }
		
		data.raw["construction-robot"]["bob-construction-robot-2"]["shadow"] = data.raw["construction-robot"]["construction-robot"]["shadow"]
		data.raw["construction-robot"]["bob-construction-robot-3"]["shadow"] = data.raw["construction-robot"]["construction-robot"]["shadow"]
		data.raw["construction-robot"]["bob-construction-robot-4"]["shadow"] = data.raw["construction-robot"]["construction-robot"]["shadow"]
		
		data.raw["construction-robot"]["bob-construction-robot-2"]["shadow_idle"] = data.raw["construction-robot"]["construction-robot"]["shadow_idle"]
		data.raw["construction-robot"]["bob-construction-robot-3"]["shadow_idle"] = data.raw["construction-robot"]["construction-robot"]["shadow_idle"]
		data.raw["construction-robot"]["bob-construction-robot-4"]["shadow_idle"] = data.raw["construction-robot"]["construction-robot"]["shadow_idle"]
		
		data.raw["construction-robot"]["bob-construction-robot-2"]["shadow_in_motion"] = data.raw["construction-robot"]["construction-robot"]["shadow_in_motion"]
		data.raw["construction-robot"]["bob-construction-robot-3"]["shadow_in_motion"] = data.raw["construction-robot"]["construction-robot"]["shadow_in_motion"]
		data.raw["construction-robot"]["bob-construction-robot-4"]["shadow_in_motion"] = data.raw["construction-robot"]["construction-robot"]["shadow_in_motion"]
		
		data.raw["construction-robot"]["bob-construction-robot-2"]["shadow_working"] = data.raw["construction-robot"]["construction-robot"]["shadow_working"]
		data.raw["construction-robot"]["bob-construction-robot-3"]["shadow_working"] = data.raw["construction-robot"]["construction-robot"]["shadow_working"]
		data.raw["construction-robot"]["bob-construction-robot-4"]["shadow_working"] = data.raw["construction-robot"]["construction-robot"]["shadow_working"]

	end

end

--------------- CIRCUITS graphics -------------------

if circuit_graphics then

	if data.raw.item["wooden-board"]  then data.raw.item["wooden-board"].icon = "__ExtraChests__/graphics/icons/circuits/wooden-board.png" end 
	if data.raw.item["phenolic-board"]  then data.raw.item["phenolic-board"].icon = "__ExtraChests__/graphics/icons/circuits/phenolic-board.png" end 
	if data.raw.item["fibreglass-board"]  then data.raw.item["fibreglass-board"].icon = "__ExtraChests__/graphics/icons/circuits/fibreglass-board.png" end 
	if data.raw.item["basic-circuit-board"]  then data.raw.item["basic-circuit-board"].icon = "__ExtraChests__/graphics/icons/circuits/basic-circuit-board.png" end 
	if data.raw.item["circuit-board"]  then data.raw.item["circuit-board"].icon = "__ExtraChests__/graphics/icons/circuits/circuit-board.png" end 

	if data.raw.item["superior-circuit-board"]  then data.raw.item["superior-circuit-board"].icon = "__ExtraChests__/graphics/icons/circuits/superior-circuit-board.png" end 
	if data.raw.item["multi-layer-circuit-board"]  then data.raw.item["multi-layer-circuit-board"].icon = "__ExtraChests__/graphics/icons/circuits/multi-layer-circuit-board.png" end 
	if data.raw.item["electronic-circuit"]  then data.raw.item["electronic-circuit"].icon = "__ExtraChests__/graphics/icons/circuits/basic-electronic-circuit-board.png" end 
	if data.raw.item["advanced-circuit"]  then data.raw.item["advanced-circuit"].icon = "__ExtraChests__/graphics/icons/circuits/electronic-circuit-board.png" end 
	if data.raw.item["processing-unit"]  then data.raw.item["processing-unit"].icon = "__ExtraChests__/graphics/icons/circuits/electronic-logic-board.png" end 

	if data.raw.item["advanced-processing-unit"]  then data.raw.item["advanced-processing-unit"].icon = "__ExtraChests__/graphics/icons/circuits/electronic-processing-board.png" end 

end

if battery_graphics then

	if data.raw.item["battery"]  then data.raw.item["battery"].icon = "__ExtraChests__/graphics/icons/intermediates/battery.png" end
	if data.raw.item["lithium-ion-battery"]  then data.raw.item["lithium-ion-battery"].icon = "__ExtraChests__/graphics/icons/intermediates/lithium-ion-battery.png" end
	if data.raw.item["silver-zinc-battery"]  then data.raw.item["silver-zinc-battery"].icon = "__ExtraChests__/graphics/icons/intermediates/silver-zinc-battery.png" end
end


------------------ INSERTERS GRAPHICS ----------------

if inserters_graphics then

	if data.raw.inserter["burner-inserter"] then data.raw.inserter["burner-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/burner-inserter.png" end 
	if data.raw.inserter["long-handed-burner-inserter"] then data.raw.inserter["long-handed-burner-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/long-handed-burner-inserter.png" end 
	if data.raw.inserter["basic-inserter"] then data.raw.inserter["basic-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/basic-inserter.png" end 
	if data.raw.inserter["long-handed-inserter"] then data.raw.inserter["long-handed-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/long-handed-inserter.png" end 

	if data.raw.inserter["fast-inserter"] then data.raw.inserter["fast-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/fast/fast-inserter.png" end 
	if data.raw.inserter["fast-long-inserter"] then data.raw.inserter["fast-long-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/fast/fast-long-inserter.png" end 
	if data.raw.inserter["fast-near-inserter"] then data.raw.inserter["fast-near-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/fast/fast-near-inserter.png" end 
	if data.raw.inserter["fast-far-inserter"] then data.raw.inserter["fast-far-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/fast/fast-far-inserter.png" end 

	if data.raw.inserter["smart-far-inserter"] then data.raw.inserter["smart-far-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-far-inserter.png" end 
	if data.raw.inserter["smart-inserter"] then data.raw.inserter["smart-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-inserter.png" end 
	if data.raw.inserter["smart-long-inserter"] then data.raw.inserter["smart-long-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-long-inserter.png" end 
	if data.raw.inserter["smart-long-near-inserter"] then data.raw.inserter["smart-long-near-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-long-near-inserter.png" end 
	if data.raw.inserter["smart-long-short-inserter"] then data.raw.inserter["smart-long-short-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-long-short-inserter.png" end 
	if data.raw.inserter["smart-near-inserter"] then data.raw.inserter["smart-near-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-near-inserter.png" end 
	if data.raw.inserter["smart-short-far-inserter"] then data.raw.inserter["smart-short-far-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-short-far-inserter.png" end 
	if data.raw.inserter["smart-short-long-inserter"] then data.raw.inserter["smart-short-long-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-short-long-inserter.png" end 

	if data.raw.inserter["purple-far-inserter"] then data.raw.inserter["purple-far-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-far-inserter.png" end 
	if data.raw.inserter["purple-inserter"] then data.raw.inserter["purple-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-inserter.png" end 
	if data.raw.inserter["purple-long-inserter"] then data.raw.inserter["purple-long-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-long-inserter.png" end 
	if data.raw.inserter["purple-long-near-inserter"] then data.raw.inserter["purple-long-near-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-long-near-inserter.png" end 
	if data.raw.inserter["purple-long-short-inserter"] then data.raw.inserter["purple-long-short-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-long-short-inserter.png" end 
	if data.raw.inserter["purple-near-inserter"] then data.raw.inserter["purple-near-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-near-inserter.png" end 
	if data.raw.inserter["purple-short-far-inserter"] then data.raw.inserter["purple-short-far-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-short-far-inserter.png" end 
	if data.raw.inserter["purple-short-long-inserter"] then data.raw.inserter["purple-short-long-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-short-long-inserter.png" end 


	if data.raw.item["burner-inserter"] then data.raw.item["burner-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/burner-inserter.png" end 
	if data.raw.item["long-handed-burner-inserter"] then data.raw.item["long-handed-burner-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/long-handed-burner-inserter.png" end 
	if data.raw.item["basic-inserter"] then data.raw.item["basic-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/basic-inserter.png" end 
	if data.raw.item["long-handed-inserter"] then data.raw.item["long-handed-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/long-handed-inserter.png" end 

	if data.raw.item["fast-inserter"] then data.raw.item["fast-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/fast/fast-inserter.png" end 
	if data.raw.item["fast-long-inserter"] then data.raw.item["fast-long-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/fast/fast-long-inserter.png" end 
	if data.raw.item["fast-near-inserter"] then data.raw.item["fast-near-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/fast/fast-near-inserter.png" end 
	if data.raw.item["fast-far-inserter"] then data.raw.item["fast-far-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/fast/fast-far-inserter.png" end 

	if data.raw.item["smart-far-inserter"] then data.raw.item["smart-far-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-far-inserter.png" end 
	if data.raw.item["smart-inserter"] then data.raw.item["smart-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-inserter.png" end 
	if data.raw.item["smart-long-inserter"] then data.raw.item["smart-long-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-long-inserter.png" end 
	if data.raw.item["smart-long-near-inserter"] then data.raw.item["smart-long-near-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-long-near-inserter.png" end 
	if data.raw.item["smart-long-short-inserter"] then data.raw.item["smart-long-short-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-long-short-inserter.png" end 
	if data.raw.item["smart-near-inserter"] then data.raw.item["smart-near-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-near-inserter.png" end 
	if data.raw.item["smart-short-far-inserter"] then data.raw.item["smart-short-far-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-short-far-inserter.png" end 
	if data.raw.item["smart-short-long-inserter"] then data.raw.item["smart-short-long-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/smart/smart-short-long-inserter.png" end 

	if data.raw.item["purple-far-inserter"] then data.raw.item["purple-far-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-far-inserter.png" end 
	if data.raw.item["purple-inserter"] then data.raw.item["purple-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-inserter.png" end 
	if data.raw.item["purple-long-inserter"] then data.raw.item["purple-long-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-long-inserter.png" end 
	if data.raw.item["purple-long-near-inserter"] then data.raw.item["purple-long-near-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-long-near-inserter.png" end 
	if data.raw.item["purple-long-short-inserter"] then data.raw.item["purple-long-short-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-long-short-inserter.png" end 
	if data.raw.item["purple-near-inserter"] then data.raw.item["purple-near-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-near-inserter.png" end 
	if data.raw.item["purple-short-far-inserter"] then data.raw.item["purple-short-far-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-short-far-inserter.png" end 
	if data.raw.item["purple-short-long-inserter"] then data.raw.item["purple-short-long-inserter"].icon = "__ExtraChests__/graphics/entity/inserter/icons/express/purple-short-long-inserter.png" end 


	if data.raw.inserter["fast-near-inserter"] then data.raw.inserter["fast-near-inserter"]["hand_base_picture"].filename = "__ExtraChests__/graphics/entity/inserter/fast-inserter-hand-base.png" end
	if data.raw.inserter["fast-far-inserter"] then data.raw.inserter["fast-far-inserter"]["hand_base_picture"].filename = "__ExtraChests__/graphics/entity/inserter/long-handed-inserter-hand-base.png" end

	if data.raw.inserter["smart-near-inserter"] then data.raw.inserter["smart-near-inserter"]["hand_base_picture"].filename	= "__ExtraChests__/graphics/entity/inserter/smart-inserter-hand-base.png" end
	if data.raw.inserter["smart-far-inserter"] then data.raw.inserter["smart-far-inserter"]["hand_base_picture"].filename = "__ExtraChests__/graphics/entity/inserter/long-handed-inserter-hand-base.png" end

	if data.raw.inserter["purple-near-inserter"] then data.raw.inserter["purple-near-inserter"]["hand_base_picture"].filename = "__ExtraChests__/graphics/entity/inserter/purple-inserter-hand-base.png" end
	if data.raw.inserter["purple-far-inserter"] then data.raw.inserter["purple-far-inserter"]["hand_base_picture"].filename	= "__ExtraChests__/graphics/entity/inserter/long-handed-inserter-hand-base.png" end

end

if data.raw.inserter["purple-long-inserter"] then data.raw.inserter["purple-long-inserter"].fast_replaceable_group = "inserter"	  end
if data.raw.inserter["smart-long-inserter"] then data.raw.inserter["smart-long-inserter"].fast_replaceable_group = "inserter"	  end
if data.raw.inserter["fast-long-inserter"] then data.raw.inserter["fast-long-inserter"].fast_replaceable_group = "inserter"	  end
if data.raw.inserter["long-handed-burner-inster"] then data.raw.inserter["long-handed-burner-inserter"].fast_replaceable_group = "inserter" end


------------------ OTHER GRAPHICS ----------------

if battery_graphics then

	if data.raw.item["battery"]  then data.raw.item["battery"].icon = "__ExtraChests__/graphics/icons/intermediates/battery.png" end
	if data.raw.item["lithium-ion-battery"]  then data.raw.item["lithium-ion-battery"].icon = "__ExtraChests__/graphics/icons/intermediates/lithium-ion-battery.png" end
	if data.raw.item["silver-zinc-battery"]  then data.raw.item["silver-zinc-battery"].icon = "__ExtraChests__/graphics/icons/intermediates/silver-zinc-battery.png" end
end

if wall_graphics then
	if data.raw.wall["reinforced-wall"]  then data.raw.wall["reinforced-wall"].icon = "__ExtraChests__/graphics/icons/warfare/reinforced-wall.png" end
	if data.raw.gate["reinforced-gate"]  then data.raw.gate["reinforced-gate"].icon = "__ExtraChests__/graphics/icons/warfare/reinforced-gate.png" end
	if data.raw.item["reinforced-wall"]  then data.raw.item["reinforced-wall"].icon = "__ExtraChests__/graphics/icons/warfare/reinforced-wall.png" end
	if data.raw.item["reinforced-gate"]  then data.raw.item["reinforced-gate"].icon = "__ExtraChests__/graphics/icons/warfare/reinforced-gate.png" end
end

if labs_graphics then
	if data.raw.lab["lab-2"]  then data.raw.lab["lab-2"].icon = "__ExtraChests__/graphics/entity/labs/icons/lab-2.png" end
	if data.raw.lab["lab-2"]  then data.raw.lab["lab-2"]["on_animation"].filename = "__ExtraChests__/graphics/entity/labs/lab-2.png" end
	if data.raw.lab["lab-2"]  then data.raw.lab["lab-2"]["off_animation"].filename = "__ExtraChests__/graphics/entity/labs/lab-2.png" end

	if data.raw.lab["lab-module"]  then data.raw.lab["lab-module"].icon = "__ExtraChests__/graphics/entity/labs/icons/lab-module.png" end
	if data.raw.lab["lab-module"]  then data.raw.lab["lab-module"]["on_animation"].filename = "__ExtraChests__/graphics/entity/labs/lab-module.png" end
	if data.raw.lab["lab-module"]  then data.raw.lab["lab-module"]["off_animation"].filename = "__ExtraChests__/graphics/entity/labs/lab-module.png" end

	if data.raw.lab["lab-alien"]  then data.raw.lab["lab-alien"].icon = "__ExtraChests__/graphics/entity/labs/icons/lab-alien.png" end
	if data.raw.lab["lab-alien"]  then data.raw.lab["lab-alien"]["on_animation"].filename = "__ExtraChests__/graphics/entity/labs/lab-alien.png" end
	if data.raw.lab["lab-alien"]  then data.raw.lab["lab-alien"]["off_animation"].filename = "__ExtraChests__/graphics/entity/labs/lab-alien.png" end

	if data.raw.item["lab-2"]  then data.raw.item["lab-2"].icon = "__ExtraChests__/graphics/entity/labs/icons/lab-2.png" end
	if data.raw.item["lab-module"]  then data.raw.item["lab-module"].icon = "__ExtraChests__/graphics/entity/labs/icons/lab-module.png" end
	if data.raw.item["lab-alien"]  then data.raw.item["lab-alien"].icon = "__ExtraChests__/graphics/entity/labs/icons/lab-alien.png" end

end


--------------- WARFARE graphics -------------------

if warfare_graphics then

	if data.raw.ammo["magazine"]  then data.raw.ammo["magazine"].icon = "__ExtraChests__/graphics/icons/warfare/magazine.png" end
	if data.raw.ammo["acid-bullet-magazine"]  then data.raw.ammo["acid-bullet-magazine"].icon = "__ExtraChests__/graphics/icons/warfare/acid-bullet-magazine.png" end
	if data.raw.ammo["ap-bullet-magazine"]  then data.raw.ammo["ap-bullet-magazine"].icon = "__ExtraChests__/graphics/icons/warfare/ap-bullet-magazine.png" end
	if data.raw.ammo["bullet-magazine"]  then data.raw.ammo["bullet-magazine"].icon = "__ExtraChests__/graphics/icons/warfare/bullet-magazine.png" end
	if data.raw.ammo["flame-bullet-magazine"]  then data.raw.ammo["flame-bullet-magazine"].icon = "__ExtraChests__/graphics/icons/warfare/flame-bullet-magazine.png" end
	if data.raw.ammo["he-bullet-magazine"]  then data.raw.ammo["he-bullet-magazine"].icon = "__ExtraChests__/graphics/icons/warfare/he-bullet-magazine.png" end
	if data.raw.ammo["impact-bullet-magazine"]  then data.raw.ammo["impact-bullet-magazine"].icon = "__ExtraChests__/graphics/icons/warfare/impact-bullet-magazine.png" end
	if data.raw.ammo["poison-bullet-magazine"]  then data.raw.ammo["poison-bullet-magazine"].icon = "__ExtraChests__/graphics/icons/warfare/poison-bullet-magazine.png" end


	if data.raw.ammo["bob-rocket"]  then data.raw.ammo["bob-rocket"].icon = "__ExtraChests__/graphics/icons/warfare/rocket.png" end
	if data.raw.ammo["bob-piercing-rocket"]  then data.raw.ammo["bob-piercing-rocket"].icon = "__ExtraChests__/graphics/icons/warfare/piercing-rocket.png" end
	if data.raw.ammo["bob-poison-rocket"]  then data.raw.ammo["bob-poison-rocket"].icon = "__ExtraChests__/graphics/icons/warfare/poison-rocket.png" end
	if data.raw.ammo["bob-acid-rocket"]  then data.raw.ammo["bob-acid-rocket"].icon = "__ExtraChests__/graphics/icons/warfare/acid-rocket.png" end
	if data.raw.ammo["bob-explosive-rocket"]  then data.raw.ammo["bob-explosive-rocket"].icon = "__ExtraChests__/graphics/icons/warfare/explosive-rocket.png" end
	if data.raw.ammo["bob-impact-rocket"]  then data.raw.ammo["bob-impact-rocket"].icon = "__ExtraChests__/graphics/icons/warfare/impact-rocket.png" end
	if data.raw.ammo["bob-flame-rocket"]  then data.raw.ammo["bob-flame-rocket"].icon = "__ExtraChests__/graphics/icons/warfare/flame-rocket.png" end

	if data.raw.ammo["shotgun-acid-shell"]  then data.raw.ammo["shotgun-acid-shell"].icon = "__ExtraChests__/graphics/icons/warfare/shotgun-acid-shell.png" end
	if data.raw.ammo["shotgun-ap-shell"]  then data.raw.ammo["shotgun-ap-shell"].icon = "__ExtraChests__/graphics/icons/warfare/shotgun-ap-shell.png" end
	if data.raw.ammo["shotgun-explosive-shell"]  then data.raw.ammo["shotgun-explosive-shell"].icon = "__ExtraChests__/graphics/icons/warfare/shotgun-explosive-shell.png" end
	if data.raw.ammo["shotgun-flame-shell"]  then data.raw.ammo["shotgun-flame-shell"].icon = "__ExtraChests__/graphics/icons/warfare/shotgun-flame-shell.png" end
	if data.raw.ammo["shotgun-impact-shell"]  then data.raw.ammo["shotgun-impact-shell"].icon = "__ExtraChests__/graphics/icons/warfare/shotgun-impact-shell.png" end
	if data.raw.ammo["shotgun-poison-shell"]  then data.raw.ammo["shotgun-poison-shell"].icon = "__ExtraChests__/graphics/icons/warfare/shotgun-poison-shell.png" end
	if data.raw.ammo["better-shotgun-shell"]  then data.raw.ammo["better-shotgun-shell"].icon = "__ExtraChests__/graphics/icons/warfare/shotgun-shell.png" end


	if data.raw["land-mine"]["poison-mine"]  then data.raw["land-mine"]["poison-mine"].icon = "__ExtraChests__/graphics/icons/warfare/land-mine-poison.png" end
	if data.raw["land-mine"]["distractor-mine"]  then data.raw["land-mine"]["distractor-mine"].icon = "__ExtraChests__/graphics/icons/warfare/land-mine-distract.png" end
	if data.raw["land-mine"]["slowdown-mine"]  then data.raw["land-mine"]["slowdown-mine"].icon = "__ExtraChests__/graphics/icons/warfare/land-mine-slow.png" end

	if data.raw.item["poison-mine"]  then data.raw.item["poison-mine"].icon = "__ExtraChests__/graphics/icons/warfare/land-mine-poison.png" end
	if data.raw.item["distractor-mine"]  then data.raw.item["distractor-mine"].icon = "__ExtraChests__/graphics/icons/warfare/land-mine-distract.png" end
	if data.raw.item["slowdown-mine"]  then data.raw.item["slowdown-mine"].icon = "__ExtraChests__/graphics/icons/warfare/land-mine-slow.png" end


	if data.raw["unit"]["bob-robot-tank"]  then data.raw["unit"]["bob-robot-tank"].icon = "__ExtraChests__/graphics/icons/warfare/drone.png" end
	if data.raw.item["bob-robot-tank"]  then data.raw.item["bob-robot-tank"].icon = "__ExtraChests__/graphics/icons/warfare/drone.png" end

end

if equipment_graphics then

	if data.raw.item["fusion-reactor-equipment"]    then data.raw.item["fusion-reactor-equipment"].icon   = "__ExtraChests__/graphics/icons/equipment/fusion-reactor-equipment-1-icon.png" end
	if data.raw.item["fusion-reactor-equipment-2"]  then data.raw.item["fusion-reactor-equipment-2"].icon = "__ExtraChests__/graphics/icons/equipment/fusion-reactor-equipment-2-icon.png" end
	if data.raw.item["fusion-reactor-equipment-3"]  then data.raw.item["fusion-reactor-equipment-3"].icon = "__ExtraChests__/graphics/icons/equipment/fusion-reactor-equipment-3-icon.png" end
	if data.raw.item["fusion-reactor-equipment-4"]  then data.raw.item["fusion-reactor-equipment-4"].icon = "__ExtraChests__/graphics/icons/equipment/fusion-reactor-equipment-4-icon.png" end

	if data.raw["generator-equipment"]["fusion-reactor-equipment"]    then   data.raw["generator-equipment"]["fusion-reactor-equipment"]["sprite"]["filename"] = "__ExtraChests__/graphics/icons/equipment/fusion-reactor-equipment-1.png" end
	if data.raw["generator-equipment"]["fusion-reactor-equipment-2"]  then data.raw["generator-equipment"]["fusion-reactor-equipment-2"]["sprite"]["filename"] = "__ExtraChests__/graphics/icons/equipment/fusion-reactor-equipment-2.png" end
	if data.raw["generator-equipment"]["fusion-reactor-equipment-3"]  then data.raw["generator-equipment"]["fusion-reactor-equipment-3"]["sprite"]["filename"] = "__ExtraChests__/graphics/icons/equipment/fusion-reactor-equipment-3.png" end
	if data.raw["generator-equipment"]["fusion-reactor-equipment-4"]  then data.raw["generator-equipment"]["fusion-reactor-equipment-4"]["sprite"]["filename"] = "__ExtraChests__/graphics/icons/equipment/fusion-reactor-equipment-4.png" end


	if data.raw.item["solar-panel-equipment"]    then data.raw.item["solar-panel-equipment"].icon   = "__ExtraChests__/graphics/icons/equipment/solar-panel-equipment-1.png" end
	if data.raw.item["solar-panel-equipment-2"]  then data.raw.item["solar-panel-equipment-2"].icon = "__ExtraChests__/graphics/icons/equipment/solar-panel-equipment-2.png" end
	if data.raw.item["solar-panel-equipment-3"]  then data.raw.item["solar-panel-equipment-3"].icon = "__ExtraChests__/graphics/icons/equipment/solar-panel-equipment-3.png" end
	if data.raw.item["solar-panel-equipment-4"]  then data.raw.item["solar-panel-equipment-4"].icon = "__ExtraChests__/graphics/icons/equipment/solar-panel-equipment-4.png" end

	if data.raw["solar-panel-equipment"]["solar-panel-equipment"]    then   data.raw["solar-panel-equipment"]["solar-panel-equipment"]["sprite"]["filename"] = "__ExtraChests__/graphics/icons/equipment/solar-panel-equipment-1.png" end
	if data.raw["solar-panel-equipment"]["solar-panel-equipment-2"]  then data.raw["solar-panel-equipment"]["solar-panel-equipment-2"]["sprite"]["filename"] = "__ExtraChests__/graphics/icons/equipment/solar-panel-equipment-2.png" end
	if data.raw["solar-panel-equipment"]["solar-panel-equipment-3"]  then data.raw["solar-panel-equipment"]["solar-panel-equipment-3"]["sprite"]["filename"] = "__ExtraChests__/graphics/icons/equipment/solar-panel-equipment-3.png" end
	if data.raw["solar-panel-equipment"]["solar-panel-equipment-4"]  then data.raw["solar-panel-equipment"]["solar-panel-equipment-4"]["sprite"]["filename"] = "__ExtraChests__/graphics/icons/equipment/solar-panel-equipment-4.png" end




	if data.raw.item["basic-laser-defense-equipment"]    then data.raw.item["basic-laser-defense-equipment"].icon   = "__ExtraChests__/graphics/icons/equipment/basic-laser-defense-equipment-1-icon.png" end
	if data.raw.item["basic-laser-defense-equipment-2"]  then data.raw.item["basic-laser-defense-equipment-2"].icon = "__ExtraChests__/graphics/icons/equipment/basic-laser-defense-equipment-2-icon.png" end
	if data.raw.item["basic-laser-defense-equipment-3"]  then data.raw.item["basic-laser-defense-equipment-3"].icon = "__ExtraChests__/graphics/icons/equipment/basic-laser-defense-equipment-3-icon.png" end
	if data.raw.item["basic-laser-defense-equipment-4"]  then data.raw.item["basic-laser-defense-equipment-4"].icon = "__ExtraChests__/graphics/icons/equipment/basic-laser-defense-equipment-4-icon.png" end
	if data.raw.item["basic-laser-defense-equipment-5"]  then data.raw.item["basic-laser-defense-equipment-5"].icon = "__ExtraChests__/graphics/icons/equipment/basic-laser-defense-equipment-5-icon.png" end
	if data.raw.item["basic-laser-defense-equipment-6"]  then data.raw.item["basic-laser-defense-equipment-6"].icon = "__ExtraChests__/graphics/icons/equipment/basic-laser-defense-equipment-6-icon.png" end
																						  
	if data.raw.item["basic-laser-defense-equipment-2"]    then 																					       
		data:extend(
		{
		  bob_basic_laser_defense_equipment("basic-laser-defense-equipment",   "__ExtraChests__/graphics/icons/equipment/basic-laser-defense-equipment-1.png", "11kJ", "10kJ", "bob-yellow-laser", 1, 20, 15),
		}
		)
	end
	
	if data.raw.item["basic-laser-defense-equipment-2"]    then 																					       
		data:extend(
		{	
		  {
		    type = "projectile",
		    name = "bob-red-laser",
		    flags = {"not-on-map"},
		    acceleration = 0.005,
		    action = boblaseraction("bob-laser-bubble-ruby", 5),
		    light = {intensity = 0.5, size = 10},
		    animation = boblaseranimation(1, {r=1, g=0.2, b=0.2, a=1}),
		    speed = 0.15
		  },

		  bob_basic_laser_defense_equipment("basic-laser-defense-equipment-2", "__ExtraChests__/graphics/icons/equipment/basic-laser-defense-equipment-2.png", "26kJ", "12500J", "bob-red-laser",    1.5, 15, 16),
		  bob_basic_laser_defense_equipment("basic-laser-defense-equipment-3", "__ExtraChests__/graphics/icons/equipment/basic-laser-defense-equipment-3.png", "46kJ", "15kJ",   "bob-blue-laser",   2.1, 12, 17),
		  bob_basic_laser_defense_equipment("basic-laser-defense-equipment-4", "__ExtraChests__/graphics/icons/equipment/basic-laser-defense-equipment-4.png", "71kJ", "17500J", "bob-purple-laser", 2.8, 10, 18),
		  bob_basic_laser_defense_equipment("basic-laser-defense-equipment-5", "__ExtraChests__/graphics/icons/equipment/basic-laser-defense-equipment-5.png", "101kJ","20kJ",   "bob-green-laser",  3.6, 8.5, 19),
		  bob_basic_laser_defense_equipment("basic-laser-defense-equipment-6", "__ExtraChests__/graphics/icons/equipment/basic-laser-defense-equipment-6.png", "136kJ","22500J", "bob-white-laser",  4.5, 7.5, 20),
		}
		)
	end	
	

	if data.raw["projectile"]["bob-rocket"]    then 	
		data.raw["projectile"]["bob-rocket"]["animation"]["filename"]   	= "__ExtraChests__/graphics/entity/projectiles/rocket.png" 
		data.raw["projectile"]["bob-rocket"]["shadow"]["filename"]   		= "__ExtraChests__/graphics/entity/projectiles/rocket-shadow.png" 
	end
	if data.raw["projectile"]["bob-piercing-rocket"]  then 	
		data.raw["projectile"]["bob-piercing-rocket"]["animation"]["filename"] 	= "__ExtraChests__/graphics/entity/projectiles/piercing-rocket.png" 
		data.raw["projectile"]["bob-piercing-rocket"]["shadow"]["filename"] 	= "__ExtraChests__/graphics/entity/projectiles/rocket-shadow.png" 
	end
	if data.raw["projectile"]["bob-impact-rocket"]  then
	 	data.raw["projectile"]["bob-impact-rocket"]["animation"]["filename"] 	= "__ExtraChests__/graphics/entity/projectiles/impact-rocket.png" 
		data.raw["projectile"]["bob-impact-rocket"]["shadow"]["filename"] 	= "__ExtraChests__/graphics/entity/projectiles/rocket-shadow.png" 
	end
	if data.raw["projectile"]["bob-explosive-rocket"]  then
		data.raw["projectile"]["bob-explosive-rocket"]["animation"]["filename"] = "__ExtraChests__/graphics/entity/projectiles/explosive-rocket.png" 
		data.raw["projectile"]["bob-explosive-rocket"]["shadow"]["filename"] 	= "__ExtraChests__/graphics/entity/projectiles/rocket-shadow.png" 
	end
	if data.raw["projectile"]["bob-flame-rocket"]  then
	 	data.raw["projectile"]["bob-flame-rocket"]["animation"]["filename"] 	= "__ExtraChests__/graphics/entity/projectiles/flame-rocket.png" 
		data.raw["projectile"]["bob-flame-rocket"]["shadow"]["filename"] 	= "__ExtraChests__/graphics/entity/projectiles/rocket-shadow.png" 
	end
	if data.raw["projectile"]["bob-poison-rocket"]  then
	 	data.raw["projectile"]["bob-poison-rocket"]["animation"]["filename"] 	= "__ExtraChests__/graphics/entity/projectiles/poison-rocket.png" 
		data.raw["projectile"]["bob-poison-rocket"]["shadow"]["filename"] 	= "__ExtraChests__/graphics/entity/projectiles/rocket-shadow.png" 
	end
	if data.raw["projectile"]["bob-acid-rocket"]  then
	 	data.raw["projectile"]["bob-acid-rocket"]["animation"]["filename"] 	= "__ExtraChests__/graphics/entity/projectiles/acid-rocket.png" 
		data.raw["projectile"]["bob-acid-rocket"]["shadow"]["filename"] 	= "__ExtraChests__/graphics/entity/projectiles/rocket-shadow.png" 
	end


--	if data.raw["active-defense-equipment"]["basic-laser-defense-equipment-2"]  then data.raw["active-defense-equipment"]["basic-laser-defense-equipment-2"].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw["active-defense-equipment"]["basic-laser-defense-equipment-3"]  then data.raw["active-defense-equipment"]["basic-laser-defense-equipment-3"].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw["active-defense-equipment"]["basic-laser-defense-equipment-4"]  then data.raw["active-defense-equipment"]["basic-laser-defense-equipment-4"].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw["active-defense-equipment"]["basic-laser-defense-equipment-5"]  then data.raw["active-defense-equipment"]["basic-laser-defense-equipment-5"].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw["active-defense-equipment"]["basic-laser-defense-equipment-6"]  then data.raw["active-defense-equipment"]["basic-laser-defense-equipment-6"].icon = "__ExtraChests__/graphics/icons/equipment/" end
--
----	if data.raw["active-defense-equipment"][""]  then data.raw["active-defense-equipment"][""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw["active-defense-equipment"][""]  then data.raw["active-defense-equipment"][""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw["active-defense-equipment"][""]  then data.raw["active-defense-equipment"][""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw["active-defense-equipment"][""]  then data.raw["active-defense-equipment"][""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw["active-defense-equipment"][""]  then data.raw["active-defense-equipment"][""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw["active-defense-equipment"][""]  then data.raw["active-defense-equipment"][""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	
	

--	if data.raw.item[""]  then data.raw.item[""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw.item[""]  then data.raw.item[""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw.item[""]  then data.raw.item[""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw.item[""]  then data.raw.item[""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw.item[""]  then data.raw.item[""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw.item[""]  then data.raw.item[""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw.item[""]  then data.raw.item[""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw.item[""]  then data.raw.item[""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw.item[""]  then data.raw.item[""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw.item[""]  then data.raw.item[""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw.item[""]  then data.raw.item[""].icon = "__ExtraChests__/graphics/icons/equipment/" end
--	if data.raw.item[""]  then data.raw.item[""].icon = "__ExtraChests__/graphics/icons/equipment/" end

end


--     ============== TECHNOLOGIES ICONS graphics ===============

if menu_graphics then

	if data.raw["item-group"]["logistics"].icon then data.raw["item-group"]["logistics"].icon = "__ExtraChests__/graphics/icons/menu/logistics.png"	   end
	if data.raw["item-group"]["bob-logistics"] then data.raw["item-group"]["bob-logistics"].icon = "__ExtraChests__/graphics/icons/menu/bobslogistics.png"   end

	if data.raw["item-group"]["bob-intermediate-products"] then data.raw["item-group"]["bob-intermediate-products"].icon = "__ExtraChests__/graphics/icons/menu/bobintermediates.png"	 end
	if data.raw["item-group"]["production"] then data.raw["item-group"]["production"].icon = "__ExtraChests__/graphics/icons/menu/production.png"	 end
	if data.raw["item-group"]["intermediate-products"] then data.raw["item-group"]["intermediate-products"].icon = "__ExtraChests__/graphics/icons/menu/intermediate-products.png"	 end
	
	if data.raw["item-group"]["bobmodules"] then data.raw["item-group"]["bobmodules"].icon = "__ExtraChests__/graphics/icons/menu/modules.png" end

end

if techonologies_graphics then

	if data.raw.technology["solar-energy"]   then data.raw.technology["solar-energy"].icon   = "__ExtraChests__/graphics/icons/technology/solar-energy-t1-tech.png" end

	if data.raw.technology["bob-solar-energy"]   then data.raw.technology["bob-solar-energy"].icon   = "__ExtraChests__/graphics/icons/technology/solar-energy-t1-tech.png" end
	if data.raw.technology["bob-solar-energy-2"] then data.raw.technology["bob-solar-energy-2"].icon = "__ExtraChests__/graphics/icons/technology/solar-energy-t2-tech.png" end
	if data.raw.technology["bob-solar-energy-3"] then data.raw.technology["bob-solar-energy-3"].icon = "__ExtraChests__/graphics/icons/technology/solar-energy-t3-tech.png" end
	if data.raw.technology["bob-solar-energy-4"] then data.raw.technology["bob-solar-energy-4"].icon = "__ExtraChests__/graphics/icons/technology/solar-energy-t4-tech.png" end





	if data.raw.technology["lead-processing"] then data.raw.technology["lead-processing"].icon = "__ExtraChests__/graphics/icons/technology/lead-processing.png" end 
	if data.raw.technology["aluminium-processing"] then data.raw.technology["aluminium-processing"].icon = "__ExtraChests__/graphics/icons/technology/aluminium-processing.png" end 
	if data.raw.technology["nitinol-processing"] then data.raw.technology["nitinol-processing"].icon = "__ExtraChests__/graphics/icons/technology/nitinol-processing.png" end 
	if data.raw.technology["barrels"] then data.raw.technology["barrels"].icon = "__ExtraChests__/graphics/icons/technology/barrels.png" end 



        if data.raw.technology["steam-engine-generator-1"] then data.raw.technology["steam-engine-generator-1"].icon = "__ExtraChests__/graphics/icons/technology/steam-engine-2.png" end    
        if data.raw.technology["steam-engine-generator-2"] then data.raw.technology["steam-engine-generator-2"].icon = "__ExtraChests__/graphics/icons/technology/steam-engine-3.png" end  
                
        if data.raw.technology["steam-engine-generator-1"] then data.raw.technology["steam-engine-generator-1"].icon_size = 128 end    
        if data.raw.technology["steam-engine-generator-2"] then data.raw.technology["steam-engine-generator-2"].icon_size = 128 end  


        if data.raw.technology["electronics-machine-1"] then data.raw.technology["electronics-machine-1"].icon = "__ExtraChests__/graphics/icons/technology/electronics-machine-chip.png" end    
        if data.raw.technology["electronics-machine-2"] then data.raw.technology["electronics-machine-2"].icon = "__ExtraChests__/graphics/icons/technology/electronics-machine-chip.png" end  
        if data.raw.technology["electronics-machine-3"] then data.raw.technology["electronics-machine-3"].icon = "__ExtraChests__/graphics/icons/technology/electronics-machine-chip.png" end  
                
        if data.raw.technology["electronics-machine-1"] then data.raw.technology["electronics-machine-1"].icon_size = 128 end    
        if data.raw.technology["electronics-machine-2"] then data.raw.technology["electronics-machine-2"].icon_size = 128 end  
        if data.raw.technology["electronics-machine-3"] then data.raw.technology["electronics-machine-3"].icon_size = 128 end  



        if data.raw.technology["advanced-electronics-3"] then data.raw.technology["advanced-electronics-3"].icon = "__ExtraChests__/graphics/icons/technology/advanced-electronics-3.png" end    
        if data.raw.technology["advanced-electronics-3"] then data.raw.technology["advanced-electronics-3"].icon_size = 128 end    



        if data.raw.technology["reinforced-wall"] then data.raw.technology["reinforced-wall"].icon = "__ExtraChests__/graphics/icons/technology/reinforce-walls.png" end    
        if data.raw.technology["reinforced-wall"] then data.raw.technology["reinforced-wall"].icon_size = 128 end    



	if data.raw.technology["bob-pumpjacks-1"] then data.raw.technology["bob-pumpjacks-1"].icon = "__base__/graphics/technology/oil-gathering.png" end 
	if data.raw.technology["bob-pumpjacks-2"] then data.raw.technology["bob-pumpjacks-2"].icon = "__base__/graphics/technology/oil-gathering.png" end 
	if data.raw.technology["bob-pumpjacks-3"] then data.raw.technology["bob-pumpjacks-3"].icon = "__base__/graphics/technology/oil-gathering.png" end 
	if data.raw.technology["bob-pumpjacks-4"] then data.raw.technology["bob-pumpjacks-4"].icon = "__base__/graphics/technology/oil-gathering.png" end 




 	if data.raw.technology["energy-shield-equipment"] then data.raw.technology["energy-shield-equipment"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-equipment.png" end 
	if data.raw.technology["energy-shield-mk2-equipment"] then data.raw.technology["energy-shield-mk2-equipment"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-mk2-equipment.png" end 	    
	if data.raw.technology["energy-shield-equipment"] then data.raw.technology["energy-shield-equipment"].icon_size = 128 end 
	if data.raw.technology["energy-shield-mk2-equipment"] then data.raw.technology["energy-shield-mk2-equipment"].icon_size = 128 end 


	if data.raw.technology["energy-shield-equipment-1"] then data.raw.technology["energy-shield-equipment-1"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-equipment.png" end 
	if data.raw.technology["energy-shield-equipment-2"] then data.raw.technology["energy-shield-equipment-2"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-mk2-equipment.png" end 	    
	if data.raw.technology["energy-shield-equipment-3"] then data.raw.technology["energy-shield-equipment-3"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-mk3-equipment.png" end 
	if data.raw.technology["energy-shield-equipment-4"] then data.raw.technology["energy-shield-equipment-4"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-mk4-equipment.png" end 
	if data.raw.technology["energy-shield-equipment-5"] then data.raw.technology["energy-shield-equipment-5"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-mk5-equipment.png" end 
	if data.raw.technology["energy-shield-equipment-6"] then data.raw.technology["energy-shield-equipment-6"].icon = "__ExtraChests__/graphics/icons/technology/energy-shield-mk6-equipment.png" end 

	if data.raw.technology["energy-shield-equipment-1"] then data.raw.technology["energy-shield-equipment-1"].icon_size = 128 end 
	if data.raw.technology["energy-shield-equipment-2"] then data.raw.technology["energy-shield-equipment-2"].icon_size = 128 end 
	if data.raw.technology["energy-shield-equipment-3"] then data.raw.technology["energy-shield-equipment-3"].icon_size = 128 end 
	if data.raw.technology["energy-shield-equipment-4"] then data.raw.technology["energy-shield-equipment-4"].icon_size = 128 end 
	if data.raw.technology["energy-shield-equipment-5"] then data.raw.technology["energy-shield-equipment-5"].icon_size = 128 end 
	if data.raw.technology["energy-shield-equipment-6"] then data.raw.technology["energy-shield-equipment-6"].icon_size = 128 end 





	if data.raw.technology["bob-drills-1"] then data.raw.technology["bob-drills-1"].icon = "__ExtraChests__/graphics/icons/technology/mining-drill.png" end 
	if data.raw.technology["bob-drills-2"] then data.raw.technology["bob-drills-2"].icon = "__ExtraChests__/graphics/icons/technology/mining-drill.png" end 
	if data.raw.technology["bob-drills-3"] then data.raw.technology["bob-drills-3"].icon = "__ExtraChests__/graphics/icons/technology/mining-drill.png" end 
	if data.raw.technology["bob-drills-4"] then data.raw.technology["bob-drills-4"].icon = "__ExtraChests__/graphics/icons/technology/mining-drill.png" end 

	if data.raw.technology["bob-area-drills-1"] then data.raw.technology["bob-area-drills-1"].icon = "__ExtraChests__/graphics/icons/technology/large-mining-drill.png" end 
	if data.raw.technology["bob-area-drills-2"] then data.raw.technology["bob-area-drills-2"].icon = "__ExtraChests__/graphics/icons/technology/large-mining-drill.png" end 
	if data.raw.technology["bob-area-drills-3"] then data.raw.technology["bob-area-drills-3"].icon = "__ExtraChests__/graphics/icons/technology/large-mining-drill.png" end 
	if data.raw.technology["bob-area-drills-4"] then data.raw.technology["bob-area-drills-4"].icon = "__ExtraChests__/graphics/icons/technology/large-mining-drill.png" end 
	
	if data.raw.technology["bob-boiler-1"] then data.raw.technology["bob-boiler-1"].icon = "__ExtraChests__/graphics/icons/technology/boiler-2.png" end
	if data.raw.technology["bob-boiler-2"] then data.raw.technology["bob-boiler-2"].icon = "__ExtraChests__/graphics/icons/technology/boiler-3.png" end
	if data.raw.technology["bob-boiler-3"] then data.raw.technology["bob-boiler-3"].icon = "__ExtraChests__/graphics/icons/technology/boiler-4.png" end




	if data.raw.technology["battery"] then data.raw.technology["battery"].icon = "__ExtraChests__/graphics/icons/technology/battery-1.png" end
	if data.raw.technology["battery-2"] then data.raw.technology["battery-2"].icon = "__ExtraChests__/graphics/icons/technology/battery-2.png" end
	if data.raw.technology["battery-3"] then data.raw.technology["battery-3"].icon = "__ExtraChests__/graphics/icons/technology/battery-3.png" end

	if data.raw.technology["battery"] then data.raw.technology["battery"].icon_size = 128 end
	if data.raw.technology["battery-2"] then data.raw.technology["battery-2"].icon_size = 128 end
	if data.raw.technology["battery-3"] then data.raw.technology["battery-3"].icon_size = 128 end


	if data.raw.technology["basic-laser-defense-equipment"]   then    data.raw.technology["basic-laser-defense-equipment"].icon = "__ExtraChests__/graphics/icons/technology/basic-laser-defense-equipment-1.png" end
	if data.raw.technology["basic-laser-defense-equipment-2"] then  data.raw.technology["basic-laser-defense-equipment-2"].icon = "__ExtraChests__/graphics/icons/technology/basic-laser-defense-equipment-2.png" end
	if data.raw.technology["basic-laser-defense-equipment-3"] then  data.raw.technology["basic-laser-defense-equipment-3"].icon = "__ExtraChests__/graphics/icons/technology/basic-laser-defense-equipment-3.png" end
	if data.raw.technology["basic-laser-defense-equipment-4"] then  data.raw.technology["basic-laser-defense-equipment-4"].icon = "__ExtraChests__/graphics/icons/technology/basic-laser-defense-equipment-4.png" end
	if data.raw.technology["basic-laser-defense-equipment-5"] then  data.raw.technology["basic-laser-defense-equipment-5"].icon = "__ExtraChests__/graphics/icons/technology/basic-laser-defense-equipment-5.png" end
	if data.raw.technology["basic-laser-defense-equipment-6"] then  data.raw.technology["basic-laser-defense-equipment-6"].icon = "__ExtraChests__/graphics/icons/technology/basic-laser-defense-equipment-6.png" end

	if data.raw.technology["basic-laser-defense-equipment"]   then    data.raw.technology["basic-laser-defense-equipment"].icon_size = 128 end
	if data.raw.technology["basic-laser-defense-equipment-2"] then  data.raw.technology["basic-laser-defense-equipment-2"].icon_size = 128 end
	if data.raw.technology["basic-laser-defense-equipment-3"] then  data.raw.technology["basic-laser-defense-equipment-3"].icon_size = 128 end
	if data.raw.technology["basic-laser-defense-equipment-4"] then  data.raw.technology["basic-laser-defense-equipment-4"].icon_size = 128 end
	if data.raw.technology["basic-laser-defense-equipment-5"] then  data.raw.technology["basic-laser-defense-equipment-5"].icon_size = 128 end
	if data.raw.technology["basic-laser-defense-equipment-6"] then  data.raw.technology["basic-laser-defense-equipment-6"].icon_size = 128 end
	




	if data.raw.technology["bob-robotics-1"] then data.raw.technology["bob-robotics-1"].icon = "__ExtraChests__/graphics/icons/technology/robotics-2.png" end    
	if data.raw.technology["bob-robotics-2"] then data.raw.technology["bob-robotics-2"].icon = "__ExtraChests__/graphics/icons/technology/robotics-3.png" end  
	if data.raw.technology["bob-robotics-3"] then data.raw.technology["bob-robotics-3"].icon = "__ExtraChests__/graphics/icons/technology/robotics-4.png" end  
												   
	if data.raw.technology["bob-robotics-1"] then data.raw.technology["bob-robotics-1"].icon_size = 128 end    
	if data.raw.technology["bob-robotics-2"] then data.raw.technology["bob-robotics-2"].icon_size = 128 end  
	if data.raw.technology["bob-robotics-3"] then data.raw.technology["bob-robotics-3"].icon_size = 128 end  



	if data.raw.technology["solar-panel-equipment"] then data.raw.technology["solar-panel-equipment"].icon = "__ExtraChests__/graphics/icons/technology/solar-panel-equipment-1.png" end    
	if data.raw.technology["solar-panel-equipment-1"] then data.raw.technology["solar-panel-equipment-1"].icon = "__ExtraChests__/graphics/icons/technology/solar-panel-equipment-1.png" end    
	if data.raw.technology["solar-panel-equipment-2"] then data.raw.technology["solar-panel-equipment-2"].icon = "__ExtraChests__/graphics/icons/technology/solar-panel-equipment-2.png" end  
	if data.raw.technology["solar-panel-equipment-3"] then data.raw.technology["solar-panel-equipment-3"].icon = "__ExtraChests__/graphics/icons/technology/solar-panel-equipment-3.png" end  
	if data.raw.technology["solar-panel-equipment-4"] then data.raw.technology["solar-panel-equipment-4"].icon = "__ExtraChests__/graphics/icons/technology/solar-panel-equipment-4.png" end  


	if data.raw.technology["solar-panel-equipment"] then data.raw.technology["solar-panel-equipment"].icon_size = 128 end    
	if data.raw.technology["solar-panel-equipment-1"] then data.raw.technology["solar-panel-equipment-1"].icon_size = 128 end    
	if data.raw.technology["solar-panel-equipment-2"] then data.raw.technology["solar-panel-equipment-2"].icon_size = 128 end  
	if data.raw.technology["solar-panel-equipment-3"] then data.raw.technology["solar-panel-equipment-3"].icon_size = 128 end  
	if data.raw.technology["solar-panel-equipment-4"] then data.raw.technology["solar-panel-equipment-4"].icon_size = 128 end  





	if data.raw.technology["bob-acid-bullets"] then data.raw.technology["bob-acid-bullets"].icon = "__ExtraChests__/graphics/icons/technology/acid-bullet-magazine.png" end    
	if data.raw.technology["bob-ap-bullets"] then data.raw.technology["bob-ap-bullets"].icon = "__ExtraChests__/graphics/icons/technology/ap-bullet-magazine.png" end  
	if data.raw.technology["bob-bullets"] then data.raw.technology["bob-bullets"].icon = "__ExtraChests__/graphics/icons/technology/bullet-magazine.png" end  
	if data.raw.technology["bob-flame-bullets"] then data.raw.technology["bob-flame-bullets"].icon = "__ExtraChests__/graphics/icons/technology/flame-bullet-magazine.png" end    
	if data.raw.technology["bob-he-bullets"] then data.raw.technology["bob-he-bullets"].icon = "__ExtraChests__/graphics/icons/technology/he-bullet-magazine.png" end  
	if data.raw.technology["bob-impact-bullets"] then data.raw.technology["bob-impact-bullets"].icon = "__ExtraChests__/graphics/icons/technology/impact-bullet-magazine.png" end  
	if data.raw.technology["bob-poison-bullets"] then data.raw.technology["bob-poison-bullets"].icon = "__ExtraChests__/graphics/icons/technology/poison-bullet-magazine.png" end  


	if data.raw.technology["bob-acid-bullets"] then data.raw.technology["bob-acid-bullets"].icon_size = 128 end    
	if data.raw.technology["bob-ap-bullets"] then data.raw.technology["bob-ap-bullets"].icon_size = 128 end  
	if data.raw.technology["bob-bullets"] then data.raw.technology["bob-bullets"].icon_size = 128 end  
	if data.raw.technology["bob-flame-bullets"] then data.raw.technology["bob-flame-bullets"].icon_size = 128 end    
	if data.raw.technology["bob-he-bullets"] then data.raw.technology["bob-he-bullets"].icon_size = 128 end  
	if data.raw.technology["bob-impact-bullets"] then data.raw.technology["bob-impact-bullets"].icon_size = 128 end  
	if data.raw.technology["bob-poison-bullets"] then data.raw.technology["bob-poison-bullets"].icon_size = 128 end  




	if data.raw.technology["bob-rocket"] then data.raw.technology["bob-rocket"].icon = "__ExtraChests__/graphics/icons/technology/rocket.png" end    
	if data.raw.technology["bob-piercing-rocket"] then data.raw.technology["bob-piercing-rocket"].icon = "__ExtraChests__/graphics/icons/technology/piercing-rocket.png" end  
	if data.raw.technology["bob-poison-rocket"] then data.raw.technology["bob-poison-rocket"].icon = "__ExtraChests__/graphics/icons/technology/poison-rocket.png" end  
	if data.raw.technology["bob-acid-rocket"] then data.raw.technology["bob-acid-rocket"].icon = "__ExtraChests__/graphics/icons/technology/acid-rocket.png" end    
	if data.raw.technology["bob-explosive-rocket"] then data.raw.technology["bob-explosive-rocket"].icon = "__ExtraChests__/graphics/icons/technology/explosive-rocket.png" end  
	if data.raw.technology["bob-impact-rocket"] then data.raw.technology["bob-impact-rocket"].icon = "__ExtraChests__/graphics/icons/technology/impact-rocket.png" end  
	if data.raw.technology["bob-flame-rocket"] then data.raw.technology["bob-flame-rocket"].icon = "__ExtraChests__/graphics/icons/technology/flame-rocket.png" end  


	if data.raw.technology["bob-rocket"] then data.raw.technology["bob-rocket"].icon_size = 128 end    
	if data.raw.technology["bob-piercing-rocket"] then data.raw.technology["bob-piercing-rocket"].icon_size = 128 end  
	if data.raw.technology["bob-poison-rocket"] then data.raw.technology["bob-poison-rocket"].icon_size = 128 end  
	if data.raw.technology["bob-acid-rocket"] then data.raw.technology["bob-acid-rocket"].icon_size = 128 end    
	if data.raw.technology["bob-explosive-rocket"] then data.raw.technology["bob-explosive-rocket"].icon_size = 128 end  
	if data.raw.technology["bob-impact-rocket"] then data.raw.technology["bob-impact-rocket"].icon_size = 128 end  
	if data.raw.technology["bob-flame-rocket"] then data.raw.technology["bob-flame-rocket"].icon_size = 128 end  





	if data.raw.technology["bob-shotgun-acid-shells"] then data.raw.technology["bob-shotgun-acid-shells"].icon = "__ExtraChests__/graphics/icons/technology/shotgun-acid-shell.png" end    
	if data.raw.technology["bob-shotgun-ap-shells"] then data.raw.technology["bob-shotgun-ap-shells"].icon = "__ExtraChests__/graphics/icons/technology/shotgun-ap-shell.png" end  
	if data.raw.technology["bob-shotgun-explosive-shells"] then data.raw.technology["bob-shotgun-explosive-shells"].icon = "__ExtraChests__/graphics/icons/technology/shotgun-explosive-shell.png" end  
	if data.raw.technology["bob-shotgun-flame-shells"] then data.raw.technology["bob-shotgun-flame-shells"].icon = "__ExtraChests__/graphics/icons/technology/shotgun-flame-shell.png" end    
	if data.raw.technology["bob-shotgun-impact-shells"] then data.raw.technology["bob-shotgun-impact-shells"].icon = "__ExtraChests__/graphics/icons/technology/shotgun-impact-shell.png" end  
	if data.raw.technology["bob-shotgun-poison-shells"] then data.raw.technology["bob-shotgun-poison-shells"].icon = "__ExtraChests__/graphics/icons/technology/shotgun-poison-shell.png" end  
	if data.raw.technology["bob-shotgun-shells"] then data.raw.technology["bob-shotgun-shells"].icon = "__ExtraChests__/graphics/icons/technology/shotgun-shell.png" end  


	if data.raw.technology["bob-shotgun-acid-shells"] then data.raw.technology["bob-shotgun-acid-shells"].icon_size = 128 end    
	if data.raw.technology["bob-shotgun-ap-shells"] then data.raw.technology["bob-shotgun-ap-shells"].icon_size = 128 end  
	if data.raw.technology["bob-shotgun-explosive-shells"] then data.raw.technology["bob-shotgun-explosive-shells"].icon_size = 128 end  
	if data.raw.technology["bob-shotgun-flame-shells"] then data.raw.technology["bob-shotgun-flame-shells"].icon_size = 128 end    
	if data.raw.technology["bob-shotgun-impact-shells"] then data.raw.technology["bob-shotgun-impact-shells"].icon_size = 128 end  
	if data.raw.technology["bob-shotgun-poison-shells"] then data.raw.technology["bob-shotgun-poison-shells"].icon_size = 128 end  
	if data.raw.technology["bob-shotgun-shells"] then data.raw.technology["bob-shotgun-shells"].icon_size = 128 end  



	if data.raw.technology["bob-laser-rifle-ammo-1"] then data.raw.technology["bob-laser-rifle-ammo-1"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-ammo.png" end
	if data.raw.technology["bob-laser-rifle-ammo-2"] then data.raw.technology["bob-laser-rifle-ammo-2"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-ammo.png" end
	if data.raw.technology["bob-laser-rifle-ammo-3"] then data.raw.technology["bob-laser-rifle-ammo-3"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-ammo.png" end
	if data.raw.technology["bob-laser-rifle-ammo-4"] then data.raw.technology["bob-laser-rifle-ammo-4"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-ammo.png" end
	if data.raw.technology["bob-laser-rifle-ammo-5"] then data.raw.technology["bob-laser-rifle-ammo-5"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-ammo.png" end
	if data.raw.technology["bob-laser-rifle-ammo-6"] then data.raw.technology["bob-laser-rifle-ammo-6"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-ammo.png" end

	if data.raw.technology["bob-laser-rifle-ammo-1"] then data.raw.technology["bob-laser-rifle-ammo-1"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-ammo-2"] then data.raw.technology["bob-laser-rifle-ammo-2"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-ammo-3"] then data.raw.technology["bob-laser-rifle-ammo-3"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-ammo-4"] then data.raw.technology["bob-laser-rifle-ammo-4"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-ammo-5"] then data.raw.technology["bob-laser-rifle-ammo-5"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-ammo-6"] then data.raw.technology["bob-laser-rifle-ammo-6"].icon_size = 128 end


	if data.raw.technology["bob-laser-rifle-damage-1"] then data.raw.technology["bob-laser-rifle-damage-1"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-damage.png" end
	if data.raw.technology["bob-laser-rifle-damage-2"] then data.raw.technology["bob-laser-rifle-damage-2"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-damage.png" end
	if data.raw.technology["bob-laser-rifle-damage-3"] then data.raw.technology["bob-laser-rifle-damage-3"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-damage.png" end
	if data.raw.technology["bob-laser-rifle-damage-4"] then data.raw.technology["bob-laser-rifle-damage-4"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-damage.png" end
	if data.raw.technology["bob-laser-rifle-damage-5"] then data.raw.technology["bob-laser-rifle-damage-5"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-damage.png" end
	if data.raw.technology["bob-laser-rifle-damage-6"] then data.raw.technology["bob-laser-rifle-damage-6"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-damage.png" end

	if data.raw.technology["bob-laser-rifle-damage-1"] then data.raw.technology["bob-laser-rifle-damage-1"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-damage-2"] then data.raw.technology["bob-laser-rifle-damage-2"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-damage-3"] then data.raw.technology["bob-laser-rifle-damage-3"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-damage-4"] then data.raw.technology["bob-laser-rifle-damage-4"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-damage-5"] then data.raw.technology["bob-laser-rifle-damage-5"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-damage-6"] then data.raw.technology["bob-laser-rifle-damage-6"].icon_size = 128 end



	if data.raw.technology["bob-laser-rifle-speed-1"] then data.raw.technology["bob-laser-rifle-speed-1"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-speed.png" end
	if data.raw.technology["bob-laser-rifle-speed-2"] then data.raw.technology["bob-laser-rifle-speed-2"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-speed.png" end
	if data.raw.technology["bob-laser-rifle-speed-3"] then data.raw.technology["bob-laser-rifle-speed-3"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-speed.png" end
	if data.raw.technology["bob-laser-rifle-speed-4"] then data.raw.technology["bob-laser-rifle-speed-4"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-speed.png" end
	if data.raw.technology["bob-laser-rifle-speed-5"] then data.raw.technology["bob-laser-rifle-speed-5"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-speed.png" end
	if data.raw.technology["bob-laser-rifle-speed-6"] then data.raw.technology["bob-laser-rifle-speed-6"].icon = "__ExtraChests__/graphics/icons/technology/laser-rifle-speed.png" end

	if data.raw.technology["bob-laser-rifle-speed-1"] then data.raw.technology["bob-laser-rifle-speed-1"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-speed-2"] then data.raw.technology["bob-laser-rifle-speed-2"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-speed-3"] then data.raw.technology["bob-laser-rifle-speed-3"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-speed-4"] then data.raw.technology["bob-laser-rifle-speed-4"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-speed-5"] then data.raw.technology["bob-laser-rifle-speed-5"].icon_size = 128 end
	if data.raw.technology["bob-laser-rifle-speed-6"] then data.raw.technology["bob-laser-rifle-speed-6"].icon_size = 128 end


	if data.raw.technology["poison-mine"] then data.raw.technology["poison-mine"].icon = "__ExtraChests__/graphics/icons/technology/land-min-poison.png" end
	if data.raw.technology["slowdown-mine"] then data.raw.technology["slowdown-mine"].icon = "__ExtraChests__/graphics/icons/technology/land-mine-slow.png" end
	if data.raw.technology["distractor-mine"] then data.raw.technology["distractor-mine"].icon = "__ExtraChests__/graphics/icons/technology/land-mine-distract.png" end

	if data.raw.technology["poison-mine"] then data.raw.technology["poison-mine"].icon_size = 128 end
	if data.raw.technology["slowdown-mine"] then data.raw.technology["slowdown-mine"].icon_size = 128 end
	if data.raw.technology["distractor-mine"] then data.raw.technology["distractor-mine"].icon_size = 128 end

	if data.raw.technology["alien-research"] then data.raw.technology["alien-research"].icon = "__ExtraChests__/graphics/icons/technology/alien-research.png" end
	if data.raw.technology["alien-research"] then data.raw.technology["alien-research"].icon_size = 128 end

	if data.raw.technology["bob-robot-tanks"] then data.raw.technology["bob-robot-tanks"].icon = "__ExtraChests__/graphics/icons/technology/drones-tanks.png" end
	if data.raw.technology["bob-robot-tanks"] then data.raw.technology["bob-robot-tanks"].icon_size = 128 end

 	if data.raw.technology["fusion-reactor-equipment"] then data.raw.technology["fusion-reactor-equipment"].icon = "__ExtraChests__/graphics/icons/technology/fusion-reactor-equipment-1.png" end

	if data.raw.technology["fusion-reactor-equipment-1"] then data.raw.technology["fusion-reactor-equipment-1"].icon = "__ExtraChests__/graphics/icons/technology/fusion-reactor-equipment-1.png" end
	if data.raw.technology["fusion-reactor-equipment-2"] then data.raw.technology["fusion-reactor-equipment-2"].icon = "__ExtraChests__/graphics/icons/technology/fusion-reactor-equipment-2.png" end
	if data.raw.technology["fusion-reactor-equipment-3"] then data.raw.technology["fusion-reactor-equipment-3"].icon = "__ExtraChests__/graphics/icons/technology/fusion-reactor-equipment-3.png" end
	if data.raw.technology["fusion-reactor-equipment-4"] then data.raw.technology["fusion-reactor-equipment-4"].icon = "__ExtraChests__/graphics/icons/technology/fusion-reactor-equipment-4.png" end

	if data.raw.technology["fusion-reactor-equipment"] then data.raw.technology["fusion-reactor-equipment"].icon_size = 128 end
	if data.raw.technology["fusion-reactor-equipment-1"] then data.raw.technology["fusion-reactor-equipment-1"].icon_size = 128 end
	if data.raw.technology["fusion-reactor-equipment-2"] then data.raw.technology["fusion-reactor-equipment-2"].icon_size = 128 end
	if data.raw.technology["fusion-reactor-equipment-3"] then data.raw.technology["fusion-reactor-equipment-3"].icon_size = 128 end
	if data.raw.technology["fusion-reactor-equipment-4"] then data.raw.technology["fusion-reactor-equipment-4"].icon_size = 128 end






	if data.raw.technology["bob-tank-cannon-damage-1"] then data.raw.technology["bob-tank-cannon-damage-1"].icon = "__ExtraChests__/graphics/icons/technology/tank-cannon-damage.png" end
	if data.raw.technology["bob-tank-cannon-damage-2"] then data.raw.technology["bob-tank-cannon-damage-2"].icon = "__ExtraChests__/graphics/icons/technology/tank-cannon-damage.png" end
	if data.raw.technology["bob-tank-cannon-damage-3"] then data.raw.technology["bob-tank-cannon-damage-3"].icon = "__ExtraChests__/graphics/icons/technology/tank-cannon-damage.png" end
	if data.raw.technology["bob-tank-cannon-damage-4"] then data.raw.technology["bob-tank-cannon-damage-4"].icon = "__ExtraChests__/graphics/icons/technology/tank-cannon-damage.png" end
	if data.raw.technology["bob-tank-cannon-damage-5"] then data.raw.technology["bob-tank-cannon-damage-5"].icon = "__ExtraChests__/graphics/icons/technology/tank-cannon-damage.png" end
	if data.raw.technology["bob-tank-cannon-damage-6"] then data.raw.technology["bob-tank-cannon-damage-6"].icon = "__ExtraChests__/graphics/icons/technology/tank-cannon-damage.png" end

	if data.raw.technology["bob-tank-cannon-damage-1"] then data.raw.technology["bob-tank-cannon-damage-1"].icon_size = 128 end
	if data.raw.technology["bob-tank-cannon-damage-2"] then data.raw.technology["bob-tank-cannon-damage-2"].icon_size = 128 end
	if data.raw.technology["bob-tank-cannon-damage-3"] then data.raw.technology["bob-tank-cannon-damage-3"].icon_size = 128 end
	if data.raw.technology["bob-tank-cannon-damage-4"] then data.raw.technology["bob-tank-cannon-damage-4"].icon_size = 128 end
	if data.raw.technology["bob-tank-cannon-damage-5"] then data.raw.technology["bob-tank-cannon-damage-5"].icon_size = 128 end
	if data.raw.technology["bob-tank-cannon-damage-6"] then data.raw.technology["bob-tank-cannon-damage-6"].icon_size = 128 end



	if data.raw.technology["bob-tank-cannon-speed-1"] then data.raw.technology["bob-tank-cannon-speed-1"].icon = "__ExtraChests__/graphics/icons/technology/tank-cannon-speed.png" end
	if data.raw.technology["bob-tank-cannon-speed-2"] then data.raw.technology["bob-tank-cannon-speed-2"].icon = "__ExtraChests__/graphics/icons/technology/tank-cannon-speed.png" end
	if data.raw.technology["bob-tank-cannon-speed-3"] then data.raw.technology["bob-tank-cannon-speed-3"].icon = "__ExtraChests__/graphics/icons/technology/tank-cannon-speed.png" end
	if data.raw.technology["bob-tank-cannon-speed-4"] then data.raw.technology["bob-tank-cannon-speed-4"].icon = "__ExtraChests__/graphics/icons/technology/tank-cannon-speed.png" end
	if data.raw.technology["bob-tank-cannon-speed-5"] then data.raw.technology["bob-tank-cannon-speed-5"].icon = "__ExtraChests__/graphics/icons/technology/tank-cannon-speed.png" end
	if data.raw.technology["bob-tank-cannon-speed-6"] then data.raw.technology["bob-tank-cannon-speed-6"].icon = "__ExtraChests__/graphics/icons/technology/tank-cannon-speed.png" end

	if data.raw.technology["bob-tank-cannon-speed-1"] then data.raw.technology["bob-tank-cannon-speed-1"].icon_size = 128 end
	if data.raw.technology["bob-tank-cannon-speed-2"] then data.raw.technology["bob-tank-cannon-speed-2"].icon_size = 128 end
	if data.raw.technology["bob-tank-cannon-speed-3"] then data.raw.technology["bob-tank-cannon-speed-3"].icon_size = 128 end
	if data.raw.technology["bob-tank-cannon-speed-4"] then data.raw.technology["bob-tank-cannon-speed-4"].icon_size = 128 end
	if data.raw.technology["bob-tank-cannon-speed-5"] then data.raw.technology["bob-tank-cannon-speed-5"].icon_size = 128 end
	if data.raw.technology["bob-tank-cannon-speed-6"] then data.raw.technology["bob-tank-cannon-speed-6"].icon_size = 128 end



	if data.raw.technology["bob-tank-artillery-damage-1"] then data.raw.technology["bob-tank-artillery-damage-1"].icon = "__ExtraChests__/graphics/icons/technology/tank-artillery-damage.png" end
	if data.raw.technology["bob-tank-artillery-damage-2"] then data.raw.technology["bob-tank-artillery-damage-2"].icon = "__ExtraChests__/graphics/icons/technology/tank-artillery-damage.png" end
	if data.raw.technology["bob-tank-artillery-damage-3"] then data.raw.technology["bob-tank-artillery-damage-3"].icon = "__ExtraChests__/graphics/icons/technology/tank-artillery-damage.png" end
	if data.raw.technology["bob-tank-artillery-damage-4"] then data.raw.technology["bob-tank-artillery-damage-4"].icon = "__ExtraChests__/graphics/icons/technology/tank-artillery-damage.png" end
	if data.raw.technology["bob-tank-artillery-damage-5"] then data.raw.technology["bob-tank-artillery-damage-5"].icon = "__ExtraChests__/graphics/icons/technology/tank-artillery-damage.png" end
	if data.raw.technology["bob-tank-artillery-damage-6"] then data.raw.technology["bob-tank-artillery-damage-6"].icon = "__ExtraChests__/graphics/icons/technology/tank-artillery-damage.png" end

	if data.raw.technology["bob-tank-artillery-damage-1"] then data.raw.technology["bob-tank-artillery-damage-1"].icon_size = 128 end
	if data.raw.technology["bob-tank-artillery-damage-2"] then data.raw.technology["bob-tank-artillery-damage-2"].icon_size = 128 end
	if data.raw.technology["bob-tank-artillery-damage-3"] then data.raw.technology["bob-tank-artillery-damage-3"].icon_size = 128 end
	if data.raw.technology["bob-tank-artillery-damage-4"] then data.raw.technology["bob-tank-artillery-damage-4"].icon_size = 128 end
	if data.raw.technology["bob-tank-artillery-damage-5"] then data.raw.technology["bob-tank-artillery-damage-5"].icon_size = 128 end
	if data.raw.technology["bob-tank-artillery-damage-6"] then data.raw.technology["bob-tank-artillery-damage-6"].icon_size = 128 end



	if data.raw.technology["bob-tank-artillery-speed-1"] then data.raw.technology["bob-tank-artillery-speed-1"].icon = "__ExtraChests__/graphics/icons/technology/tank-artillery-speed.png" end
	if data.raw.technology["bob-tank-artillery-speed-2"] then data.raw.technology["bob-tank-artillery-speed-2"].icon = "__ExtraChests__/graphics/icons/technology/tank-artillery-speed.png" end
	if data.raw.technology["bob-tank-artillery-speed-3"] then data.raw.technology["bob-tank-artillery-speed-3"].icon = "__ExtraChests__/graphics/icons/technology/tank-artillery-speed.png" end
	if data.raw.technology["bob-tank-artillery-speed-4"] then data.raw.technology["bob-tank-artillery-speed-4"].icon = "__ExtraChests__/graphics/icons/technology/tank-artillery-speed.png" end
	if data.raw.technology["bob-tank-artillery-speed-5"] then data.raw.technology["bob-tank-artillery-speed-5"].icon = "__ExtraChests__/graphics/icons/technology/tank-artillery-speed.png" end
	if data.raw.technology["bob-tank-artillery-speed-6"] then data.raw.technology["bob-tank-artillery-speed-6"].icon = "__ExtraChests__/graphics/icons/technology/tank-artillery-speed.png" end

	if data.raw.technology["bob-tank-artillery-speed-1"] then data.raw.technology["bob-tank-artillery-speed-1"].icon_size = 128 end
	if data.raw.technology["bob-tank-artillery-speed-2"] then data.raw.technology["bob-tank-artillery-speed-2"].icon_size = 128 end
	if data.raw.technology["bob-tank-artillery-speed-3"] then data.raw.technology["bob-tank-artillery-speed-3"].icon_size = 128 end
	if data.raw.technology["bob-tank-artillery-speed-4"] then data.raw.technology["bob-tank-artillery-speed-4"].icon_size = 128 end
	if data.raw.technology["bob-tank-artillery-speed-5"] then data.raw.technology["bob-tank-artillery-speed-5"].icon_size = 128 end
	if data.raw.technology["bob-tank-artillery-speed-6"] then data.raw.technology["bob-tank-artillery-speed-6"].icon_size = 128 end




 	if data.raw.technology["battery-equipment"]   then data.raw.technology["battery-equipment"].icon = "__ExtraChests__/graphics/icons/technology/battery-equipment-1.png" end
	if data.raw.technology["battery-equipment"] then data.raw.technology["battery-equipment"].icon_size = 128 end
	if data.raw.technology["battery-mk2-equipment"] then data.raw.technology["battery-mk2-equipment"].icon = "__ExtraChests__/graphics/icons/technology/battery-equipment-2.png" end
	if data.raw.technology["battery-mk2-equipment"] then data.raw.technology["battery-mk2-equipment"].icon_size = 128 end


	if data.raw.technology["battery-equipment-1"] then data.raw.technology["battery-equipment-1"].icon = "__ExtraChests__/graphics/icons/technology/battery-equipment-1.png" end
	if data.raw.technology["battery-equipment-2"] then data.raw.technology["battery-equipment-2"].icon = "__ExtraChests__/graphics/icons/technology/battery-equipment-2.png" end
	if data.raw.technology["battery-equipment-3"] then data.raw.technology["battery-equipment-3"].icon = "__ExtraChests__/graphics/icons/technology/battery-equipment-3.png" end
	if data.raw.technology["battery-equipment-4"] then data.raw.technology["battery-equipment-4"].icon = "__ExtraChests__/graphics/icons/technology/battery-equipment-4.png" end
	if data.raw.technology["battery-equipment-5"] then data.raw.technology["battery-equipment-5"].icon = "__ExtraChests__/graphics/icons/technology/battery-equipment-5.png" end
	if data.raw.technology["battery-equipment-6"] then data.raw.technology["battery-equipment-6"].icon = "__ExtraChests__/graphics/icons/technology/battery-equipment-6.png" end

	if data.raw.technology["battery-equipment-1"] then data.raw.technology["battery-equipment-1"].icon_size = 128 end
	if data.raw.technology["battery-equipment-2"] then data.raw.technology["battery-equipment-2"].icon_size = 128 end
	if data.raw.technology["battery-equipment-3"] then data.raw.technology["battery-equipment-3"].icon_size = 128 end
	if data.raw.technology["battery-equipment-4"] then data.raw.technology["battery-equipment-4"].icon_size = 128 end
	if data.raw.technology["battery-equipment-5"] then data.raw.technology["battery-equipment-5"].icon_size = 128 end
	if data.raw.technology["battery-equipment-6"] then data.raw.technology["battery-equipment-6"].icon_size = 128 end



	if data.raw.technology["advanced-research"] then data.raw.technology["advanced-research"].icon = "__ExtraChests__/graphics/icons/technology/advanced-research.png" end
	if data.raw.technology["advanced-research"] then data.raw.technology["advanced-research"].icon_size = 128 end



	if data.raw.technology["more-inserters-1"] then data.raw.technology["more-inserters-1"].icon = "__ExtraChests__/graphics/icons/technology/inserters-smart-more.png" end
	if data.raw.technology["more-inserters-2"] then data.raw.technology["more-inserters-2"].icon = "__ExtraChests__/graphics/icons/technology/inserters-express-more.png" end
	if data.raw.technology["near-inserters-1"] then data.raw.technology["near-inserters-1"].icon = "__ExtraChests__/graphics/icons/technology/inserters-fast-short.png" end
	if data.raw.technology["near-inserters-2"] then data.raw.technology["near-inserters-2"].icon = "__ExtraChests__/graphics/icons/technology/inserters-smart-short.png" end
	if data.raw.technology["near-inserters-3"] then data.raw.technology["near-inserters-3"].icon = "__ExtraChests__/graphics/icons/technology/inserters-express-short.png" end
	if data.raw.technology["long-burner-inserter"] then data.raw.technology["long-burner-inserter"].icon = "__ExtraChests__/graphics/icons/technology/inserters-burner-long.png" end
	if data.raw.technology["long-inserters-1"] then data.raw.technology["long-inserters-1"].icon = "__ExtraChests__/graphics/icons/technology/inserters-fast-long.png" end
	if data.raw.technology["long-inserters-2"] then data.raw.technology["long-inserters-2"].icon = "__ExtraChests__/graphics/icons/technology/inserters-smart-long.png" end
	if data.raw.technology["long-inserters-3"] then data.raw.technology["long-inserters-3"].icon = "__ExtraChests__/graphics/icons/technology/inserters-express-long.png" end
	if data.raw.technology["purple-inserters"] then data.raw.technology["purple-inserters"].icon = "__ExtraChests__/graphics/icons/technology/inserters-express.png" end
	if data.raw.technology["fast-smart-inserters"] then data.raw.technology["fast-smart-inserters"].icon = "__ExtraChests__/graphics/icons/technology/inserters-smart-express.png" end

	if data.raw.technology["more-inserters-1"] then data.raw.technology["more-inserters-1"].icon_size = 128 end
	if data.raw.technology["more-inserters-2"] then data.raw.technology["more-inserters-2"].icon_size = 128 end
	if data.raw.technology["near-inserters-1"] then data.raw.technology["near-inserters-1"].icon_size = 128 end
	if data.raw.technology["near-inserters-2"] then data.raw.technology["near-inserters-2"].icon_size = 128 end
	if data.raw.technology["near-inserters-3"] then data.raw.technology["near-inserters-3"].icon_size = 128 end
	if data.raw.technology["long-burner-inserter"] then data.raw.technology["long-burner-inserter"].icon_size = 128 end
	if data.raw.technology["long-inserters-1"] then data.raw.technology["long-inserters-1"].icon_size = 128 end
	if data.raw.technology["long-inserters-2"] then data.raw.technology["long-inserters-2"].icon_size = 128 end
	if data.raw.technology["long-inserters-3"] then data.raw.technology["long-inserters-3"].icon_size = 128 end
	if data.raw.technology["purple-inserters"] then data.raw.technology["purple-inserters"].icon_size = 128 end
	if data.raw.technology["fast-smart-inserters"] then data.raw.technology["fast-smart-inserters"].icon_size = 128 end



 	if data.raw.technology["electric-energy-distribution-2"] then data.raw.technology["electric-energy-distribution-2"].icon = "__ExtraChests__/graphics/icons/technology/electric-substation.png" end
	if data.raw.technology["electric-energy-distribution-2"] then data.raw.technology["electric-energy-distribution-2"].icon_size = 128 end

	if data.raw.technology["electric-substation-1"] then data.raw.technology["electric-substation-1"].icon = "__ExtraChests__/graphics/icons/technology/electric-substation.png" end
	if data.raw.technology["electric-substation-2"] then data.raw.technology["electric-substation-2"].icon = "__ExtraChests__/graphics/icons/technology/electric-substation.png" end
	if data.raw.technology["electric-substation-3"] then data.raw.technology["electric-substation-3"].icon = "__ExtraChests__/graphics/icons/technology/electric-substation.png" end
	if data.raw.technology["electric-substation-4"] then data.raw.technology["electric-substation-4"].icon = "__ExtraChests__/graphics/icons/technology/electric-substation.png" end

	if data.raw.technology["electric-substation-1"] then data.raw.technology["electric-substation-1"].icon_size = 128 end
	if data.raw.technology["electric-substation-2"] then data.raw.technology["electric-substation-2"].icon_size = 128 end
	if data.raw.technology["electric-substation-3"] then data.raw.technology["electric-substation-3"].icon_size = 128 end
	if data.raw.technology["electric-substation-4"] then data.raw.technology["electric-substation-4"].icon_size = 128 end



	if data.raw.technology["ceramics"] then data.raw.technology["ceramics"].icon = "__ExtraChests__/graphics/icons/technology/ceramics.png" end
	if data.raw.technology["ceramics"] then data.raw.technology["ceramics"].icon_size = 128 end


	if data.raw.technology["oil-processing"] then data.raw.technology["oil-processing"].icon = "__ExtraChests__/graphics/icons/technology/oil-processing.png" end
	if data.raw.technology["oil-processing"] then data.raw.technology["oil-processing"].icon_size = 128 end


 	if data.raw.technology["module-merging"] then data.raw.technology["module-merging"].icon = "__ExtraChests__/graphics/icons/technology/modules-2.png" end
	if data.raw.technology["module-merging"] then data.raw.technology["module-merging"].icon_size = 128 end


	if data.raw.technology["modules"]   then data.raw.technology["modules"].icon = "__ExtraChests__/graphics/icons/technology/modules.png" end
	if data.raw.technology["modules-2"] then data.raw.technology["modules-2"].icon = "__ExtraChests__/graphics/icons/technology/modules-2.png" end
	if data.raw.technology["modules"] then data.raw.technology["modules"].icon_size = 128 end
	if data.raw.technology["modules-2"] then data.raw.technology["modules-2"].icon_size = 128 end


--      if data.raw.technology[""] then data.raw.technology[""].icon = "__ExtraChests__/graphics/icons/technology/.png" end    
--      if data.raw.technology[""] then data.raw.technology[""].icon = "__ExtraChests__/graphics/icons/technology/.png" end  
--      if data.raw.technology[""] then data.raw.technology[""].icon = "__ExtraChests__/graphics/icons/technology/.png" end  
--      
--      
--      if data.raw.technology[""] then data.raw.technology[""].icon_size = 128 end    
--      if data.raw.technology[""] then data.raw.technology[""].icon_size = 128 end  
--      if data.raw.technology[""] then data.raw.technology[""].icon_size = 128 end  




end												   




--------------------------------------------
-------- GROUPS update ---------------------
--------------------------------------------


--       ========== LOGISTIC ===========


if data.raw["item-subgroup"]["addon-purple-inserter"] then
	if data.raw.item["purple-inserter"] then data.raw.item["purple-inserter"].subgroup = "addon-purple-inserter" end 
	if data.raw.item["purple-near-inserter"] then data.raw.item["purple-near-inserter"].subgroup = "addon-purple-inserter" end 
	if data.raw.item["purple-far-inserter"] then data.raw.item["purple-far-inserter"].subgroup  = "addon-purple-inserter" end 
	if data.raw.item["purple-short-far-inserter"] then data.raw.item["purple-short-far-inserter"].subgroup  = "addon-purple-inserter" end 
	if data.raw.item["purple-short-long-inserter"] then data.raw.item["purple-short-long-inserter"].subgroup  = "addon-purple-inserter" end 
	if data.raw.item["purple-long-near-inserter"] then data.raw.item["purple-long-near-inserter"].subgroup   = "addon-purple-inserter" end 
	if data.raw.item["purple-long-short-inserter"] then data.raw.item["purple-long-short-inserter"].subgroup  = "addon-purple-inserter" end 
	if data.raw.item["purple-long-inserter"]	 then data.raw.item["purple-long-inserter"].subgroup	  = "addon-purple-inserter" end 
end
       


if data.raw["item-subgroup"]["belt"] then
	if data.raw.item["green-transport-belt"] then data.raw.item["green-transport-belt"].subgroup = "belt" end 
	if data.raw.item["purple-transport-belt"] then data.raw.item["purple-transport-belt"].subgroup = "belt" end 
end

if data.raw.item["green-transport-belt"] then data.raw.item["green-transport-belt"].order = "a[transport-belt]-d[green-transport-belt]" end 
if data.raw.item["purple-transport-belt"] then data.raw.item["purple-transport-belt"].order = "a[transport-belt]-e[purple-transport-belt]" end 


if data.raw["item-subgroup"]["addon-underground-belts"] then
	if data.raw.item["basic-transport-belt-to-ground"] then data.raw.item["basic-transport-belt-to-ground"].subgroup = "addon-underground-belts" end 
	if data.raw.item["fast-transport-belt-to-ground"]  then data.raw.item["fast-transport-belt-to-ground"].subgroup = "addon-underground-belts" end 
	if data.raw.item["express-transport-belt-to-ground"] then data.raw.item["express-transport-belt-to-ground"].subgroup = "addon-underground-belts" end 
	if data.raw.item["green-transport-belt-to-ground"] then data.raw.item["green-transport-belt-to-ground"].subgroup = "addon-underground-belts" end 
	if data.raw.item["purple-transport-belt-to-ground"]  then data.raw.item["purple-transport-belt-to-ground"].subgroup = "addon-underground-belts" end 
end



if data.raw.item["green-transport-belt-to-ground"] then data.raw.item["green-transport-belt-to-ground"].order = "b[transport-belt-to-ground]-d[green-transport-belt-to-ground]" end 
if data.raw.item["purple-transport-belt-to-ground"] then data.raw.item["purple-transport-belt-to-ground"].order = "b[transport-belt-to-ground]-e[purple-transport-belt-to-ground]" end 


if data.raw["item-subgroup"]["addon-splitters"] then
	if data.raw.item["basic-splitter"] then data.raw.item["basic-splitter"].subgroup = "addon-splitters" end 
	if data.raw.item["fast-splitter"] then data.raw.item["fast-splitter"].subgroup = "addon-splitters" end 
	if data.raw.item["express-splitter"] then data.raw.item["express-splitter"].subgroup = "addon-splitters" end 

	if data.raw.item["green-splitter"] then data.raw.item["green-splitter"].subgroup = "addon-splitters" end 
	if data.raw.item["purple-splitter"] then data.raw.item["purple-splitter"].subgroup = "addon-splitters" end 
end

if data.raw.item["green-splitter"] then data.raw.item["green-splitter"].order = "c[splitter]-d[green-splitter]" end 
if data.raw.item["purple-splitter"] then data.raw.item["purple-splitter"].order = "c[splitter]-e[purple-splitter]" end 


if data.raw["item-subgroup"]["addon-energy-substation"] then
	if data.raw.item["substation"] then data.raw.item["substation"].subgroup = "addon-energy-substation" end 
	if data.raw.item["substation-2"] then data.raw.item["substation-2"].subgroup = "addon-energy-substation" end 
	if data.raw.item["substation-3"] then data.raw.item["substation-3"].subgroup = "addon-energy-substation" end 
	if data.raw.item["substation-4"] then data.raw.item["substation-4"].subgroup = "addon-energy-substation" end 
end



--data.raw.item["straight-rail"].subgroup = "addon-energy-substation"
--data.raw.item["curved-rail"].subgroup = "addon-energy-substation"
--data.raw.item["train-stop"].subgroup = "addon-energy-substation"
--data.raw.item["rail-signal"].subgroup = "addon-energy-substation"
--data.raw.item["rail-chain-signal"].subgroup = "addon-energy-substation"
if data.raw.item["rail-chain-signal"] then data.raw.item["rail-chain-signal"].order = "a[train-system]-e[arail-signal-chain]" end 


if data.raw.item["diesel-locomotive"] then data.raw.item["diesel-locomotive"].subgroup = "addon-trains" end 
if data.raw.item["diesel-locomotive"] then data.raw.item["diesel-locomotive"].order = "a[train-system]-e[diesel-locomotive-1]" end 
if data.raw.item["diesel-locomotive-2"] then data.raw.item["diesel-locomotive-2"].subgroup = "addon-trains" end 
if data.raw.item["diesel-locomotive-3"] then data.raw.item["diesel-locomotive-3"].subgroup = "addon-trains" end 
if data.raw.item["armoured-diesel-locomotive"] then data.raw.item["armoured-diesel-locomotive"].subgroup = "addon-trains" end 
if data.raw.item["cargo-wagon"] then data.raw.item["cargo-wagon"].subgroup = "addon-trains" end 
if data.raw.item["cargo-wagon"] then data.raw.item["cargo-wagon"].order = "a[train-system]-f[cargo-wagon-1]" end 
if data.raw.item["cargo-wagon-2"]  then data.raw.item["cargo-wagon-2"].subgroup = "addon-trains" end 
if data.raw.item["cargo-wagon-3"]  then data.raw.item["cargo-wagon-3"].subgroup = "addon-trains" end 
if data.raw.item["armoured-cargo-wagon"] then data.raw.item["armoured-cargo-wagon"].subgroup = "addon-trains" end 


if data.raw.item["car"] then data.raw.item["car"].subgroup = "addon-cars-tanks" end 
if data.raw.item["tank"] then data.raw.item["tank"].subgroup = "addon-cars-tanks" end 
if data.raw.item["tank-2"] then data.raw.item["tank-2"].subgroup = "addon-cars-tanks" end 
if data.raw.item["tank-3"] then data.raw.item["tank-3"].subgroup = "addon-cars-tanks" end 
if data.raw.item["bob-robot-tank"] then data.raw.item["bob-robot-tank"].subgroup = "addon-cars-tanks" end 


if data.raw.item["landfill2by2"] then data.raw.item["landfill2by2"].subgroup = "addon-energy-substation" end 
if data.raw.item["landfill4by4"] then data.raw.item["landfill4by4"].subgroup = "addon-energy-substation" end 
if data.raw.item["water-be-gone"]  then data.raw.item["water-be-gone"].subgroup = "addon-energy-substation" end 
if data.raw.item["water-bomb"] then data.raw.item["water-bomb"].subgroup = "addon-energy-substation" end 
if data.raw.item["water-bomb"] then data.raw.item["water-bomb"].order = "cd[landfill]" end 

if data.raw["item-subgroup"]["bob-electronic-components"] then
	if data.raw.item["copper-cable"] then data.raw.item["copper-cable"].subgroup = "bob-electronic-components" end 
	if data.raw.item["copper-cable"] then data.raw.item["copper-cable"].order = "0-a0[tinned-copper-cable]" end 

	if data.raw.item["red-wire"] then data.raw.item["red-wire"].subgroup = "bob-electronic-components" end 
	if data.raw.item["red-wire"] then data.raw.item["red-wire"].order = "0-a3a[red-wire]" end 

	if data.raw.item["green-wire"] then data.raw.item["green-wire"].subgroup = "bob-electronic-components" end 
	if data.raw.item["green-wire"] then data.raw.item["green-wire"].order = "0-a3b[green-wire]" end 
end


--       ========== BOBS LOGISTIC ===========

if data.raw["item-subgroup"]["bob-pump"] then
	if data.raw.item["small-pump"] then data.raw.item["small-pump"].subgroup = "bob-pump" end 
	if data.raw.item["small-pump"] then data.raw.item["small-pump"].order = "a[small-pump]" end 
end

if data.raw["item-subgroup"]["bob-storage"] then
	if data.raw.item["storage-tank"] then data.raw.item["storage-tank"].subgroup = "bob-storage" end 
	if data.raw.item["storage-tank"] then data.raw.item["storage-tank"].order = "b[fluid]-a[storage-tank-1]" end 
end


if upgrade_tank_capacity and data.raw["storage-tank"]["storage-tank-2"] then
	data.raw["storage-tank"]["storage-tank-2"]["fluid_box"]["base_area"] = 500
	data.raw["storage-tank"]["storage-tank-3"]["fluid_box"]["base_area"] = 1000
	data.raw["storage-tank"]["storage-tank-4"]["fluid_box"]["base_area"] = 2500
end


if data.raw["item-subgroup"]["addon-robots-frame"] then
	if data.raw.item["flying-robot-frame"] then  data.raw.item["flying-robot-frame"].subgroup = "addon-robots-frame"	      end
	if data.raw.item["flying-robot-frame-2"]  then  data.raw.item["flying-robot-frame-2"].subgroup = "addon-robots-frame"     end
	if data.raw.item["flying-robot-frame-3"]  then  data.raw.item["flying-robot-frame-3"].subgroup = "addon-robots-frame"     end
	if data.raw.item["flying-robot-frame-4"]  then  data.raw.item["flying-robot-frame-4"].subgroup = "addon-robots-frame"     end

	if data.raw.item["logistic-robot"] then  data.raw.item["logistic-robot"].subgroup = "addon-logistic-robots"		       end
	if data.raw.item["bob-logistic-robot-2"]  then  data.raw.item["bob-logistic-robot-2"].subgroup = "addon-logistic-robots"   end
	if data.raw.item["bob-logistic-robot-3"]  then  data.raw.item["bob-logistic-robot-3"].subgroup = "addon-logistic-robots"   end
	if data.raw.item["bob-logistic-robot-4"]  then  data.raw.item["bob-logistic-robot-4"].subgroup = "addon-logistic-robots"   end

	if data.raw.item["construction-robot"] then  data.raw.item["construction-robot"].subgroup = "addon-construction-robots"		 end
	if data.raw.item["bob-construction-robot-2"] then  data.raw.item["bob-construction-robot-2"].subgroup = "addon-construction-robots"	 end
	if data.raw.item["bob-construction-robot-3"] then  data.raw.item["bob-construction-robot-3"].subgroup = "addon-construction-robots"	 end
	if data.raw.item["bob-construction-robot-4"] then  data.raw.item["bob-construction-robot-4"].subgroup = "addon-construction-robots"	 end


	if data.raw.item["roboport"] then  data.raw.item["roboport"].subgroup = "addon-roboports"		   end
	if data.raw.item["bob-roboport-2"] then  data.raw.item["bob-roboport-2"].subgroup = "addon-roboports"  end
	if data.raw.item["bob-roboport-3"] then  data.raw.item["bob-roboport-3"].subgroup = "addon-roboports"  end
	if data.raw.item["bob-roboport-4"] then  data.raw.item["bob-roboport-4"].subgroup = "addon-roboports"  end

	if data.raw.item["bob-robo-charge-port"]  then  data.raw.item["bob-robo-charge-port"].subgroup = "addon-roboports"	    end
	if data.raw.item["bob-robo-charge-port-2"]  then  data.raw.item["bob-robo-charge-port-2"].subgroup = "addon-roboports"  end
	if data.raw.item["bob-robo-charge-port-3"]  then  data.raw.item["bob-robo-charge-port-3"].subgroup = "addon-roboports"  end
	if data.raw.item["bob-robo-charge-port-4"]  then  data.raw.item["bob-robo-charge-port-4"].subgroup = "addon-roboports"  end

	if data.raw.item["bob-logistic-zone-expander"] then  data.raw.item["bob-logistic-zone-expander"].subgroup = "addon-expander"       end
	if data.raw.item["bob-logistic-zone-expander-2"] then  data.raw.item["bob-logistic-zone-expander-2"].subgroup = "addon-expander"   end
	if data.raw.item["bob-logistic-zone-expander-3"] then  data.raw.item["bob-logistic-zone-expander-3"].subgroup = "addon-expander"   end
	if data.raw.item["bob-logistic-zone-expander-4"] then  data.raw.item["bob-logistic-zone-expander-4"].subgroup = "addon-expander"   end

	if data.raw.item["bob-robo-charge-port-large"] then  data.raw.item["bob-robo-charge-port-large"].subgroup = "addon-expander"      end
	if data.raw.item["bob-robo-charge-port-large-2"] then  data.raw.item["bob-robo-charge-port-large-2"].subgroup = "addon-expander"  end
	if data.raw.item["bob-robo-charge-port-large-3"] then  data.raw.item["bob-robo-charge-port-large-3"].subgroup = "addon-expander"  end
	if data.raw.item["bob-robo-charge-port-large-4"] then  data.raw.item["bob-robo-charge-port-large-4"].subgroup = "addon-expander"  end


	if data.raw.item["bob-robochest"] then  data.raw.item["bob-robochest"].subgroup = "addon-robochests"	end
	if data.raw.item["bob-robochest-2"] then  data.raw.item["bob-robochest-2"].subgroup = "addon-robochests"	end
	if data.raw.item["bob-robochest-3"] then  data.raw.item["bob-robochest-3"].subgroup = "addon-robochests"	end
	if data.raw.item["bob-robochest-4"] then  data.raw.item["bob-robochest-4"].subgroup = "addon-robochests"	end

end


if data.raw.item["bob-robo-charge-port"] then  data.raw.item["bob-robo-charge-port"].order = "c[signal]-b[robo-charge-port-a-1]"	 end
if data.raw.item["bob-robo-charge-port-2"] then  data.raw.item["bob-robo-charge-port-2"].order = "c[signal]-b[robo-charge-port-a-1]" end
if data.raw.item["bob-robo-charge-port-3"] then  data.raw.item["bob-robo-charge-port-3"].order = "c[signal]-b[robo-charge-port-a-1]" end
if data.raw.item["bob-robo-charge-port-4"] then  data.raw.item["bob-robo-charge-port-4"].order = "c[signal]-b[robo-charge-port-a-1]" end


if data.raw["item-subgroup"]["addon-pump-jacks"] then
	if data.raw.item["offshore-pump"] then  data.raw.item["offshore-pump"].subgroup = "addon-pump-jacks"     end
	if data.raw.item["pumpjack"] then  data.raw.item["pumpjack"].subgroup = "addon-pump-jacks"		     end
	if data.raw.item["bob-pumpjack-1"] then  data.raw.item["bob-pumpjack-1"].subgroup = "addon-pump-jacks"   end
	if data.raw.item["bob-pumpjack-2"] then  data.raw.item["bob-pumpjack-2"].subgroup = "addon-pump-jacks"   end
	if data.raw.item["bob-pumpjack-3"] then  data.raw.item["bob-pumpjack-3"].subgroup = "addon-pump-jacks"   end
	if data.raw.item["bob-pumpjack-4"] then  data.raw.item["bob-pumpjack-4"].subgroup = "addon-pump-jacks"   end
	if data.raw.item["oil-refinery"] then data.raw.item["oil-refinery"].subgroup = "addon-pump-jacks" end 
end
if data.raw.item["oil-refinery"] then data.raw.item["oil-refinery"].order = "z[oil-refinery]" end 



--       ========== PRODUCTION ===========

if data.raw["repair-tool"]["repair-pack"] then data.raw["repair-tool"]["repair-pack"].order = "0[repair]-a[repair-pack]" end 

if data.raw.item["small-lamp"] then data.raw.item["small-lamp"].order = "a[light]-a[small-lamp]" end 


if data.raw["deconstruction-item"]["upgrade-planner"] then data.raw["deconstruction-item"]["upgrade-planner"].subgroup = "energy" end
if data.raw["deconstruction-item"]["deconstruction-planner"]  then data.raw["deconstruction-item"]["deconstruction-planner"].subgroup = "energy" end


if data.raw["blueprint"] then data.raw["blueprint"]["blueprint"].subgroup = "energy" end 


if data.raw["item-subgroup"]["addon-chemical-machine"] then
	if data.raw.item["chemical-furnace"] then data.raw.item["chemical-furnace"].subgroup = "addon-chemical-machine" end 
	if data.raw.item["chemical-boiler"] then data.raw.item["chemical-boiler"].subgroup = "addon-chemical-machine" end 
	if data.raw.item["electric-chemical-mixing-furnace"] then data.raw.item["electric-chemical-mixing-furnace"].subgroup = "addon-chemical-machine" end 
	if data.raw.item["electric-chemical-mixing-furnace-2"] then data.raw.item["electric-chemical-mixing-furnace-2"].subgroup = "addon-chemical-machine" end 
end



if data.raw.item["lab"] then data.raw.item["lab"].order = "g[lab-1]" end
if data.raw.item["lab-2"] then data.raw.item["lab-2"].order = "g[lab-2]" end
if data.raw.item["lab-module"] then data.raw.item["lab-module"].order = "g[lab-3]" end
if data.raw.item["lab-alien"] then data.raw.item["lab-alien"].order = "g[lab-4]" end


if data.raw.item["turret-probe"] then
	data.raw.item["turret-probe"].subgroup = "energy"
	data.raw.item["turret-probe"].order = "a[turret-probe]"
end

if data.raw.item["resource-monitor"] then
	data.raw.item["resource-monitor"].subgroup = "energy"
	data.raw.item["resource-monitor"].order = "b[resource-monitor]"
end


if data.raw.item["pipe-cleaner"] then
	data.raw.item["pipe-cleaner"].subgroup = "energy"
	data.raw.item["pipe-cleaner"].order = "c[pipe-cleaner]"
end

if data.raw.item["burner-generator"] then
	data.raw.item["burner-generator"].subgroup = "energy"
	data.raw.item["burner-generator"].order = "d[burner-generator]"
end

if data.raw.item["OilSteamBoiler"] then
	data.raw.item["OilSteamBoiler"].subgroup = "energy"
	data.raw.item["OilSteamBoiler"].order = "e[OilSteamBoiler]"
end

if data.raw.item["reverse-factory"] then
	data.raw.item["reverse-factory"].subgroup = "energy"
	data.raw.item["reverse-factory"].order = "f[reverse-factory]"
end






--       ========== MODULES ===========

--data.raw.tool["module-case"].subgroup = "addon-modules2"
--data.raw.item["module-contact"].subgroup = "addon-modules2"
--data.raw.tool["module-circuit-board"].subgroup = "addon-modules2"


if data.raw.item["module-processor-board"] then data.raw.item["module-processor-board"].subgroup = "addon-modules1" end 
if data.raw.item["module-processor-board-2"] then data.raw.item["module-processor-board-2"].subgroup = "addon-modules1" end 
if data.raw.item["module-processor-board-3"] then data.raw.item["module-processor-board-3"].subgroup = "addon-modules1" end 

if data.raw.tool["speed-processor"] then data.raw.tool["speed-processor"].subgroup = "addon-modules1" end 
if data.raw.item["speed-processor-2"] then data.raw.item["speed-processor-2"].subgroup = "addon-modules1" end 
if data.raw.item["speed-processor-3"] then data.raw.item["speed-processor-3"].subgroup = "addon-modules1" end 

if data.raw.tool["effectivity-processor"]  then data.raw.tool["effectivity-processor"].subgroup = "addon-modules1" end 
if data.raw.item["effectivity-processor-2"]  then data.raw.item["effectivity-processor-2"].subgroup = "addon-modules1" end 
if data.raw.item["effectivity-processor-3"]  then data.raw.item["effectivity-processor-3"].subgroup = "addon-modules1" end 



if data.raw.tool["productivity-processor"] then data.raw.tool["productivity-processor"].subgroup = "addon-modules2" end 
if data.raw.item["productivity-processor-2"] then data.raw.item["productivity-processor-2"].subgroup = "addon-modules2" end 
if data.raw.item["productivity-processor-3"] then data.raw.item["productivity-processor-3"].subgroup = "addon-modules2" end 

if data.raw.tool["pollution-clean-processor"] then data.raw.tool["pollution-clean-processor"].subgroup = "addon-modules2" end 
if data.raw.item["pollution-clean-processor-2"] then data.raw.item["pollution-clean-processor-2"].subgroup = "addon-modules2" end 
if data.raw.item["pollution-clean-processor-3"] then data.raw.item["pollution-clean-processor-3"].subgroup = "addon-modules2" end 

if data.raw.tool["pollution-create-processor"] then data.raw.tool["pollution-create-processor"].subgroup = "addon-modules2" end 
if data.raw.item["pollution-create-processor-2"] then data.raw.item["pollution-create-processor-2"].subgroup = "addon-modules2" end 
if data.raw.item["pollution-create-processor-3"] then data.raw.item["pollution-create-processor-3"].subgroup = "addon-modules2" end 


--       ========== INTERMEDIATES ===========


if data.raw.recipe["iron-stick"]  then data.raw.recipe["iron-stick"].subgroup = "addon-engines" end  
if data.raw.recipe["engine-unit"]  then data.raw.recipe["engine-unit"].subgroup = "addon-engines" end  
if data.raw.recipe["electric-engine-unit"]  then data.raw.recipe["electric-engine-unit"].subgroup = "addon-engines" end  

if data.raw.recipe["iron-stick"]  then data.raw.recipe["iron-stick"].order = "a" end  
if data.raw.recipe["engine-unit"]  then data.raw.recipe["engine-unit"].order = "b" end  
if data.raw.recipe["electric-engine-unit"]  then data.raw.recipe["electric-engine-unit"].order = "c" end  

if data.raw.item["iron-stick"]  then data.raw.item["iron-stick"].subgroup = "addon-engines" end  
if data.raw.item["engine-unit"]  then data.raw.item["engine-unit"].subgroup = "addon-engines" end  
if data.raw.item["electric-engine-unit"]  then data.raw.item["electric-engine-unit"].subgroup = "addon-engines" end  

if data.raw.item["iron-stick"]  then data.raw.item["iron-stick"].order = "a" end  
if data.raw.item["engine-unit"]  then data.raw.item["engine-unit"].order = "b" end  
if data.raw.item["electric-engine-unit"]  then data.raw.item["electric-engine-unit"].order = "c" end  

if data.raw.item["low-density-structure"]  then data.raw.item["low-density-structure"].subgroup = "addon-rocket-parts" end  
if data.raw.item["rocket-fuel"]  then data.raw.item["rocket-fuel"].subgroup = "addon-rocket-parts" end  
if data.raw.item["rocket-control-unit"]  then data.raw.item["rocket-control-unit"].subgroup = "addon-rocket-parts" end  
if data.raw.item["rocket-part"]  then data.raw.item["rocket-part"].subgroup = "addon-rocket-parts" end  
if data.raw.item["satellite"]  then data.raw.item["satellite"].subgroup = "addon-rocket-parts" end  

if data.raw.item["low-density-structure"]  then data.raw.item["low-density-structure"].order = "z-a[low-density-structure]" end  
if data.raw.item["rocket-fuel"]  then data.raw.item["rocket-fuel"].order = "z-b[rocket-fuel]" end  
if data.raw.item["rocket-control-unit"]  then data.raw.item["rocket-control-unit"].order = "z-c[rocket-control-unit]" end  
if data.raw.item["rocket-part"]  then data.raw.item["rocket-part"].order = "z-d[rocket-part]" end  
if data.raw.item["satellite"]  then data.raw.item["satellite"].order = "z-e[satellite]" end  

--data.raw.recipe["low-density-structure"].order = "z-a[low-density-structure]"
--data.raw.recipe["rocket-fuel"].order = "z-b[rocket-fuel]"
--data.raw.recipe["rocket-control-unit"].order = "z-c[rocket-control-unit]"
--data.raw.recipe["rocket-part"].order = "z-d[rocket-part]"
--data.raw.recipe["satellite"].order = "z-e[satellite]"


--       ========== FLUIDS ===========

if data.raw["item-subgroup"]["addon-petrol-fluids"] then
	if data.raw.recipe["basic-oil-processing"]  then data.raw.recipe["basic-oil-processing"].subgroup = "addon-petrol-fluids" end  
	if data.raw.recipe["advanced-oil-processing"]  then data.raw.recipe["advanced-oil-processing"].subgroup = "addon-petrol-fluids" end  
	if data.raw.recipe["bob-oil-processing"]  then data.raw.recipe["bob-oil-processing"].subgroup = "addon-petrol-fluids" end  

	if data.raw.recipe["heavy-oil-cracking"]  then data.raw.recipe["heavy-oil-cracking"].subgroup = "addon-petrol-fluids" end  
	if data.raw.recipe["light-oil-cracking"]  then data.raw.recipe["light-oil-cracking"].subgroup = "addon-petrol-fluids" end  
	if data.raw.recipe["coal-cracking"]  then data.raw.recipe["coal-cracking"].subgroup = "addon-petrol-fluids" end  
	if data.raw.recipe["petroleum-gas-cracking"]  then data.raw.recipe["petroleum-gas-cracking"].subgroup = "addon-petrol-fluids" end  
	if data.raw.recipe["lubricant"]  then data.raw.recipe["lubricant"].subgroup = "addon-petrol-fluids" end  
	if data.raw.recipe["liquid-fuel"]  then data.raw.recipe["liquid-fuel"].subgroup = "addon-petrol-fluids" end  
end



if data.raw.recipe["coal-cracking"]  then data.raw.recipe["coal-cracking"].order = "b[fluid-chemistry]-a[cracking1]" end  
if data.raw.recipe["heavy-oil-cracking"]  then data.raw.recipe["heavy-oil-cracking"].order = "b[fluid-chemistry]-a[cracking2]" end  
if data.raw.recipe["light-oil-cracking"]  then data.raw.recipe["light-oil-cracking"].order = "b[fluid-chemistry]-a[cracking3]" end  
if data.raw.recipe["petroleum-gas-cracking"]  then data.raw.recipe["petroleum-gas-cracking"].order = "b[fluid-chemistry]-a[cracking4]" end  


if data.raw.recipe["lubricant"]  then data.raw.recipe["lubricant"].order = "c[fluid-chemistry]-b1[lubricant]" end  
if data.raw.recipe["liquid-fuel"]  then data.raw.recipe["liquid-fuel"].order = "c[fluid-chemistry]-b2[liquid-fuel]" end  

if data.raw.recipe["burn-crude-oil"] and  data.raw["item-subgroup"]["addon-fuels-fluids"] then
	data.raw.recipe["burn-crude-oil"].subgroup = "addon-fuels-fluids"
	data.raw.recipe["burn-heavy-oil"].subgroup = "addon-fuels-fluids"
	data.raw.recipe["burn-light-oil"].subgroup = "addon-fuels-fluids"
	data.raw.item["crude-oil-barrel"].subgroup = "bob-barrel"
end




if data.raw["item-subgroup"]["addon-sulfur-fluids"] then
	if data.raw.recipe["sulfuric-acid"]  then data.raw.recipe["sulfuric-acid"].subgroup = "addon-sulfur-fluids" end  
	if data.raw.recipe["sulfuric-acid-2"]  then data.raw.recipe["sulfuric-acid-2"].subgroup = "addon-sulfur-fluids" end  
end


if data.raw.recipe["sulfuric-acid"]  then data.raw.recipe["sulfuric-acid"].order = "a[sulfur2]" end  
if data.raw.recipe["sulfuric-acid-2"]  then data.raw.recipe["sulfuric-acid-2"].order = "a[sulfur3]" end  


if data.raw["item-subgroup"]["addon-chloride-fluids"] then
	if data.raw.recipe["salt-water-electrolysis"]  then data.raw.recipe["salt-water-electrolysis"].subgroup = "addon-chloride-fluids" end  
	if data.raw.recipe["hydrogen-chloride"]  then data.raw.recipe["hydrogen-chloride"].subgroup = "addon-chloride-fluids" end  
	if data.raw.recipe["tungstic-acid"]  then data.raw.recipe["tungstic-acid"].subgroup = "addon-chloride-fluids" end  
	if data.raw.recipe["ferric-chloride-solution"]  then data.raw.recipe["ferric-chloride-solution"].subgroup = "addon-chloride-fluids" end  

	if data.raw.recipe["salt-water-electrolysis"]  then data.raw.recipe["salt-water-electrolysis"].subgroup = "addon-chloride-fluids" end  
	if data.raw.recipe["hydrogen-chloride"]  then data.raw.recipe["hydrogen-chloride"].subgroup = "addon-chloride-fluids" end  
	if data.raw.recipe["tungstic-acid"]  then data.raw.recipe["tungstic-acid"].subgroup = "addon-chloride-fluids" end  
	if data.raw.recipe["ferric-chloride-solution"]  then data.raw.recipe["ferric-chloride-solution"].subgroup = "addon-chloride-fluids" end  
end



if data.raw.recipe["salt-water-electrolysis"]  then data.raw.recipe["salt-water-electrolysis"].order = "a[chlorine1]" end  
if data.raw.recipe["hydrogen-chloride"]  then data.raw.recipe["hydrogen-chloride"].order = "a[chlorine2]" end  
if data.raw.recipe["tungstic-acid"]  then data.raw.recipe["tungstic-acid"].order = "a[chlorine3]" end  
if data.raw.recipe["ferric-chloride-solution"]  then data.raw.recipe["ferric-chloride-solution"].order = "a[chlorine4]" end  



if data.raw["item-subgroup"]["addon-nitrogen-fluids"] then
	if data.raw.recipe["nitrogen"]  then data.raw.recipe["nitrogen"].subgroup = "addon-nitrogen-fluids" end  
	if data.raw.recipe["nitrogen-dioxide"]  then data.raw.recipe["nitrogen-dioxide"].subgroup = "addon-nitrogen-fluids" end  
	if data.raw.recipe["nitric-acid"]  then data.raw.recipe["nitric-acid"].subgroup = "addon-nitrogen-fluids" end  
	if data.raw.recipe["sulfuric-nitric-acid"]  then data.raw.recipe["sulfuric-nitric-acid"].subgroup = "addon-nitrogen-fluids" end  
	if data.raw.recipe["nitroglycerin"]  then data.raw.recipe["nitroglycerin"].subgroup = "addon-nitrogen-fluids" end  
	if data.raw.recipe["glycerol"]  then data.raw.recipe["glycerol"].subgroup = "addon-nitrogen-fluids" end  
end


if data.raw.recipe["nitrogen"]  then data.raw.recipe["nitrogen"].order = "a[nitrogen1]" end  
if data.raw.recipe["nitrogen-dioxide"]  then data.raw.recipe["nitrogen-dioxide"].order = "a[nitrogen2]" end  
if data.raw.recipe["nitric-acid"]  then data.raw.recipe["nitric-acid"].order = "a[nitrogen3]" end  
if data.raw.recipe["sulfuric-nitric-acid"]  then data.raw.recipe["sulfuric-nitric-acid"].order = "a[nitrogen4]" end  
if data.raw.recipe["nitroglycerin"]  then data.raw.recipe["nitroglycerin"].order = "a[nitrogen5]" end  
if data.raw.recipe["glycerol"]  then data.raw.recipe["glycerol"].order = "a[nitrogen6]" end  


if data.raw["item-subgroup"]["addon-fuels-fluids"] then
	if data.raw.recipe["solid-fuel-from-light-oil"]  then data.raw.recipe["solid-fuel-from-light-oil"].subgroup = "addon-fuels-fluids" end  
	if data.raw.recipe["solid-fuel-from-petroleum-gas"]  then data.raw.recipe["solid-fuel-from-petroleum-gas"].subgroup = "addon-fuels-fluids" end  
	if data.raw.recipe["solid-fuel-from-heavy-oil"]  then data.raw.recipe["solid-fuel-from-heavy-oil"].subgroup = "addon-fuels-fluids" end  
	if data.raw.recipe["solid-fuel-from-hydrogen"]  then data.raw.recipe["solid-fuel-from-hydrogen"].subgroup = "addon-fuels-fluids" end  
end



if data.raw.recipe["solid-fuel-from-heavy-oil"]  then data.raw.recipe["solid-fuel-from-heavy-oil"].order = "a[solid1]" end  
if data.raw.recipe["solid-fuel-from-light-oil"]  then data.raw.recipe["solid-fuel-from-light-oil"].order = "a[solid2]" end  
if data.raw.recipe["solid-fuel-from-petroleum-gas"]  then data.raw.recipe["solid-fuel-from-petroleum-gas"].order = "a[solid3]" end  
if data.raw.recipe["solid-fuel-from-hydrogen"]  then data.raw.recipe["solid-fuel-from-hydrogen"].order = "a[solid4]" end  



if data.raw["item-subgroup"]["addon-loading-bottles"] then
	if data.raw.recipe["hydrogen-canister"]  then data.raw.recipe["hydrogen-canister"].subgroup = "addon-loading-bottles" end  
	if data.raw.recipe["oxygen-canister"]  then data.raw.recipe["oxygen-canister"].subgroup = "addon-loading-bottles" end  
	if data.raw.recipe["nitrogen-canister"]  then data.raw.recipe["nitrogen-canister"].subgroup = "addon-loading-bottles" end  
	if data.raw.recipe["chlorine-canister"]  then data.raw.recipe["chlorine-canister"].subgroup = "addon-loading-bottles" end  
	if data.raw.recipe["hydrogen-chloride-canister"]  then data.raw.recipe["hydrogen-chloride-canister"].subgroup = "addon-loading-bottles" end  
	if data.raw.recipe["petroleum-gas-canister"]  then data.raw.recipe["petroleum-gas-canister"].subgroup = "addon-loading-bottles" end  
end



if data.raw["item-subgroup"]["addon-empty-bottles"] then
	if data.raw.recipe["empty-hydrogen-canister"]  then data.raw.recipe["empty-hydrogen-canister"].subgroup = "addon-empty-bottles" end  
	if data.raw.recipe["empty-oxygen-canister"]  then data.raw.recipe["empty-oxygen-canister"].subgroup = "addon-empty-bottles" end  
	if data.raw.recipe["empty-nitrogen-canister"]  then data.raw.recipe["empty-nitrogen-canister"].subgroup = "addon-empty-bottles" end  
	if data.raw.recipe["empty-chlorine-canister"]  then data.raw.recipe["empty-chlorine-canister"].subgroup = "addon-empty-bottles" end  
	if data.raw.recipe["empty-hydrogen-chloride-canister"]  then data.raw.recipe["empty-hydrogen-chloride-canister"].subgroup = "addon-empty-bottles" end  
	if data.raw.recipe["empty-petroleum-gas-canister"]  then data.raw.recipe["empty-petroleum-gas-canister"].subgroup = "addon-empty-bottles" end  
end



if data.raw["item-subgroup"]["addon-loading-barrels"] then
	if data.raw.recipe["fill-crude-oil-barrel"]  then data.raw.recipe["fill-crude-oil-barrel"].subgroup = "addon-loading-barrels" end  
	if data.raw.recipe["fill-crude-oil-barrel"]  then data.raw.recipe["fill-crude-oil-barrel"].order = "a[crude-oil-barrel]" end  
	if data.raw.recipe["bob-fill-crude-oil-barrel"]  then data.raw.recipe["bob-fill-crude-oil-barrel"].subgroup = "addon-loading-barrels" end  
	if data.raw.recipe["fill-heavy-oil-barrel"]  then data.raw.recipe["fill-heavy-oil-barrel"].subgroup = "addon-loading-barrels" end  
	if data.raw.recipe["fill-light-oil-barrel"]  then data.raw.recipe["fill-light-oil-barrel"].subgroup = "addon-loading-barrels" end  
	if data.raw.recipe["fill-lubricant-barrel"]  then data.raw.recipe["fill-lubricant-barrel"].subgroup = "addon-loading-barrels" end  
	if data.raw.recipe["fill-sulfuric-acid-barrel"]  then data.raw.recipe["fill-sulfuric-acid-barrel"].subgroup = "addon-loading-barrels" end  

	if data.raw.recipe["liquid-fuel-canister"]  then data.raw.recipe["liquid-fuel-canister"].subgroup = "addon-loading-barrels" end  
	if data.raw.recipe["ferric-chloride-canister"]  then data.raw.recipe["ferric-chloride-canister"].subgroup = "addon-loading-barrels" end  
end


if data.raw.recipe["liquid-fuel-canister"]  then data.raw.recipe["liquid-fuel-canister"].order = "d[liquid-fuel-canister]" end  
if data.raw.recipe["ferric-chloride-canister"]  then data.raw.recipe["ferric-chloride-canister"].order = "d[ferric-chloride-canister]" end  


if data.raw["item-subgroup"]["addon-empty-barrels"] then
	if data.raw.recipe["empty-crude-oil-barrel"]  then data.raw.recipe["empty-crude-oil-barrel"].subgroup = "addon-empty-barrels" end  
	if data.raw.recipe["bob-empty-crude-oil-barrel"]  then data.raw.recipe["bob-empty-crude-oil-barrel"].subgroup = "addon-empty-barrels" end  
	if data.raw.recipe["empty-heavy-oil-barrel"]  then data.raw.recipe["empty-heavy-oil-barrel"].subgroup = "addon-empty-barrels" end  
	if data.raw.recipe["empty-light-oil-barrel"]  then data.raw.recipe["empty-light-oil-barrel"].subgroup = "addon-empty-barrels" end  
	if data.raw.recipe["empty-lubricant-barrel"]  then data.raw.recipe["empty-lubricant-barrel"].subgroup = "addon-empty-barrels" end  
	if data.raw.recipe["empty-sulfuric-acid-barrel"]  then data.raw.recipe["empty-sulfuric-acid-barrel"].subgroup = "addon-empty-barrels" end  
	if data.raw.recipe["empty-liquid-fuel-canister"]  then data.raw.recipe["empty-liquid-fuel-canister"].subgroup = "addon-empty-barrels" end  
	if data.raw.recipe["empty-ferric-chloride-canister"]  then data.raw.recipe["empty-ferric-chloride-canister"].subgroup = "addon-empty-barrels" end  
end

if data.raw.recipe["empty-crude-oil-barrel"]  then data.raw.recipe["empty-crude-oil-barrel"].order = "a[empty-crude-oil-barrel]" end  

if data.raw.recipe["empty-liquid-fuel-canister"]  then data.raw.recipe["empty-liquid-fuel-canister"].order = "d[empty-liquid-fuel-canister]" end  
if data.raw.recipe["empty-ferric-chloride-canister"]  then data.raw.recipe["empty-ferric-chloride-canister"].order = "d[empty-ferric-chloride-canister]" end  

if data.raw.item["ferric-chloride-canister"]  then data.raw.item["ferric-chloride-canister"].order = "z[ferric-chloride-canister]" end  
if data.raw.item["liquid-fuel-canister"]  then data.raw.item["liquid-fuel-canister"].order = "z[liquid-fuel-canister]" end  



--       ========== BOBS MATERIALS ===========

if data.raw["item-subgroup"]["bob-ores"] then
	if  data.raw.item["raw-wood"]  then  data.raw.item["raw-wood"].subgroup = "bob-ores" end 
	if  data.raw.item["coal"]  then  data.raw.item["coal"].subgroup = "bob-ores" end 
	if  data.raw.item["stone"]  then  data.raw.item["stone"].subgroup = "bob-ores" end 
	if  data.raw.item["iron-ore"]  then  data.raw.item["iron-ore"].subgroup = "bob-ores" end 
	if  data.raw.item["copper-ore"]  then  data.raw.item["copper-ore"].subgroup = "bob-ores" end 
end


 
if  data.raw.item["raw-wood"]  then  data.raw.item["raw-wood"].order = "a[base-ore1]" end 
if  data.raw.item["stone"]  then  data.raw.item["stone"].order = "a[base-ore2]" end 
if  data.raw.item["copper-ore"]  then  data.raw.item["copper-ore"].order = "a[base-ore3]" end 
if  data.raw.item["iron-ore"]  then  data.raw.item["iron-ore"].order = "a[base-ore4]" end 
if  data.raw.item["coal"]  then  data.raw.item["coal"].order = "a[base-ore5]" end 
 
 
if  data.raw.item["wood"] and data.raw["item-subgroup"]["bob-resource"] then  data.raw.item["wood"].subgroup = "bob-resource" end 
 
--data.raw.item["resin"].subgroup = "bob-resource"
--data.raw.recipe["bob-resin-wood"].order = "a[b-resin["

if data.raw["item-subgroup"]["bob-material"] then
	if  data.raw.item["iron-plate"] then  data.raw.item["iron-plate"].subgroup = "bob-material" end 
	if  data.raw.item["copper-plate"]  then  data.raw.item["copper-plate"].subgroup = "bob-material" end 
	if  data.raw.item["steel-plate"]  then  data.raw.item["steel-plate"].subgroup = "bob-material" end 

	if  data.raw.item["stone-brick"]  then  data.raw.item["stone-brick"].subgroup = "bob-material" end 
	if  data.raw.item["concrete"]  then  data.raw.item["concrete"].subgroup = "bob-material" end 
end

if  data.raw.item["wood"]  then  data.raw.item["wood"].order = "a[a-wood]" end 
if  data.raw.item["resin"]  then  data.raw.item["resin"].order = "a[b-resin]" end 
if  data.raw.recipe["bob-resin-oil"]  then  data.raw.recipe["bob-resin-oil"].order = "a[synthetic-wooda]" end 
if  data.raw.item["copper-plate"]  then  data.raw.item["copper-plate"].order = "a-a-a[copper-plate]" end 
if  data.raw.item["iron-plate"]  then  data.raw.item["iron-plate"].order = "a-a-b[iron-plate]" end 
if  data.raw.item["steel-plate"]  then  data.raw.item["steel-plate"].order = "a-a-c[steel-plate]" end 

if  data.raw.item["stone-brick"]  then  data.raw.item["stone-brick"].order = "a-a-d[iron-plate]" end 
if  data.raw.item["concrete"]  then  data.raw.item["concrete"].order = "a-a-e[steel-plate]" end 


--data.raw.item["polishing-compound"].subgroup = "bob-resource"
--data.raw.item["petroleum-jelly"].subgroup = "bob-resource"

if  data.raw.item["polishing-compound"]  then  data.raw.item["polishing-compound"].order = "z-a[polishing-compound]" end 
if  data.raw.item["petroleum-jelly"]  then  data.raw.item["petroleum-jelly"].order = "z-b[polishing-compound]" end 


if data.raw["item-subgroup"]["bob-resource-chemical"] then
	if  data.raw.item["sulfur"]  then  data.raw.item["sulfur"].subgroup = "bob-resource-chemical" end 
	if  data.raw.item["plastic-bar"]  then  data.raw.item["plastic-bar"].subgroup = "bob-resource-chemical" end 

	if  data.raw.item["sulfur"]  then  data.raw.item["sulfur"].order = "f[sulfur]" end 


	if  data.raw.item["silver-nitrate"]  then  data.raw.item["silver-nitrate"].subgroup = "bob-resource-chemical" end 
	if  data.raw.item["silver-oxide"]  then  data.raw.item["silver-oxide"].subgroup = "bob-resource-chemical" end 
	if  data.raw.recipe["silver-nitrate"]  then  data.raw.recipe["silver-nitrate"].subgroup = "bob-resource-chemical" end 
	if  data.raw.recipe["silver-oxide"]  then  data.raw.recipe["silver-oxide"].subgroup = "bob-resource-chemical" end 
end




if  data.raw.item["tin-plate"]  then  data.raw.item["tin-plate"].order = "a[a-a-tin-plate]" end 
if  data.raw.item["lead-plate"]  then  data.raw.item["lead-plate"].order = "a[a-b-lead-plate]" end 

if  data.raw.recipe["cobalt-oxide-from-copper"]  then  data.raw.recipe["cobalt-oxide-from-copper"].order = "a[a-a-cobalt-oxide-from-copper]" end 
if  data.raw.recipe["bob-lead-plate"]  then  data.raw.recipe["bob-lead-plate"].order = "a[a-b-bob-lead-plate]" end 
if  data.raw.recipe["silver-from-lead"]  then  data.raw.recipe["silver-from-lead"].order = "a[a-c-silver-from-lead]" end 

if  data.raw.item["aluminium-plate"]  then  data.raw.item["aluminium-plate"].order = "a[a-a-aluminium-plate]" end 
if  data.raw.item["zinc-plate"]  then  data.raw.item["zinc-plate"].order = "a[a-b-zinc-plate]" end 
if  data.raw.item["titanium-plate"]  then  data.raw.item["titanium-plate"].order = "a[a-d-titanium-plate]" end 


if  data.raw.item["bronze-alloy"]  then  data.raw.item["bronze-alloy"].order = "a[a-a-bronze-alloy]" end 
if  data.raw.item["brass-alloy"]  then  data.raw.item["brass-alloy"].order = "a[a-b-brass-alloy]" end 
if  data.raw.item["tungsten-plate"]  then  data.raw.item["tungsten-plate"].order = "a[a-c-tungsten-plate]" end 
if  data.raw.item["copper-tungsten-alloy"]  then  data.raw.item["copper-tungsten-alloy"].order = "a[a-d-copper-tungsten-alloy]" end 
if  data.raw.item["tungsten-carbide"]  then  data.raw.item["tungsten-carbide"].order = "a[a-e-tungsten-carbide]" end 
if  data.raw.recipe["tungsten-carbide-2"]  then  data.raw.recipe["tungsten-carbide-2"].order = "a[a-f-tungsten-carbide]" end 
if  data.raw.item["gunmetal-alloy"]  then  data.raw.item["gunmetal-alloy"].order = "a[a-h-gunmetal-alloy]" end 


--       ========== BOBS INTERMEDIATES ===========

if data.raw["item-subgroup"]["bob-intermediates"] then
	if  data.raw.item["battery"]  then  data.raw.item["battery"].subgroup = "bob-intermediates" end 
	if  data.raw.item["explosives"]  then  data.raw.item["explosives"].subgroup = "bob-intermediates" end 
end

if  data.raw.item["battery"]  then  data.raw.item["battery"].order = "a[battery1]" end 
if  data.raw.item["lithium-ion-battery"]  then  data.raw.item["lithium-ion-battery"].order = "a[battery2]" end 
if  data.raw.item["silver-zinc-battery"]  then  data.raw.item["silver-zinc-battery"].order = "a[battery3]" end 


if  data.raw.item["explosives"]  then  data.raw.item["explosives"].order = "z[explosives]" end 
	

if data.raw["item-subgroup"]["bob-gears"] then
	if  data.raw.item["iron-gear-wheel"] then  data.raw.item["iron-gear-wheel"].subgroup = "bob-gears" end 
end

if  data.raw.item["iron-gear-wheel"] then  data.raw.item["iron-gear-wheel"].order = "z[iron-gear-wheel]" end 

if  data.raw.item["gas-canister"]  then  data.raw.item["gas-canister"].subgroup = "barrel" end 
if  data.raw.item["empty-canister"]  then  data.raw.item["empty-canister"].subgroup = "barrel" end 
if  data.raw.recipe["gas-canister"]  then  data.raw.recipe["gas-canister"].subgroup = "barrel" end 
if  data.raw.recipe["empty-canister"]  then  data.raw.recipe["empty-canister"].subgroup = "barrel" end 



if data.raw["item-subgroup"]["addon-electronics"] then
	if  data.raw.item["solder"]  then  data.raw.item["solder"].subgroup = "addon-electronics" end 
	if  data.raw.item["basic-electronic-components"]  then  data.raw.item["basic-electronic-components"].subgroup = "addon-electronics" end 
	if  data.raw.item["electronic-components"]  then  data.raw.item["electronic-components"].subgroup = "addon-electronics" end 
	if  data.raw.item["intergrated-electronics"]  then  data.raw.item["intergrated-electronics"].subgroup = "addon-electronics" end 
	if  data.raw.item["processing-electronics"]  then  data.raw.item["processing-electronics"].subgroup = "addon-electronics" end 
end




if  data.raw["item-subgroup"]["addon-circuits"] then
	if  data.raw.item["electronic-circuit"]  then  data.raw.item["electronic-circuit"].subgroup = "addon-circuits" end 
	if  data.raw.item["advanced-circuit"]  then  data.raw.item["advanced-circuit"].subgroup = "addon-circuits" end 
	if  data.raw.item["processing-unit"]  then  data.raw.item["processing-unit"].subgroup = "addon-circuits" end 
	if  data.raw.item["advanced-processing-unit"]  then  data.raw.item["advanced-processing-unit"].subgroup = "addon-circuits" end 
end 


if data.raw["item-subgroup"]["addon-bearing-ball"] then
	if  data.raw.item["steel-bearing-ball"]  then  data.raw.item["steel-bearing-ball"].subgroup = "addon-bearing-ball" end 
	if  data.raw.item["titanium-bearing-ball"]  then  data.raw.item["titanium-bearing-ball"].subgroup = "addon-bearing-ball" end 
	if  data.raw.item["nitinol-bearing-ball"]  then  data.raw.item["nitinol-bearing-ball"].subgroup = "addon-bearing-ball" end 
	if  data.raw.item["ceramic-bearing-ball"]  then  data.raw.item["ceramic-bearing-ball"].subgroup = "addon-bearing-ball" end 
end



if data.raw["item-subgroup"]["addon-bullets"] then
	if  data.raw.item["bullet"]  then  data.raw.item["bullet"].subgroup = "addon-bullets" end 
	if  data.raw.item["acid-bullet"]  then  data.raw.item["acid-bullet"].subgroup = "addon-bullets" end 
	if  data.raw.item["ap-bullet"]  then  data.raw.item["ap-bullet"].subgroup = "addon-bullets" end 
	if  data.raw.item["flame-bullet"]  then  data.raw.item["flame-bullet"].subgroup = "addon-bullets" end 
	if  data.raw.item["he-bullet"]  then  data.raw.item["he-bullet"].subgroup = "addon-bullets" end 
	if  data.raw.item["impact-bullet"]  then  data.raw.item["impact-bullet"].subgroup = "addon-bullets" end 
	if  data.raw.item["poison-bullet"]  then  data.raw.item["poison-bullet"].subgroup = "addon-bullets" end 
end



if  data.raw.item["bullet"]  then  data.raw.item["bullet"].order = "a" end 

if data.raw["item-subgroup"]["addon-projectile"] then
	if  data.raw.item["bullet-projectile"]  then  data.raw.item["bullet-projectile"].subgroup = "addon-projectile" end 
	if  data.raw.item["acid-bullet-projectile"]  then  data.raw.item["acid-bullet-projectile"].subgroup = "addon-projectile" end 
	if  data.raw.item["ap-bullet-projectile"]  then  data.raw.item["ap-bullet-projectile"].subgroup = "addon-projectile" end 
	if  data.raw.item["flame-bullet-projectile"]  then  data.raw.item["flame-bullet-projectile"].subgroup = "addon-projectile" end 
	if  data.raw.item["he-bullet-projectile"]  then  data.raw.item["he-bullet-projectile"].subgroup = "addon-projectile" end 
	if  data.raw.item["impact-bullet-projectile"]  then  data.raw.item["impact-bullet-projectile"].subgroup = "addon-projectile" end 
	if  data.raw.item["poison-bullet-projectile"]  then  data.raw.item["poison-bullet-projectile"].subgroup = "addon-projectile" end 
end


if  data.raw.item["bullet-projectile"]  then  data.raw.item["bullet-projectile"].order = "a" end 

if data.raw["item-subgroup"]["addon-missile"] then
	if  data.raw.item["rocket-warhead"]  then  data.raw.item["rocket-warhead"].subgroup = "addon-missile" end 
	if  data.raw.item["acid-rocket-warhead"]  then  data.raw.item["acid-rocket-warhead"].subgroup = "addon-missile" end 
	if  data.raw.item["explosive-rocket-warhead"]  then  data.raw.item["explosive-rocket-warhead"].subgroup = "addon-missile" end 
	if  data.raw.item["flame-rocket-warhead"]  then  data.raw.item["flame-rocket-warhead"].subgroup = "addon-missile" end 
	if  data.raw.item["impact-rocket-warhead"]  then  data.raw.item["impact-rocket-warhead"].subgroup = "addon-missile" end 
	if  data.raw.item["piercing-rocket-warhead"]  then  data.raw.item["piercing-rocket-warhead"].subgroup = "addon-missile" end 
	if  data.raw.item["poison-rocket-warhead"]  then  data.raw.item["poison-rocket-warhead"].subgroup = "addon-missile" end 
end


if  data.raw.item["rocket-warhead"]  then  data.raw.item["rocket-warhead"].order = "a" end 
if  data.raw.item["acid-rocket-warhead"]  then  data.raw.item["acid-rocket-warhead"].order = "b" end 
if  data.raw.item["explosive-rocket-warhead"]  then  data.raw.item["explosive-rocket-warhead"].order = "c" end 
if  data.raw.item["flame-rocket-warhead"]  then  data.raw.item["flame-rocket-warhead"].order = "d" end 
if  data.raw.item["impact-rocket-warhead"]  then  data.raw.item["impact-rocket-warhead"].order = "e" end 
if  data.raw.item["piercing-rocket-warhead"]  then  data.raw.item["piercing-rocket-warhead"].order = "f" end 
if  data.raw.item["poison-rocket-warhead"]  then  data.raw.item["poison-rocket-warhead"].order = "g" end 



if data.raw["item-subgroup"]["addon-bullets"] then
	if  data.raw.recipe["bullet"]  then  data.raw.recipe["bullet"].subgroup = "addon-bullets" end 
	if  data.raw.recipe["acid-bullet"]  then  data.raw.recipe["acid-bullet"].subgroup = "addon-bullets" end 
	if  data.raw.recipe["ap-bullet"]  then  data.raw.recipe["ap-bullet"].subgroup = "addon-bullets" end 
	if  data.raw.recipe["flame-bullet"]  then  data.raw.recipe["flame-bullet"].subgroup = "addon-bullets" end 
	if  data.raw.recipe["he-bullet"]  then  data.raw.recipe["he-bullet"].subgroup = "addon-bullets" end 
	if  data.raw.recipe["impact-bullet"]  then  data.raw.recipe["impact-bullet"].subgroup = "addon-bullets" end 
	if  data.raw.recipe["poison-bullet"]  then  data.raw.recipe["poison-bullet"].subgroup = "addon-bullets" end 
end


if  data.raw.recipe["bullet"]  then  data.raw.recipe["bullet"].order = "a" end 

if data.raw["item-subgroup"]["addon-projectile"] then
	if  data.raw.recipe["bullet-projectile"]  then  data.raw.recipe["bullet-projectile"].subgroup = "addon-projectile" end 
	if  data.raw.recipe["acid-bullet-projectile"]  then  data.raw.recipe["acid-bullet-projectile"].subgroup = "addon-projectile" end 
	if  data.raw.recipe["ap-bullet-projectile"]  then  data.raw.recipe["ap-bullet-projectile"].subgroup = "addon-projectile" end 
	if  data.raw.recipe["flame-bullet-projectile"]  then  data.raw.recipe["flame-bullet-projectile"].subgroup = "addon-projectile" end 
	if  data.raw.recipe["he-bullet-projectile"]  then  data.raw.recipe["he-bullet-projectile"].subgroup = "addon-projectile" end 
	if  data.raw.recipe["impact-bullet-projectile"]  then  data.raw.recipe["impact-bullet-projectile"].subgroup = "addon-projectile" end 
	if  data.raw.recipe["poison-bullet-projectile"]  then  data.raw.recipe["poison-bullet-projectile"].subgroup = "addon-projectile" end 
end


if  data.raw.recipe["bullet-projectile"]  then  data.raw.recipe["bullet-projectile"].order = "a" end 

if data.raw["item-subgroup"]["addon-missile"] then
	if  data.raw.recipe["rocket-warhead"]  then  data.raw.recipe["rocket-warhead"].subgroup = "addon-missile" end 
	if  data.raw.recipe["acid-rocket-warhead"]  then  data.raw.recipe["acid-rocket-warhead"].subgroup = "addon-missile" end 
	if  data.raw.recipe["explosive-rocket-warhead"]  then  data.raw.recipe["explosive-rocket-warhead"].subgroup = "addon-missile" end 
	if  data.raw.recipe["flame-rocket-warhead"]  then  data.raw.recipe["flame-rocket-warhead"].subgroup = "addon-missile" end 
	if  data.raw.recipe["impact-rocket-warhead"]  then  data.raw.recipe["impact-rocket-warhead"].subgroup = "addon-missile" end 
	if  data.raw.recipe["piercing-rocket-warhead"]  then  data.raw.recipe["piercing-rocket-warhead"].subgroup = "addon-missile" end 
	if  data.raw.recipe["poison-rocket-warhead"]  then  data.raw.recipe["poison-rocket-warhead"].subgroup = "addon-missile" end 
end


if  data.raw.recipe["rocket-warhead"]  then  data.raw.recipe["rocket-warhead"].order = "a" end 
if  data.raw.recipe["acid-rocket-warhead"]  then  data.raw.recipe["acid-rocket-warhead"].order = "b" end 
if  data.raw.recipe["explosive-rocket-warhead"]  then  data.raw.recipe["explosive-rocket-warhead"].order = "c" end 
if  data.raw.recipe["flame-rocket-warhead"]  then  data.raw.recipe["flame-rocket-warhead"].order = "d" end 
if  data.raw.recipe["impact-rocket-warhead"]  then  data.raw.recipe["impact-rocket-warhead"].order = "e" end 
if  data.raw.recipe["piercing-rocket-warhead"]  then  data.raw.recipe["piercing-rocket-warhead"].order = "f" end 
if  data.raw.recipe["poison-rocket-warhead"]  then  data.raw.recipe["poison-rocket-warhead"].order = "g" end 





if data.raw["item-subgroup"]["addon-roboport-parts"] then
	if  data.raw.item["roboport-door-1"]  then  data.raw.item["roboport-door-1"].subgroup = "addon-roboport-parts" end 
	if  data.raw.item["roboport-door-2"]  then  data.raw.item["roboport-door-2"].subgroup = "addon-roboport-parts" end 
	if  data.raw.item["roboport-door-3"]  then  data.raw.item["roboport-door-3"].subgroup = "addon-roboport-parts" end 
	if  data.raw.item["roboport-door-4"]  then  data.raw.item["roboport-door-4"].subgroup = "addon-roboport-parts" end 
end




--       ========== ARMS ===========

if data.raw["item-subgroup"]["addon-mines"] then
	if data.raw.item["land-mine"]  then data.raw.item["land-mine"].subgroup = "addon-mines" end  
	if data.raw.item["poison-mine"]  then data.raw.item["poison-mine"].subgroup = "addon-mines" end  
	if data.raw.item["distractor-mine"]  then data.raw.item["distractor-mine"].subgroup = "addon-mines" end  
	if data.raw.item["slowdown-mine"]  then data.raw.item["slowdown-mine"].subgroup = "addon-mines" end  

	if data.raw.ammo["explosive-artillery-shell"]  then data.raw.ammo["explosive-artillery-shell"].subgroup = "addon-mines" end  
	if data.raw.capsule["basic-grenade"]  then data.raw.capsule["basic-grenade"].subgroup = "addon-mines" end  
	if data.raw.ammo["flame-thrower-ammo"]  then data.raw.ammo["flame-thrower-ammo"].subgroup = "addon-mines" end  
end

if  data.raw.item["land-mine"]  then  data.raw.item["land-mine"].order = "z-a" end 
if  data.raw.item["slowdown-mine"]  then  data.raw.item["slowdown-mine"].order = "z-b" end 
if  data.raw.item["poison-mine"]  then  data.raw.item["poison-mine"].order = "z-c" end 
if  data.raw.item["distractor-mine"]  then  data.raw.item["distractor-mine"].order = "z-d" end 

if data.raw.ammo["poison-artillery-shell"]  then data.raw.ammo["poison-artillery-shell"].subgroup = "capsule" end  
if data.raw.ammo["poison-artillery-shell"]  then data.raw.ammo["poison-artillery-shell"].order = "a[poison-artillery-shell]" end  




if data.raw["item-subgroup"]["addon-magazine"] then
	if data.raw.ammo["bullet-magazine"]  then data.raw.ammo["bullet-magazine"].subgroup = "addon-magazine" end  
	if data.raw.ammo["acid-bullet-magazine"]  then data.raw.ammo["acid-bullet-magazine"].subgroup = "addon-magazine" end  
	if data.raw.ammo["ap-bullet-magazine"]  then data.raw.ammo["ap-bullet-magazine"].subgroup = "addon-magazine" end  
	if data.raw.ammo["flame-bullet-magazine"]  then data.raw.ammo["flame-bullet-magazine"].subgroup = "addon-magazine" end  
	if data.raw.ammo["he-bullet-magazine"]  then data.raw.ammo["he-bullet-magazine"].subgroup = "addon-magazine" end  
	if data.raw.ammo["impact-bullet-magazine"]  then data.raw.ammo["impact-bullet-magazine"].subgroup = "addon-magazine" end  
	if data.raw.ammo["poison-bullet-magazine"]  then data.raw.ammo["poison-bullet-magazine"].subgroup = "addon-magazine" end  

	if data.raw.recipe["bullet-magazine"]  then data.raw.recipe["bullet-magazine"].subgroup = "addon-magazine" end  
	if data.raw.recipe["acid-bullet-magazine"]  then data.raw.recipe["acid-bullet-magazine"].subgroup = "addon-magazine" end  
	if data.raw.recipe["ap-bullet-magazine"]  then data.raw.recipe["ap-bullet-magazine"].subgroup = "addon-magazine" end  
	if data.raw.recipe["flame-bullet-magazine"]  then data.raw.recipe["flame-bullet-magazine"].subgroup = "addon-magazine" end  
	if data.raw.recipe["he-bullet-magazine"]  then data.raw.recipe["he-bullet-magazine"].subgroup = "addon-magazine" end  
	if data.raw.recipe["impact-bullet-magazine"]  then data.raw.recipe["impact-bullet-magazine"].subgroup = "addon-magazine" end  
	if data.raw.recipe["poison-bullet-magazine"]  then data.raw.recipe["poison-bullet-magazine"].subgroup = "addon-magazine" end  
end


if data.raw["item-subgroup"]["addon-shotgun"] then
	if data.raw.ammo["better-shotgun-shell"]  then data.raw.ammo["better-shotgun-shell"].subgroup = "addon-shotgun" end  
	if data.raw.ammo["shotgun-acid-shell"]  then data.raw.ammo["shotgun-acid-shell"].subgroup = "addon-shotgun" end  
	if data.raw.ammo["shotgun-ap-shell"]  then data.raw.ammo["shotgun-ap-shell"].subgroup = "addon-shotgun" end  
	if data.raw.ammo["shotgun-flame-shell"]  then data.raw.ammo["shotgun-flame-shell"].subgroup = "addon-shotgun" end  
	if data.raw.ammo["shotgun-explosive-shell"]  then data.raw.ammo["shotgun-explosive-shell"].subgroup = "addon-shotgun" end  
	if data.raw.ammo["shotgun-impact-shell"]  then data.raw.ammo["shotgun-impact-shell"].subgroup = "addon-shotgun" end  
	if data.raw.ammo["shotgun-poison-shell"]  then data.raw.ammo["shotgun-poison-shell"].subgroup = "addon-shotgun" end  

	if data.raw.recipe["better-shotgun-shell"]  then data.raw.recipe["better-shotgun-shell"].subgroup = "addon-shotgun" end  
	if data.raw.recipe["shotgun-ap-shell"]  then data.raw.recipe["shotgun-ap-shell"].subgroup = "addon-shotgun" end  
	if data.raw.recipe["shotgun-impact-shell"]  then data.raw.recipe["shotgun-impact-shell"].subgroup = "addon-shotgun" end  
	if data.raw.recipe["shotgun-explosive-shell"]  then data.raw.recipe["shotgun-explosive-shell"].subgroup = "addon-shotgun" end  
	if data.raw.recipe["shotgun-flame-shell"]  then data.raw.recipe["shotgun-flame-shell"].subgroup = "addon-shotgun" end  
	if data.raw.recipe["shotgun-acid-shell"]  then data.raw.recipe["shotgun-acid-shell"].subgroup = "addon-shotgun" end  
	if data.raw.recipe["shotgun-poison-shell"]  then data.raw.recipe["shotgun-poison-shell"].subgroup = "addon-shotgun" end  
end


if data.raw["item-subgroup"]["addon-rocket"] then
	if data.raw.ammo["bob-rocket"]  then data.raw.ammo["bob-rocket"].subgroup = "addon-rocket" end  
	if data.raw.ammo["bob-acid-rocket"]  then data.raw.ammo["bob-acid-rocket"].subgroup = "addon-rocket" end  
	if data.raw.ammo["bob-piercing-rocket"]  then data.raw.ammo["bob-piercing-rocket"].subgroup = "addon-rocket" end  
	if data.raw.ammo["bob-flame-rocket"]  then data.raw.ammo["bob-flame-rocket"].subgroup = "addon-rocket" end  
	if data.raw.ammo["bob-explosive-rocket"]  then data.raw.ammo["bob-explosive-rocket"].subgroup = "addon-rocket" end  
	if data.raw.ammo["bob-impact-rocket"]  then data.raw.ammo["bob-impact-rocket"].subgroup = "addon-rocket" end  
	if data.raw.ammo["bob-poison-rocket"]  then data.raw.ammo["bob-poison-rocket"].subgroup = "addon-rocket" end  

	if data.raw.recipe["bob-rocket"]  then data.raw.recipe["bob-rocket"].subgroup = "addon-rocket" end  
	if data.raw.recipe["bob-acid-rocket"]  then data.raw.recipe["bob-acid-rocket"].subgroup = "addon-rocket" end  
	if data.raw.recipe["bob-piercing-rocket"]  then data.raw.recipe["bob-piercing-rocket"].subgroup = "addon-rocket" end  
	if data.raw.recipe["bob-flame-rocket"]  then data.raw.recipe["bob-flame-rocket"].subgroup = "addon-rocket" end  
	if data.raw.recipe["bob-explosive-rocket"]  then data.raw.recipe["bob-explosive-rocket"].subgroup = "addon-rocket" end  
	if data.raw.recipe["bob-impact-rocket"]  then data.raw.recipe["bob-impact-rocket"].subgroup = "addon-rocket" end  
	if data.raw.recipe["bob-poison-rocket"]  then data.raw.recipe["bob-poison-rocket"].subgroup = "addon-rocket" end  
end


if data.raw["item-subgroup"]["addon-laser-rifle"] then
	if data.raw.ammo["laser-rifle-battery"]  then data.raw.ammo["laser-rifle-battery"].subgroup = "addon-laser-rifle" end  
	if data.raw.ammo["laser-rifle-battery-ruby"]  then data.raw.ammo["laser-rifle-battery-ruby"].subgroup = "addon-laser-rifle" end  
	if data.raw.ammo["laser-rifle-battery-sapphire"]  then data.raw.ammo["laser-rifle-battery-sapphire"].subgroup = "addon-laser-rifle" end  
	if data.raw.ammo["laser-rifle-battery-emerald"]  then data.raw.ammo["laser-rifle-battery-emerald"].subgroup = "addon-laser-rifle" end  
	if data.raw.ammo["laser-rifle-battery-amethyst"]  then data.raw.ammo["laser-rifle-battery-amethyst"].subgroup = "addon-laser-rifle" end  
	if data.raw.ammo["laser-rifle-battery-topaz"]  then data.raw.ammo["laser-rifle-battery-topaz"].subgroup = "addon-laser-rifle" end  
	if data.raw.ammo["laser-rifle-battery-diamond"]  then data.raw.ammo["laser-rifle-battery-diamond"].subgroup = "addon-laser-rifle" end  

	if data.raw.recipe["laser-rifle-battery"]  then data.raw.recipe["laser-rifle-battery"].subgroup = "addon-laser-rifle" end  
	if data.raw.recipe["laser-rifle-battery-ruby"]  then data.raw.recipe["laser-rifle-battery-ruby"].subgroup = "addon-laser-rifle" end  
	if data.raw.recipe["laser-rifle-battery-sapphire"]  then data.raw.recipe["laser-rifle-battery-sapphire"].subgroup = "addon-laser-rifle" end  
	if data.raw.recipe["laser-rifle-battery-emerald"]  then data.raw.recipe["laser-rifle-battery-emerald"].subgroup = "addon-laser-rifle" end  
	if data.raw.recipe["laser-rifle-battery-amethyst"]  then data.raw.recipe["laser-rifle-battery-amethyst"].subgroup = "addon-laser-rifle" end  
	if data.raw.recipe["laser-rifle-battery-topaz"]  then data.raw.recipe["laser-rifle-battery-topaz"].subgroup = "addon-laser-rifle" end  
	if data.raw.recipe["laser-rifle-battery-diamond"]  then data.raw.recipe["laser-rifle-battery-diamond"].subgroup = "addon-laser-rifle" end  
end



if data.raw.ammo["better-shotgun-shell"]  then data.raw.ammo["better-shotgun-shell"].order = "a" end  
if data.raw.ammo["shotgun-explosive-shell"]  then data.raw.ammo["shotgun-explosive-shell"].order = "f[shotgun-he-shell]" end  

if data.raw.ammo["bob-rocket"]  then data.raw.ammo["bob-rocket"].order = "a" end  
if data.raw.ammo["bob-acid-rocket"]  then data.raw.ammo["bob-acid-rocket"].order = "b" end  
if data.raw.ammo["bob-piercing-rocket"]  then data.raw.ammo["bob-piercing-rocket"].order = "c" end  
if data.raw.ammo["bob-flame-rocket"]  then data.raw.ammo["bob-flame-rocket"].order = "d" end  
if data.raw.ammo["bob-explosive-rocket"]  then data.raw.ammo["bob-explosive-rocket"].order = "e" end  
if data.raw.ammo["bob-impact-rocket"]  then data.raw.ammo["bob-impact-rocket"].order = "f" end  
if data.raw.ammo["bob-poison-rocket"]  then data.raw.ammo["bob-poison-rocket"].order = "g" end  



if data.raw.recipe["better-shotgun-shell"]  then data.raw.recipe["better-shotgun-shell"].order = "a" end  
if data.raw.recipe["shotgun-explosive-shell"]  then data.raw.recipe["shotgun-explosive-shell"].order = "f[shotgun-he-shell]" end  


if data.raw.recipe["bob-rocket"]  then data.raw.recipe["bob-rocket"].order = "a" end  
if data.raw.recipe["bob-acid-rocket"]  then data.raw.recipe["bob-acid-rocket"].order = "b" end  
if data.raw.recipe["bob-piercing-rocket"]  then data.raw.recipe["bob-piercing-rocket"].order = "c" end  
if data.raw.recipe["bob-flame-rocket"]  then data.raw.recipe["bob-flame-rocket"].order = "d" end  
if data.raw.recipe["bob-explosive-rocket"]  then data.raw.recipe["bob-explosive-rocket"].order = "e" end  
if data.raw.recipe["bob-impact-rocket"]  then data.raw.recipe["bob-impact-rocket"].order = "f" end  
if data.raw.recipe["bob-poison-rocket"]  then data.raw.recipe["bob-poison-rocket"].order = "g" end  


--data.raw.item["laser-bubble"].subgroup = "capsule"
--data.raw.item["laser-bubble"].order = "z[laser-bubble["
if data.raw.item["basic-electric-discharge-defense-equipment"]  then data.raw.item["basic-electric-discharge-defense-equipment"].subgroup = "capsule" end  
if data.raw.item["basic-electric-discharge-defense-equipment"]  then data.raw.item["basic-electric-discharge-defense-equipment"].order = "z[basic-electric-discharge-defense-equipment]" end  



if data.raw["item-subgroup"]["addon-equipment"] then
	if data.raw.item["fusion-reactor-equipment"]  then data.raw.item["fusion-reactor-equipment"].subgroup = "addon-equipment" end  
	if data.raw.item["fusion-reactor-equipment-2"]  then data.raw.item["fusion-reactor-equipment-2"].subgroup = "addon-equipment" end  
	if data.raw.item["fusion-reactor-equipment-3"]  then data.raw.item["fusion-reactor-equipment-3"].subgroup = "addon-equipment" end  
	if data.raw.item["fusion-reactor-equipment-4"]  then data.raw.item["fusion-reactor-equipment-4"].subgroup = "addon-equipment" end  

	if data.raw.item["energy-shield-equipment"]  then data.raw.item["energy-shield-equipment"].subgroup = "addon-equipment" end  
	if data.raw.item["energy-shield-mk2-equipment"]  then data.raw.item["energy-shield-mk2-equipment"].subgroup = "addon-equipment" end  
	if data.raw.item["energy-shield-mk3-equipment"]  then data.raw.item["energy-shield-mk3-equipment"].subgroup = "addon-equipment" end  
	if data.raw.item["energy-shield-mk4-equipment"]  then data.raw.item["energy-shield-mk4-equipment"].subgroup = "addon-equipment" end  
	if data.raw.item["energy-shield-mk5-equipment"]  then data.raw.item["energy-shield-mk5-equipment"].subgroup = "addon-equipment" end  
	if data.raw.item["energy-shield-mk6-equipment"]  then data.raw.item["energy-shield-mk6-equipment"].subgroup = "addon-equipment" end  
end



if data.raw.item["basic-laser-defense-equipment"]  then data.raw.item["basic-laser-defense-equipment"].subgroup = "addon-equipment2" end  
if data.raw.item["basic-laser-defense-equipment-2"]  then data.raw.item["basic-laser-defense-equipment-2"].subgroup = "addon-equipment2" end  
if data.raw.item["basic-laser-defense-equipment-3"]  then data.raw.item["basic-laser-defense-equipment-3"].subgroup = "addon-equipment2" end  
if data.raw.item["basic-laser-defense-equipment-4"]  then data.raw.item["basic-laser-defense-equipment-4"].subgroup = "addon-equipment2" end  
if data.raw.item["basic-laser-defense-equipment-5"]  then data.raw.item["basic-laser-defense-equipment-5"].subgroup = "addon-equipment2" end  
if data.raw.item["basic-laser-defense-equipment-6"]  then data.raw.item["basic-laser-defense-equipment-6"].subgroup = "addon-equipment2" end  

if data.raw.item["combat-robot-dispenser-equipment"]  then data.raw.item["combat-robot-dispenser-equipment"].subgroup = "addon-equipment2" end  
if data.raw.item["personal-roboport-equipment"]  then data.raw.item["personal-roboport-equipment"].subgroup = "addon-equipment2" end  

if data.raw.item["repair-module"] then
	data.raw.item["repair-module"].subgroup = "addon-equipment2"
	data.raw.item["repair-module"].order = "z[repair-module["
end
if data.raw.item["personal-roboport-equipment-off"] then
	data.raw.item["personal-roboport-equipment-off"].subgroup = "addon-equipment2"
	data.raw.item["personal-roboport-equipment-off"].order = "z[personal-roboport-equipment-off["
end



if data.raw["item-subgroup"]["addon-walls"] then
	if  data.raw.item["stone-wall"]  then  data.raw.item["stone-wall"].subgroup = "addon-walls" end 
	if  data.raw.item["gate"]  then  data.raw.item["gate"].subgroup = "addon-walls" end 
	if  data.raw.item["reinforced-wall"]  then  data.raw.item["reinforced-wall"].subgroup = "addon-walls" end 
	if  data.raw.item["reinforced-gate"]  then  data.raw.item["reinforced-gate"].subgroup = "addon-walls" end 

	if  data.raw.item["basic-exoskeleton-equipment"]  then  data.raw.item["basic-exoskeleton-equipment"].subgroup = "addon-walls" end 
	if  data.raw.item["basic-exoskeleton-equipment-2"]  then  data.raw.item["basic-exoskeleton-equipment-2"].subgroup = "addon-walls" end 
	if  data.raw.item["basic-exoskeleton-equipment-3"]  then  data.raw.item["basic-exoskeleton-equipment-3"].subgroup = "addon-walls" end 

	if  data.raw.item["night-vision-equipment"]  then  data.raw.item["night-vision-equipment"].subgroup = "addon-walls" end 
	if  data.raw.item["night-vision-equipment-2"]  then  data.raw.item["night-vision-equipment-2"].subgroup = "addon-walls" end 
	if  data.raw.item["night-vision-equipment-3"]  then  data.raw.item["night-vision-equipment-3"].subgroup = "addon-walls" end 
end

if data.raw.recipe["stone-wall"]  then data.raw.recipe["stone-wall"].order = "a-a" end  
if data.raw.recipe["gate"]  then data.raw.recipe["gate"].order = "a-b" end  
if data.raw.recipe["reinforced-wall"]  then data.raw.recipe["reinforced-wall"].order = "a-c" end  
if data.raw.recipe["reinforced-gate"]  then data.raw.recipe["reinforced-gate"].order = "a-d" end  




--data.raw[""][""].icon = ""
--data.raw[""][""][""]["filename"] = ""

--data.raw["item"][""].icon = ""

