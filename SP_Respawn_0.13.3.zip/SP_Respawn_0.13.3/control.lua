local inventory_indexes = 
{
	defines.inventory.player_main,
	defines.inventory.player_vehicle,
	defines.inventory.player_armor,
	defines.inventory.player_tools,
	defines.inventory.player_guns,
	defines.inventory.player_ammo,
	defines.inventory.player_quickbar,
	defines.inventory.player_trash
}


function CountTable(tbl)
	local i = 0
	
	for k, v in pairs(tbl) do
		i = i + 1
	end
	
	return i	
end

function ClearPlayerInventory(player)
	for i = 1, #inventory_indexes, 1 do
		local inv = player.get_inventory(i)
		if inv ~= nil and inv.valid then
			inv.clear()
		end
	end
end

function CreateRespawnSurface(player)
	if game.surfaces["Respawn_" .. player.index .. "_" .. player.name] == nil then
		
		game.create_surface("Respawn_" .. player.index .. "_" .. player.name, {
			terrain_segmentation = "low",
			water = "low",
			seed = 0,
			width = 1,
			height = 1,
			peaceful_mode = true
		})
		
	end
	
	return game.surfaces["Respawn_" .. player.index .. "_" .. player.name]
end

function CreateRespawnForce(player, respawnSurface)
	if game.forces["Respawn_" .. player.index .. "_" .. player.name] == nil then
		local force = game.create_force("Respawn_" .. player.index .. "_" .. player.name)
		
		force.disable_research()
		force.disable_all_prototypes()
		force.set_cease_fire("enemy", true)
		game.forces.enemy.set_cease_fire(force.name, true)
		force.set_spawn_position({0, 0}, respawnSurface.name)
	end
	
	return game.forces["Respawn_" .. player.index .. "_" .. player.name]
end

function on_pre_player_died(event)
	if CountTable(game.players) == 1 then
		local player = game.players[event.player_index]
		game.raise_event(defines.events.on_player_died, {player_index = player.index})
		
		local surface = CreateRespawnSurface(player)
		local force = CreateRespawnForce(player, surface)
		
		local oldForce = player.force.name
		local oldSurface = player.surface.name
		
		player.force = force
		player.teleport({0, 0}, surface.name)
		
		player.character.health = player.character.prototype.max_health
		player.character.active = false
		player.character.destructible = false
		player.character.operable = false
		
		global.respawnTimers[player.index] = {
			time = 600,
			character = player.character.name,
			oldForce = oldForce,
			oldSurface = oldSurface
		}
		
		player.minimap_enabled = false
		
		local gui = player.gui.center.add({type = "frame", name = "respawnFrame", caption = "You have died", direction = "vertical"})
		gui.add({type = "label", name = "respawnText", caption = "You will respawn in 10 seconds"})
	end
end

function on_tick()
	
	for index, timer in pairs(global.respawnTimers) do
		if timer.time > 0 then
			global.respawnTimers[index].time = global.respawnTimers[index].time - 1
			game.players[index].gui.center.respawnFrame.respawnText.caption = "You will respawn in " .. math.floor(global.respawnTimers[index].time / 60) .. " seconds"
		else
			local player = game.players[index]
			player.gui.center.respawnFrame.destroy()
			player.force = timer.oldForce
			
			local oldSurface = game.surfaces[timer.oldSurface]
			local respawnPos = oldSurface.find_non_colliding_position("player", player.force.get_spawn_position(oldSurface.name), 10, 1)
			
			player.teleport(respawnPos, oldSurface.name)
			
			ClearPlayerInventory(player)
			player.insert({name = "pistol", count = 1})
			player.insert({name = "firearm-magazine", count = 10})
			
			local enemies = player.surface.find_enemy_units(player.position, 50)
		
			for index, enemy in pairs(enemies) do
				enemy.destroy()
			end
			
			player.character.active = true
			player.character.rotatable = true
			player.character.destructible = true
			player.character.operable = true
		
			
			player.game_view_settings = 
			{
				showcontrollergui = true,
				showminimap = true,
				showresearchinfo = true,
				showentityinfo = true,
				showalertgui = true,
				updateentityselection = true
			}
			player.minimap_enabled = true
			
			player.print("You have respawned")
			game.raise_event(defines.events.on_player_respawned, {player_index = player.index, player_port = nil})
			
			global.respawnTimers[index] = nil
		end
	end
end

function on_init()
	if global.respawnTimers == nil then
		global.respawnTimers = {}
	end
end


script.on_init(on_init)
script.on_configuration_changed(on_init)
script.on_event(defines.events.on_pre_player_died, on_pre_player_died)
script.on_event(defines.events.on_tick, on_tick)