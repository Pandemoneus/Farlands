if turret_icons_new then

	addon_update_turret_tint("base","ammo-turret","gun-turret"	,addon_yellow_turret,addon_yellow_turret	,"__ShinyBob__/graphics/icons/warfare/gun-turret-1-new.png")
	addon_update_turret_tint("bobs","ammo-turret","bob-gun-turret-2",addon_yellow_turret,addon_red_turret		,"__ShinyBob__/graphics/icons/warfare/gun-turret-2-new.png")
	addon_update_turret_tint("bobs","ammo-turret","bob-gun-turret-3",addon_yellow_turret,addon_blue_turret		,"__ShinyBob__/graphics/icons/warfare/gun-turret-3-new.png")
	addon_update_turret_tint("bobs","ammo-turret","bob-gun-turret-4",addon_yellow_turret,addon_purple_turret	,"__ShinyBob__/graphics/icons/warfare/gun-turret-4-new.png")
	addon_update_turret_tint("bobs","ammo-turret","bob-gun-turret-5",addon_yellow_turret,addon_green_turret		,"__ShinyBob__/graphics/icons/warfare/gun-turret-5-new.png")


	addon_update_turret_tint("bobs","ammo-turret","bob-sniper-turret-1",addon_red_turret,addon_yellow_turret	,"__ShinyBob__/graphics/icons/warfare/sniper-turret-1-new.png")
	addon_update_turret_tint("bobs","ammo-turret","bob-sniper-turret-2",addon_red_turret,addon_red_turret		,"__ShinyBob__/graphics/icons/warfare/sniper-turret-2-new.png")
	addon_update_turret_tint("bobs","ammo-turret","bob-sniper-turret-3",addon_red_turret,addon_blue_turret		,"__ShinyBob__/graphics/icons/warfare/sniper-turret-3-new.png")


	addon_update_turret_tint("base","electric-turret","laser-turret"	,addon_blue_turret,addon_yellow_turret	,"__ShinyBob__/graphics/icons/warfare/laser-turret-1-new.png","bob-yellow-laser")
	addon_update_turret_tint("bobs","electric-turret","bob-laser-turret-2",addon_blue_turret,addon_red_turret	,"__ShinyBob__/graphics/icons/warfare/laser-turret-2-new.png","laser")
	addon_update_turret_tint("bobs","electric-turret","bob-laser-turret-3",addon_blue_turret,addon_blue_turret	,"__ShinyBob__/graphics/icons/warfare/laser-turret-3-new.png","bob-blue-laser")
	addon_update_turret_tint("bobs","electric-turret","bob-laser-turret-4",addon_blue_turret,addon_purple_turret	,"__ShinyBob__/graphics/icons/warfare/laser-turret-4-new.png","bob-purple-laser")
	addon_update_turret_tint("bobs","electric-turret","bob-laser-turret-5",addon_blue_turret,addon_green_turret	,"__ShinyBob__/graphics/icons/warfare/laser-turret-5-new.png","bob-green-laser")

else

	addon_update_turret_tint("base","ammo-turret","gun-turret"	,addon_yellow_turret,addon_yellow_turret	,"__ShinyBob__/graphics/icons/warfare/gun-turret-1.png")
	addon_update_turret_tint("bobs","ammo-turret","bob-gun-turret-2",addon_yellow_turret,addon_red_turret		,"__ShinyBob__/graphics/icons/warfare/gun-turret-2.png")
	addon_update_turret_tint("bobs","ammo-turret","bob-gun-turret-3",addon_yellow_turret,addon_blue_turret		,"__ShinyBob__/graphics/icons/warfare/gun-turret-3.png")
	addon_update_turret_tint("bobs","ammo-turret","bob-gun-turret-4",addon_yellow_turret,addon_purple_turret	,"__ShinyBob__/graphics/icons/warfare/gun-turret-4.png")
	addon_update_turret_tint("bobs","ammo-turret","bob-gun-turret-5",addon_yellow_turret,addon_green_turret		,"__ShinyBob__/graphics/icons/warfare/gun-turret-5.png")


	addon_update_turret_tint("bobs","ammo-turret","bob-sniper-turret-1",addon_red_turret,addon_yellow_turret	,"__ShinyBob__/graphics/icons/warfare/sniper-turret-1.png")
	addon_update_turret_tint("bobs","ammo-turret","bob-sniper-turret-2",addon_red_turret,addon_red_turret		,"__ShinyBob__/graphics/icons/warfare/sniper-turret-2.png")
	addon_update_turret_tint("bobs","ammo-turret","bob-sniper-turret-3",addon_red_turret,addon_blue_turret		,"__ShinyBob__/graphics/icons/warfare/sniper-turret-3.png")


	addon_update_turret_tint("base","electric-turret","laser-turret"	,addon_blue_turret,addon_yellow_turret	,"__ShinyBob__/graphics/icons/warfare/laser-turret-1.png","bob-yellow-laser")
	addon_update_turret_tint("bobs","electric-turret","bob-laser-turret-2",addon_blue_turret,addon_red_turret	,"__ShinyBob__/graphics/icons/warfare/laser-turret-2.png","laser")
	addon_update_turret_tint("bobs","electric-turret","bob-laser-turret-3",addon_blue_turret,addon_blue_turret	,"__ShinyBob__/graphics/icons/warfare/laser-turret-3.png","bob-blue-laser")
	addon_update_turret_tint("bobs","electric-turret","bob-laser-turret-4",addon_blue_turret,addon_purple_turret	,"__ShinyBob__/graphics/icons/warfare/laser-turret-4.png","bob-purple-laser")
	addon_update_turret_tint("bobs","electric-turret","bob-laser-turret-5",addon_blue_turret,addon_green_turret	,"__ShinyBob__/graphics/icons/warfare/laser-turret-5.png","bob-green-laser")


end
