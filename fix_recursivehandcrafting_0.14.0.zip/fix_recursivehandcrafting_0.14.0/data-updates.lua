-- Force wooden board alternatives to be created in assemblers

local function force_assembler(recipe)
	if data.raw.recipe[recipe] then
		data.raw.recipe[recipe].category = "advanced-crafting"
	end
end

local function force_electronics_assembler(recipe)
	if data.raw.recipe[recipe] then
		data.raw.recipe[recipe].category = "electronics-machine"
	end
end

local function force_chemical_plant(recipe)
	if data.raw.recipe[recipe] then
		data.raw.recipe[recipe].category = "chemistry"
	end
end

-- Bob's Plates
-- Synthetic wood from oil
force_electronics_assembler("wooden-board-synthetic")
force_chemical_plant("synthetic-wood")

-- Angel's Bioprocessing
force_assembler("wood-from-cellulose-resin")
force_assembler("wood-from-cellulose")
