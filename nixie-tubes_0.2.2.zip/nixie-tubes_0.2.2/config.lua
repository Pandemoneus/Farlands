debug_mode = false

refresh_rate = 2 --the rate, in times per second, that nixies update

