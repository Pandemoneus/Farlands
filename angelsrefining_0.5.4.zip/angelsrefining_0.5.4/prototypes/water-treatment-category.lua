data:extend(
{
  {
    type = "recipe-category",
    name = "angels-barreling",
  },
  {
    type = "recipe-category",
    name = "water-treatment",
  },
  {
    type = "recipe-category",
    name = "salination-plant",
  },
  {
    type = "recipe-category",
    name = "angels-water-void",
  },
--WATER TREATMENT
  {
    type = "item-group",
    name = "water-treatment",
    order = "la",
    inventory_order = "la",
    icon = "__angelsrefining__/graphics/item-group/water-treatment-group.png",
  },
  {
    type = "item-subgroup",
    name = "water-treatment",
    group = "water-treatment",
    order = "a",
  },
  {
    type = "item-subgroup",
    name = "water-cleaning",
    group = "water-treatment",
    order = "b",
  },
  {
    type = "item-subgroup",
    name = "water-salination",
    group = "water-treatment",
    order = "c",
  },
  {
    type = "item-subgroup",
    name = "water-treatment-building",
    group = "water-treatment",
    order = "d",
  },
--BARRELS
  {
    type = "item-group",
    name = "angels-barrels",
    order = "lb",
    inventory_order = "lb",
    icon = "__angelsrefining__/graphics/item-group/heavy-pump-group.png",
  },
  {
    type = "item-subgroup",
    name = "angels-barrels",
    group = "angels-barrels",
    order = "z",
  },
--VOID
  {
    type = "item-group",
    name = "angels-void",
    order = "aaaaa",
    inventory_order = "z",
    icon = "__angelsrefining__/graphics/technology/clarifier.png",
  },
  {
    type = "item-subgroup",
    name = "angels-void",
    group = "angels-void",
    order = "a-a",
  },
  }
  )