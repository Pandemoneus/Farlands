require "prototypes.candleInserters"
require "prototypes.candleTechnologies"
require "prototypes.candleStyles"