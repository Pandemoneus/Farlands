data:extend(
{
--PULVER
    {
    type = "recipe",
    name = "pulver-cobalt",
    category = "ore-processing",
	subgroup = "bio-processing-pulver",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"processed-cobalt", 1}},
    results=
    {
      {type="item", name="pulver-cobalt", amount=20},
    },
    icon = "__angelsbioprocessing__/graphics/icons/pulver-cobalt.png",
    order = "a [pulver-cobalt]",
    },
    {
    type = "recipe",
    name = "pulver-copper",
    category = "ore-processing",
	subgroup = "bio-processing-pulver",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"processed-copper", 1}},
    results=
    {
      {type="item", name="pulver-copper", amount=20},
    },
    icon = "__angelsbioprocessing__/graphics/icons/pulver-copper.png",
    order = "b [pulver-copper]",
    },
    {
    type = "recipe",
    name = "pulver-gold",
    category = "ore-processing",
	subgroup = "bio-processing-pulver",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"processed-gold", 1}},
    results=
    {
      {type="item", name="pulver-gold", amount=20},
    },
    icon = "__angelsbioprocessing__/graphics/icons/pulver-gold.png",
    order = "c [pulver-gold]",
    },
    {
    type = "recipe",
    name = "pulver-iron",
    category = "ore-processing",
	subgroup = "bio-processing-pulver",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"processed-iron", 1}},
    results=
    {
      {type="item", name="pulver-iron", amount=20},
    },
    icon = "__angelsbioprocessing__/graphics/icons/pulver-iron.png",
    order = "d [pulver-iron]",
    },
    {
    type = "recipe",
    name = "pulver-silver",
    category = "ore-processing",
	subgroup = "bio-processing-pulver",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"processed-silver", 1}},
    results=
    {
      {type="item", name="pulver-silver", amount=20},
    },
    icon = "__angelsbioprocessing__/graphics/icons/pulver-silver.png",
    order = "e [pulver-silver]",
    },	
    {
    type = "recipe",
    name = "pulver-titanium",
    category = "ore-processing",
	subgroup = "bio-processing-pulver",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"processed-titanium", 1}},
    results=
    {
      {type="item", name="pulver-titanium", amount=20},
    },
    icon = "__angelsbioprocessing__/graphics/icons/pulver-titanium.png",
    order = "f [pulver-titanium]",
    },
    {
    type = "recipe",
    name = "pulver-tungsten",
    category = "ore-processing",
	subgroup = "bio-processing-pulver",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"processed-tungsten", 1}},
    results=
    {
      {type="item", name="pulver-tungsten", amount=20},
    },
    icon = "__angelsbioprocessing__/graphics/icons/pulver-tungsten.png",
    order = "g [pulver-tungsten]",
    },
    {
    type = "recipe",
    name = "pulver-zinc",
    category = "ore-processing",
	subgroup = "bio-processing-pulver",
    energy_required = 2,
	enabled = "false",
    ingredients ={{"processed-zinc", 1}},
    results=
    {
      {type="item", name="pulver-zinc", amount=20},
    },
    icon = "__angelsbioprocessing__/graphics/icons/pulver-zinc.png",
    order = "h [pulver-zinc]",
    },		
--PASTE
  {
    type = "recipe",
    name = "paste-cobalt",
    category = "bio-processing",
	subgroup = "bio-processing-paste",
	enabled = "false",
    energy_required = 2,
    ingredients ={
		{type="item", name="paste-cellulose", amount=5},
	    {type="item", name="pulver-cobalt", amount=5},
	},
    results=
    {
      {type="item", name="paste-cobalt", amount=5},
    },
    icon = "__angelsbioprocessing__/graphics/icons/paste-cobalt.png",
    order = "a [paste-cobalt]",
  },
  {
    type = "recipe",
    name = "paste-copper",
    category = "bio-processing",
	subgroup = "bio-processing-paste",
	enabled = "false",
    energy_required = 2,
    ingredients ={
		{type="item", name="paste-cellulose", amount=5},
	    {type="item", name="pulver-copper", amount=5},
	},
    results=
    {
      {type="item", name="paste-copper", amount=5},
    },
    icon = "__angelsbioprocessing__/graphics/icons/paste-copper.png",
    order = "b [paste-copper]",
  }, 
  {
    type = "recipe",
    name = "paste-gold",
    category = "bio-processing",
	subgroup = "bio-processing-paste",
	enabled = "false",
    energy_required = 2,
    ingredients ={
		{type="item", name="paste-cellulose", amount=5},
	    {type="item", name="pulver-gold", amount=5},
	},
    results=
    {
      {type="item", name="paste-gold", amount=5},
    },
    icon = "__angelsbioprocessing__/graphics/icons/paste-gold.png",
    order = "c [paste-gold]",
  }, 
  {
    type = "recipe",
    name = "paste-iron",
    category = "bio-processing",
	subgroup = "bio-processing-paste",
	enabled = "false",
    energy_required = 2,
    ingredients ={
		{type="item", name="paste-cellulose", amount=5},
	    {type="item", name="pulver-iron", amount=5},
	},
    results=
    {
      {type="item", name="paste-iron", amount=5},
    },
    icon = "__angelsbioprocessing__/graphics/icons/paste-iron.png",
    order = "d [paste-iron]",
  }, 
  {
    type = "recipe",
    name = "paste-silver",
    category = "bio-processing",
	subgroup = "bio-processing-paste",
	enabled = "false",
    energy_required = 2,
    ingredients ={
		{type="item", name="paste-cellulose", amount=5},
	    {type="item", name="pulver-silver", amount=5},
	},
    results=
    {
      {type="item", name="paste-silver", amount=5},
    },
    icon = "__angelsbioprocessing__/graphics/icons/paste-silver.png",
    order = "e [paste-silver]",
  }, 
  {
    type = "recipe",
    name = "paste-titanium",
    category = "bio-processing",
	subgroup = "bio-processing-paste",
	enabled = "false",
    energy_required = 2,
    ingredients ={
		{type="item", name="paste-cellulose", amount=5},
	    {type="item", name="pulver-titanium", amount=5},
	},
    results=
    {
      {type="item", name="paste-titanium", amount=5},
    },
    icon = "__angelsbioprocessing__/graphics/icons/paste-titanium.png",
    order = "f [paste-titanium]",
  }, 
  {
    type = "recipe",
    name = "paste-tungsten",
    category = "bio-processing",
	subgroup = "bio-processing-paste",
	enabled = "false",
    energy_required = 2,
    ingredients ={
		{type="item", name="paste-cellulose", amount=5},
	    {type="item", name="pulver-tungsten", amount=5},
	},
    results=
    {
      {type="item", name="paste-tungsten", amount=5},
    },
    icon = "__angelsbioprocessing__/graphics/icons/paste-tungsten.png",
    order = "g [paste-tungsten]",
  }, 
  {
    type = "recipe",
    name = "paste-zinc",
    category = "bio-processing",
	subgroup = "bio-processing-paste",
	enabled = "false",
    energy_required = 2,
    ingredients ={
		{type="item", name="paste-cellulose", amount=5},
	    {type="item", name="pulver-zinc", amount=5},
	},
    results=
    {
      {type="item", name="paste-zinc", amount=5},
    },
    icon = "__angelsbioprocessing__/graphics/icons/paste-zinc.png",
    order = "h [paste-zinc]",
  }, 
  }
  )