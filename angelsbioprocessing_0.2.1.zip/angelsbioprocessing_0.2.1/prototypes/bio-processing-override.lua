--REFINING
if angelsmods.refining then
	--MOVE UNLOCKS
	angelsmods.functions.OV.add_unlock("bio-processing-1", "water-mineralized")
	angelsmods.functions.OV.remove_unlock("water-treatment", "water-mineralized")
end